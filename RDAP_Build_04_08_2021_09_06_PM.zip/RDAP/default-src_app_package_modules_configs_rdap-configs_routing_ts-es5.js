(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (self["webpackChunkrdap"] = self["webpackChunkrdap"] || []).push([["default-src_app_package_modules_configs_rdap-configs_routing_ts"], {
    /***/
    61725: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "configRoutes": function configRoutes() {
          return (
            /* binding */
            _configRoutes
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _configs_setup_tables_setup_table_home_setup_table_home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../configs/setup-tables/setup-table-home/setup-table-home.component */
      4183);
      /* harmony import */


      var _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./setup-tables/rdap-config-common-add-edit/rdap-config-common-add-edit.component */
      41205);
      /* harmony import */


      var _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./setup-tables/rdap-config-common-search/rdap-config-common-search.component */
      2021);

      var routes = [{
        path: "setuptable",
        component: _configs_setup_tables_setup_table_home_setup_table_home_component__WEBPACK_IMPORTED_MODULE_0__.SetupTableHomeComponent,
        children: [{
          path: "studio",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "version",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "epp",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "pool",
          // component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "region",
          // component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "status1",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "status2",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "status3",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "prodcat1",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "prodcat2",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "prodcat3",
          // component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "channeltype",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "cabinets",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "channel",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "devefforttype",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "devcomplexity",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "gravity",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "devtype1",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "devtype2",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "market",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }, {
          path: "quarter",
          //component: RdapConfigCommonSearchComponent,
          children: [{
            path: "search",
            component: _setup_tables_rdap_config_common_search_rdap_config_common_search_component__WEBPACK_IMPORTED_MODULE_2__.RdapConfigCommonSearchComponent
          }, {
            path: "add",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }, {
            path: "edit",
            component: _setup_tables_rdap_config_common_add_edit_rdap_config_common_add_edit_component__WEBPACK_IMPORTED_MODULE_1__.RdapConfigCommonAddEditComponent
          }]
        }]
      }];

      var _configRoutes = _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes);
      /***/

    },

    /***/
    41205: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RdapConfigCommonAddEditComponent": function RdapConfigCommonAddEditComponent() {
          return (
            /* binding */
            _RdapConfigCommonAddEditComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _core_core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../../../../core/core-shared-components/rdap-shared-breadcrumb/rdap-shared-breadcrumb.component */
      16971);
      /* harmony import */


      var _core_core_shared_components_rdap_shared_config_setuptable_addedit_rdap_shared_config_setuptable_addedit_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../../../../core/core-shared-components/rdap-shared-config-setuptable-addedit/rdap-shared-config-setuptable-addedit.component */
      46448);

      var _RdapConfigCommonAddEditComponent = /*#__PURE__*/function () {
        function _RdapConfigCommonAddEditComponent() {
          _classCallCheck(this, _RdapConfigCommonAddEditComponent);
        }

        _createClass(_RdapConfigCommonAddEditComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "submit",
          value: function submit(event) {
            console.log("event", event);
          }
        }]);

        return _RdapConfigCommonAddEditComponent;
      }();

      _RdapConfigCommonAddEditComponent.ɵfac = function RdapConfigCommonAddEditComponent_Factory(t) {
        return new (t || _RdapConfigCommonAddEditComponent)();
      };

      _RdapConfigCommonAddEditComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
        type: _RdapConfigCommonAddEditComponent,
        selectors: [["app-rdap-config-common-add-edit"]],
        decls: 4,
        vars: 0,
        consts: [[1, "grid-container"], [2, "padding-left", "2%", "padding-right", "2%", "padding-bottom", "2%", "padding-top", "0%"], [3, "onSearchSumbit"]],
        template: function RdapConfigCommonAddEditComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "app-rdap-shared-breadcrumb");

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "app-rdap-shared-config-setuptable-addedit", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("onSearchSumbit", function RdapConfigCommonAddEditComponent_Template_app_rdap_shared_config_setuptable_addedit_onSearchSumbit_3_listener($event) {
              return ctx.submit($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          }
        },
        directives: [_core_core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__.RdapSharedBreadcrumbComponent, _core_core_shared_components_rdap_shared_config_setuptable_addedit_rdap_shared_config_setuptable_addedit_component__WEBPACK_IMPORTED_MODULE_1__.RdapSharedConfigSetuptableAddeditComponent],
        styles: [".grid-container[_ngcontent-%COMP%] {\n  margin: 10px;\n  min-height: calc(100vh - 100px);\n}\n\n.mat-form-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .mat-form-field .mat-input-element {\n  margin-top: 0.9em !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtY29uZmlnLWNvbW1vbi1hZGQtZWRpdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSwrQkFBQTtBQUNKOztBQUVFO0VBQ0UsV0FBQTtBQUNKOztBQUdJO0VBQ0ksNEJBQUE7QUFBUiIsImZpbGUiOiJyZGFwLWNvbmZpZy1jb21tb24tYWRkLWVkaXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZ3JpZC1jb250YWluZXIge1xyXG4gICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgbWluLWhlaWdodDpjYWxjKDEwMHZoIC0gMTAwcHgpOyBcclxuICB9XHJcblxyXG4gIC5tYXQtZm9ybS1maWVsZHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG46aG9zdDo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQge1xyXG4gICAgLm1hdC1pbnB1dC1lbGVtZW50IHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAwLjllbSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59Il19 */"]
      });
      /***/
    },

    /***/
    2021: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RdapConfigCommonSearchComponent": function RdapConfigCommonSearchComponent() {
          return (
            /* binding */
            _RdapConfigCommonSearchComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      91841);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _core_core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../../../../core/core-shared-components/rdap-shared-breadcrumb/rdap-shared-breadcrumb.component */
      16971);
      /* harmony import */


      var _core_core_shared_components_rdap_shared_config_search_rdap_shared_config_search_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../../../../core/core-shared-components/rdap-shared-config-search/rdap-shared-config-search.component */
      70482);

      var _RdapConfigCommonSearchComponent = /*#__PURE__*/function () {
        function _RdapConfigCommonSearchComponent(httpClient, location, router, fb) {
          var _this = this;

          _classCallCheck(this, _RdapConfigCommonSearchComponent);

          this.httpClient = httpClient;
          this.fb = fb;
          router.events.subscribe(function (val) {
            if (location.path() != '') {
              _this.route = location.path();
              _this.routeName = _this.route.split('/')[_this.route.split('/').length - 1]; // if(this.routeName == "marketsearch"){
              //   this.pageName = "Market";
              // }else if(this.routeName == "studiosearch"){
              //   this.pageName = "Studio";
              // }else if(this.routeName == "versionsearch"){
              //   this.pageName = "Version";
              // }else if(this.routeName == "eppsearch"){
              //   this.pageName = "EPP";
              // }else if(this.routeName == "gravitysearch"){
              //   this.pageName = "Gravity";
              // }else if(this.routeName == "poolsearch"){
              //   this.pageName = "EPP";
              // }else if(this.routeName == "regionsearch"){
              //   this.pageName = "EPP";
              // }
            } else {
              _this.route = 'Home';
            }
          });
        }

        _createClass(_RdapConfigCommonSearchComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "submit",
          value: function submit(event) {
            console.log("event", event);
          }
        }]);

        return _RdapConfigCommonSearchComponent;
      }();

      _RdapConfigCommonSearchComponent.ɵfac = function RdapConfigCommonSearchComponent_Factory(t) {
        return new (t || _RdapConfigCommonSearchComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder));
      };

      _RdapConfigCommonSearchComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
        type: _RdapConfigCommonSearchComponent,
        selectors: [["app-rdap-config-common-search"]],
        decls: 4,
        vars: 0,
        consts: [[1, "grid-container"], [2, "padding-left", "2%", "padding-right", "2%", "min-height", "300px", "padding-bottom", "5%", "padding-top", "0%"], [3, "onSearchSumbit"]],
        template: function RdapConfigCommonSearchComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "app-rdap-shared-breadcrumb");

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "app-rdap-shared-config-search", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("onSearchSumbit", function RdapConfigCommonSearchComponent_Template_app_rdap_shared_config_search_onSearchSumbit_3_listener($event) {
              return ctx.submit($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          }
        },
        directives: [_core_core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__.RdapSharedBreadcrumbComponent, _core_core_shared_components_rdap_shared_config_search_rdap_shared_config_search_component__WEBPACK_IMPORTED_MODULE_1__.RdapSharedConfigSearchComponent],
        styles: [".grid-container[_ngcontent-%COMP%] {\n  margin: 10px;\n  min-height: calc(100vh - 100px);\n}\n\n.mat-form-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .mat-form-field .mat-input-element {\n  margin-top: 0.9em !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtY29uZmlnLWNvbW1vbi1zZWFyY2guY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsK0JBQUE7QUFDSjs7QUFFRTtFQUNFLFdBQUE7QUFDSjs7QUFHSTtFQUNJLDRCQUFBO0FBQVIiLCJmaWxlIjoicmRhcC1jb25maWctY29tbW9uLXNlYXJjaC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ncmlkLWNvbnRhaW5lciB7XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICBtaW4taGVpZ2h0OmNhbGMoMTAwdmggLSAxMDBweCk7IFxyXG4gIH1cclxuXHJcbiAgLm1hdC1mb3JtLWZpZWxke1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbjpob3N0OjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICAubWF0LWlucHV0LWVsZW1lbnQge1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDAuOWVtICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */"]
      });
      /***/
    },

    /***/
    4183: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SetupTableHomeComponent": function SetupTableHomeComponent() {
          return (
            /* binding */
            _SetupTableHomeComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      39895);

      var _SetupTableHomeComponent = /*#__PURE__*/function () {
        function _SetupTableHomeComponent() {
          _classCallCheck(this, _SetupTableHomeComponent);
        }

        _createClass(_SetupTableHomeComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return _SetupTableHomeComponent;
      }();

      _SetupTableHomeComponent.ɵfac = function SetupTableHomeComponent_Factory(t) {
        return new (t || _SetupTableHomeComponent)();
      };

      _SetupTableHomeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: _SetupTableHomeComponent,
        selectors: [["app-setup-table-home"]],
        decls: 1,
        vars: 0,
        template: function SetupTableHomeComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
          }
        },
        directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
        styles: [".main_content[_ngcontent-%COMP%] {\n  width: 100%;\n  height: calc(100vh - 100%);\n  background: #efefef;\n  padding-top: 15%;\n}\n\n.grid-container[_ngcontent-%COMP%] {\n  margin: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNldHVwLXRhYmxlLWhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsMEJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxZQUFBO0FBRUoiLCJmaWxlIjoic2V0dXAtdGFibGUtaG9tZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnQge1xyXG4gICAgd2lkdGg6MTAwJTsgXHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxMDAlKTsgXHJcbiAgICBiYWNrZ3JvdW5kOiAjZWZlZmVmO1xyXG4gICAgcGFkZGluZy10b3A6IDE1JTtcclxuICB9XHJcbiAgLmdyaWQtY29udGFpbmVyIHtcclxuICAgIG1hcmdpbjogMjBweDtcclxuICB9Il19 */"]
      });
      /***/
    }
  }]);
})();
//# sourceMappingURL=default-src_app_package_modules_configs_rdap-configs_routing_ts-es5.js.map