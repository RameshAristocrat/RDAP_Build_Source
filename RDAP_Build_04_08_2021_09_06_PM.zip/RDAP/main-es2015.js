(self["webpackChunkrdap"] = self["webpackChunkrdap"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ (function(module) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": function() { return /* binding */ AppRoutingModule; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);



//const routes: Routes = [];
const routes = [{ path: "", redirectTo: "login", pathMatch: "full", }];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterModule.forRoot(routes, { onSameUrlNavigation: "reload", relativeLinkResolution: 'legacy' })], _angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterModule] }); })();


/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": function() { return /* binding */ AppComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _app_package_core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../app/package/core/okta-auth/okta-auth-service */ 59841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 39895);



class AppComponent {
    constructor(oktaAuthserv) {
        this.oktaAuthserv = oktaAuthserv;
        this.title = 'okta-app';
        this.isAuthenticated = false;
    }
    ngOnInit() {
        this.oktaAuthserv.$isAuthenticated.subscribe(val => {
            debugger;
            this.isAuthenticated = val;
        });
        if (!this.isAuthenticated) {
            debugger;
            //this.oktaAuthserv.login('/login')
        }
        else {
        }
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_package_core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__.OktaAuthService)); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": function() { return /* binding */ AppModule; }
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 39075);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser/animations */ 75835);
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/flex-layout */ 25830);
/* harmony import */ var _package_core_login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./package/core/login/login.component */ 11005);
/* harmony import */ var _package_core_core_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./package/core/core.module */ 37713);
/* harmony import */ var _app_package_mat_modules_material_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../app/package/mat-modules/material.module */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _package_core_side_menu_bar_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./package/core/side-menu-bar/sidenav.service */ 14295);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);













//import { RdapExtraPinRequestDropdownComponent } from './package/modules/rdap-shared-components/rdap-autocomplete-shared-component/rdap-extra-pin-request-dropdown/rdap-extra-pin-request-dropdown.component';
//import { RdapSearchSharedComponent } from './package/modules/rdap-shared-components/rdap-search-shared/rdap-search-shared.component';
//import { StudioComponent } from './package/modules/configs/setup-tables/studio/studio.component';
//import { RDAPExtraPINRequestComponent } from './package/modules/rdap-extra-pin-request/rdap-extra-pin-request.component';
//import { DashboardComponent } from './package/launch-pad/components/dashboard/dashboard.component';
const oktaConfig = {
    issuer: 'https://aristocrat.okta.com',
    redirectUri: 'http://sydc-appdev-01:8080/main/launcher',
    clientId: '0oa9t7ifubUwIhATi357',
    scope: 'openid'
};
class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ providers: [_package_core_side_menu_bar_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService,
        //{ provide: OKTA_CONFIG, useValue: oktaConfig }
        //WorkoutService,
        //{provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
    ], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__.BrowserAnimationsModule,
            _app_package_mat_modules_material_module__WEBPACK_IMPORTED_MODULE_4__.MaterialModule,
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_10__.FlexLayoutModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _package_core_core_module__WEBPACK_IMPORTED_MODULE_3__.CoreModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent,
        _package_core_login_login_component__WEBPACK_IMPORTED_MODULE_2__.LoginComponent], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__.BrowserAnimationsModule,
        _app_package_mat_modules_material_module__WEBPACK_IMPORTED_MODULE_4__.MaterialModule,
        _angular_flex_layout__WEBPACK_IMPORTED_MODULE_10__.FlexLayoutModule,
        _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
        _package_core_core_module__WEBPACK_IMPORTED_MODULE_3__.CoreModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule,
        _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule] }); })();


/***/ }),

/***/ 8101:
/*!*****************************************************!*\
  !*** ./src/app/package/core/animation/animation.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "onSideNavChange": function() { return /* binding */ onSideNavChange; },
/* harmony export */   "onMainContentChange": function() { return /* binding */ onMainContentChange; },
/* harmony export */   "animateText": function() { return /* binding */ animateText; }
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/animations */ 17238);

const onSideNavChange = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)('onSideNavChange', [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('close', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'min-width': '50px'
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'min-width': '200px'
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('close => open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('250ms ease-in')),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('open => close', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('250ms ease-in')),
]);
const onMainContentChange = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)('onMainContentChange', [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('close', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'margin-left': '62px'
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'margin-left': '200px'
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('close => open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('250ms ease-in')),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('open => close', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('250ms ease-in')),
]);
const animateText = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)('animateText', [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('hide', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'display': 'none',
        opacity: 0,
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.state)('show', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
        'display': 'block',
        opacity: 1,
    })),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('close => open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('350ms ease-in')),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('open => close', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('200ms ease-out')),
]);


/***/ }),

/***/ 27497:
/*!**************************************************************************!*\
  !*** ./src/app/package/core/components/datatable/datatable.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatatableComponent": function() { return /* binding */ DatatableComponent; }
/* harmony export */ });
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/paginator */ 99692);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/sort */ 11494);
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/table */ 32091);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/tooltip */ 11436);










function DatatableComponent_th_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_td_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r12.position, " ");
} }
function DatatableComponent_th_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_td_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r13.name, " ");
} }
function DatatableComponent_th_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Weight ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_td_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r14.weight, " ");
} }
function DatatableComponent_th_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Symbol ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_td_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r15.symbol, " ");
} }
function DatatableComponent_th_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Actions ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_td_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "add");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " add_circle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " remove_circle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DatatableComponent_tr_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 22);
} }
function DatatableComponent_tr_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 23);
} }
const _c0 = function () { return [10, 20]; };
const ELEMENT_DATA = [
    { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
];
class DatatableComponent {
    constructor() {
        this.displayedColumns = ['position', 'name', 'weight', 'symbol', 'actions'];
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatTableDataSource(ELEMENT_DATA);
    }
    ngAfterViewInit() {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
    }
    ngOnInit() {
    }
    deleteRowData(row_obj) {
        //this.dataSource = this.dataSource.filter((value,key)=>{
        //return value.id != row_obj.id;
        //});
    }
}
DatatableComponent.ɵfac = function DatatableComponent_Factory(t) { return new (t || DatatableComponent)(); };
DatatableComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DatatableComponent, selectors: [["app-datatable"]], viewQuery: function DatatableComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_sort__WEBPACK_IMPORTED_MODULE_2__.MatSort, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__.MatPaginator, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.sort = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, decls: 22, vars: 5, consts: [[1, "grid-container"], [1, "mat-h1"], ["mat-table", "", "matSort", "", 1, "mat-elevation-z8", 3, "dataSource"], ["matColumnDef", "position"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "name"], ["matColumnDef", "weight"], ["matColumnDef", "symbol"], ["matColumnDef", "actions"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-cell", ""], ["mat-header-cell", ""], ["mat-icon-button", "", "color", "primary"], ["aria-label", "Example icon-button with a heart icon"], ["mat-icon-button", "", "matTooltip", "Click to Edit", "color", "primary", 1, "iconbutton"], [1, "material-icons-round"], ["mat-icon-button", "", "matTooltip", "Click to Delete", "color", "warn", 1, "iconbutton"], ["mat-header-row", ""], ["mat-row", ""]], template: function DatatableComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h1", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Grid");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "table", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](4, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, DatatableComponent_th_5_Template, 2, 0, "th", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, DatatableComponent_td_6_Template, 2, 1, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](7, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, DatatableComponent_th_8_Template, 2, 0, "th", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, DatatableComponent_td_9_Template, 2, 1, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](10, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, DatatableComponent_th_11_Template, 2, 0, "th", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, DatatableComponent_td_12_Template, 2, 1, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](13, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, DatatableComponent_th_14_Template, 2, 0, "th", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](15, DatatableComponent_td_15_Template, 2, 1, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](16, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, DatatableComponent_th_17_Template, 2, 0, "th", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, DatatableComponent_td_18_Template, 10, 0, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](19, DatatableComponent_tr_19_Template, 1, 0, "tr", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](20, DatatableComponent_tr_20_Template, 1, 0, "tr", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "mat-paginator", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx.dataSource);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx.displayedColumns);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx.displayedColumns);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](4, _c0));
    } }, directives: [_angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatTable, _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__.MatSort, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatColumnDef, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatHeaderCellDef, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatCellDef, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatHeaderRowDef, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatRowDef, _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__.MatPaginator, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatHeaderCell, _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__.MatSortHeader, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatCell, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIcon, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltip, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatHeaderRow, _angular_material_table__WEBPACK_IMPORTED_MODULE_1__.MatRow], styles: ["table[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.grid-container[_ngcontent-%COMP%] {\n  margin: 20px;\n}\n\n.dashboard-card[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 15px;\n  left: 15px;\n  right: 15px;\n  bottom: 15px;\n}\n\n.more-button[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 5px;\n  right: 10px;\n}\n\n.dashboard-card-content[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhdGF0YWJsZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUFDSjs7QUFFRTtFQUNFLFlBQUE7QUFDSjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtBQUNKOztBQUVFO0VBQ0Usa0JBQUE7QUFDSiIsImZpbGUiOiJkYXRhdGFibGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ0YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcblxyXG4gIC5ncmlkLWNvbnRhaW5lciB7XHJcbiAgICBtYXJnaW46IDIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5kYXNoYm9hcmQtY2FyZCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDE1cHg7XHJcbiAgICBsZWZ0OiAxNXB4O1xyXG4gICAgcmlnaHQ6IDE1cHg7XHJcbiAgICBib3R0b206IDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5tb3JlLWJ1dHRvbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDVweDtcclxuICAgIHJpZ2h0OiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAuZGFzaGJvYXJkLWNhcmQtY29udGVudCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfSJdfQ== */"] });


/***/ }),

/***/ 99020:
/*!**********************************************!*\
  !*** ./src/app/package/core/core-routing.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreRoutes": function() { return /* binding */ CoreRoutes; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login/login.component */ 11005);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home/home.component */ 73964);
/* harmony import */ var _d_board_d_board_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./d-board/d-board.component */ 67584);
/* harmony import */ var _components_datatable_datatable_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/datatable/datatable.component */ 27497);
/* harmony import */ var _okta_auth_okta_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./okta-auth/okta-auth-guard */ 76793);






const routes = [
    {
        path: "login",
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent,
        canActivate: [_okta_auth_okta_auth_guard__WEBPACK_IMPORTED_MODULE_4__.OktaAuthGuard]
    },
    {
        path: "main",
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_1__.HomeComponent,
        children: [
            {
                path: "launcher",
                component: _d_board_d_board_component__WEBPACK_IMPORTED_MODULE_2__.DBoardComponent,
            },
            {
                path: "expinreq",
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_package_modules_configs_rdap-configs_routing_ts"), __webpack_require__.e("src_app_package_modules_rdap-extra-pin-request_rdap_extra_pin_request_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../modules/rdap-extra-pin-request/rdap_extra_pin_request.module */ 16927)).then((m) => m.RdapExtraPinRequestModule),
            },
            {
                path: "config",
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_package_modules_configs_rdap-configs_routing_ts"), __webpack_require__.e("src_app_package_modules_configs_rdap-configs_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../modules/configs/rdap-configs.module */ 16696)).then((m) => m.RdapConfigModule),
            }
        ],
    }, {
        path: "tool",
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_1__.HomeComponent,
        children: [
            {
                path: "datatable",
                component: _components_datatable_datatable_component__WEBPACK_IMPORTED_MODULE_3__.DatatableComponent,
            }
        ]
    },
    // {
    //   path: "main",
    //   component: HomeComponent,
    //   children: [
    //     {
    //       path: "launcher",
    //       loadChildren: () =>
    //         import("../launch-pad/launch-pad.module").then(
    //           (m) => m.LaunchPadModule
    //         ),
    //     }]
    // }
];
const CoreRoutes = _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes);


/***/ }),

/***/ 16971:
/*!****************************************************************************************************************!*\
  !*** ./src/app/package/core/core-shared-components/rdap-shared-breadcrumb/rdap-shared-breadcrumb.component.ts ***!
  \****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RdapSharedBreadcrumbComponent": function() { return /* binding */ RdapSharedBreadcrumbComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/card */ 93738);





function RdapSharedBreadcrumbComponent_li_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", item_r1.url);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", item_r1.label, " ");
} }
class RdapSharedBreadcrumbComponent {
    constructor(httpClient, location, router) {
        this.httpClient = httpClient;
        this.breadcrumbdetails = [];
        router.events.subscribe((val) => {
            if (location.path() != '') {
                this.route = location.path();
                this.routeName = this.route.split('/')[this.route.split('/').length - 1];
            }
            else {
                this.route = 'Home';
            }
        });
        this.httpClient.get("assets/config/breadcrumb-details.json").subscribe(data => {
            //console.log(data)
            this.breadcrumbdetails.push(data);
            this.breadcrumb();
        });
    }
    ngOnInit() {
        // console.log(this.breadcrumbarr);
        // console.log(this.breadcrumbLinksList);
    }
    breadcrumb() {
        this.breadcrumbList = [];
        this.breadcrumbLinksList = [];
        this.breadcrumbarr = [];
        this.breadcrumbarr.push({ label: "Home", url: "/main/launcher" });
        this.breadcrumbList = this.route.split('/');
        this.breadcrumbLinksList = [this.breadcrumbList[0]];
        let tempBreadcrumbDetail = [];
        for (let i = 1; i <= this.breadcrumbList.length; i++) {
            const link = this.breadcrumbLinksList[i - 1] + '/' + this.breadcrumbList[i];
            this.breadcrumbLinksList.push(link);
            //this.breadcrumbList[i]
            if ((i > 1) && (i < this.breadcrumbList.length)) {
                if (this.breadcrumbList[i] == "launcher") {
                    this.breadcrumbarr.push({ label: "Dashboard", url: "/main/launcher" });
                }
                else {
                    tempBreadcrumbDetail = this.breadcrumbdetails[0].filter(x => {
                        if (x.page == this.breadcrumbList[i]) {
                            if (x.details.length > 1) {
                                this.breadcrumbarr.push(x.details.filter(x => { return x.url == this.route; })[0]);
                            }
                            else {
                                this.breadcrumbarr.push(x.details[0]);
                            }
                        }
                    });
                }
            }
        }
    }
}
RdapSharedBreadcrumbComponent.ɵfac = function RdapSharedBreadcrumbComponent_Factory(t) { return new (t || RdapSharedBreadcrumbComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_2__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router)); };
RdapSharedBreadcrumbComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: RdapSharedBreadcrumbComponent, selectors: [["app-rdap-shared-breadcrumb"]], decls: 4, vars: 1, consts: [[2, "margin-bottom", "1%"], [1, "breadcrumb"], [4, "ngFor", "ngForOf"], ["routerLinkActive", "router-link-active", 3, "routerLink"]], template: function RdapSharedBreadcrumbComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ol", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, RdapSharedBreadcrumbComponent_li_3_Template, 3, 2, "li", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.breadcrumbarr);
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_4__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_4__.MatCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLinkWithHref, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLinkActive], styles: [".breadcrumb[_ngcontent-%COMP%] {\n  background: none;\n  font-size: 1em;\n  margin: 0;\n}\n.breadcrumb[_ngcontent-%COMP%]   a[_ngcontent-%COMP%], .breadcrumb[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #968f8f;\n  padding-bottom: 1%;\n}\n.breadcrumb[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, .breadcrumb[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:hover {\n  color: #e50f7c;\n  text-decoration: none;\n}\n.breadcrumb[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-decoration: none;\n}\n.breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  list-style: none;\n  float: left;\n  margin: 5px;\n}\n.breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child {\n  margin-right: 20px;\n}\n.breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child   a[_ngcontent-%COMP%], .breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child   span[_ngcontent-%COMP%] {\n  color: #e50f7c;\n  font-weight: 500;\n  padding-bottom: 1%;\n}\n.breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]::after {\n  content: \">>\";\n  color: #000000;\n  font-weight: bold;\n}\n.breadcrumb[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child::after {\n  content: \"\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtc2hhcmVkLWJyZWFkY3J1bWIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBQ0o7QUFBSTs7RUFFRSxjQUFBO0VBQ0Esa0JBQUE7QUFFTjtBQUFJOztFQUVFLGNBQUE7RUFDQSxxQkFBQTtBQUVOO0FBQUk7RUFDSSxxQkFBQTtBQUVSO0FBQUk7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBRU47QUFBSTtFQUNFLGtCQUFBO0FBRU47QUFETTs7RUFFQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUdOO0FBQUk7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBRU47QUFBSTtFQUNFLFdBQUE7QUFFTiIsImZpbGUiOiJyZGFwLXNoYXJlZC1icmVhZGNydW1iLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJyZWFkY3J1bWIge1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMS4wZW07XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBhLFxyXG4gICAgc3BhbiB7XHJcbiAgICAgIGNvbG9yOiAjOTY4ZjhmO1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMSU7XHJcbiAgICB9XHJcbiAgICBhOmhvdmVyLFxyXG4gICAgc3Bhbjpob3ZlciB7XHJcbiAgICAgIGNvbG9yOiAjZTUwZjdjO1xyXG4gICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICB9XHJcbiAgICBhe1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIH1cclxuICAgIGxpIHtcclxuICAgICAgbGlzdC1zdHlsZTogbm9uZTtcclxuICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgIG1hcmdpbjogNXB4O1xyXG4gICAgfVxyXG4gICAgbGk6bGFzdC1jaGlsZCB7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgICAgYSxcclxuICAgIHNwYW4ge1xyXG4gICAgICBjb2xvcjogI2U1MGY3YztcclxuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgcGFkZGluZy1ib3R0b206IDElO1xyXG4gICAgfVxyXG4gICAgfVxyXG4gICAgbGk6OmFmdGVyIHtcclxuICAgICAgY29udGVudDogXCI+PlwiO1xyXG4gICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB9XHJcbiAgICBsaTpsYXN0LWNoaWxkOjphZnRlciB7XHJcbiAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuIl19 */"] });


/***/ }),

/***/ 70482:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/package/core/core-shared-components/rdap-shared-config-search/rdap-shared-config-search.component.ts ***!
  \**********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RdapSharedConfigSearchComponent": function() { return /* binding */ RdapSharedConfigSearchComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/table */ 32091);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/sort */ 11494);
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/paginator */ 99692);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/snack-bar */ 77001);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/form-field */ 98295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/input */ 83166);
/* harmony import */ var _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/cdk/text-field */ 96109);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ng-select/ng-select */ 86640);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _rdap_shared_igx_grid_search_result_rdap_shared_igx_grid_search_result_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../rdap-shared-igx-grid-search-result/rdap-shared-igx-grid-search-result.component */ 78076);


















function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_mat_error_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r4.label, " required");
} }
function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_span_3_Template, 2, 0, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_mat_error_5_Template, 2, 1, "mat-error", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r4.label, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r4.required == "required");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("name", item_r4.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r4.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r5.checkError(item_r4.formcontrolname, item_r4.required));
} }
function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_mat_error_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r4.label, " required");
} }
function RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_span_3_Template, 2, 0, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "textarea", 13, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_mat_error_6_Template, 2, 1, "mat-error", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r4.label, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r4.required == "required");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("name", item_r4.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r4.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("placeholder", item_r4.placeholder);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r6.checkError(item_r4.formcontrolname, item_r4.required));
} }
function RdapSharedConfigSearchComponent_form_3_div_2_div_3_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0);
} if (rf & 2) {
    const item_r18 = ctx.item;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r18.name, " ");
} }
function RdapSharedConfigSearchComponent_form_3_div_2_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "fieldset", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ng-select", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSearchComponent_form_3_div_2_div_3_ng_template_3_Template, 1, 1, "ng-template", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("labelForId", item_r4.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("placeholder", item_r4.placeholder);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("bindLabel", item_r4.bindname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r4.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("items", item_r4.apidata)("clearable", item_r4.clearable)("virtualScroll", item_r4.virtualScroll)("multiple", item_r4.multiple);
} }
function RdapSharedConfigSearchComponent_form_3_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_1_Template, 6, 6, "mat-form-field", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, RdapSharedConfigSearchComponent_form_3_div_2_mat_form_field_2_Template, 7, 6, "mat-form-field", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSearchComponent_form_3_div_2_div_3_Template, 4, 8, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r4.type == "text");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r4.type == "textarea");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r4.type == "select");
} }
function RdapSharedConfigSearchComponent_form_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "form", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, RdapSharedConfigSearchComponent_form_3_div_2_Template, 4, 3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx_r0.searchform);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.formdata);
} }
const _c0 = function (a0, a1) { return { "errorbtn": a0, "successbtn": a1 }; };
function RdapSharedConfigSearchComponent_mat_card_actions_4_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-card-actions", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RdapSharedConfigSearchComponent_mat_card_actions_4_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r21); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r20.submit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Search");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Reset");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", !ctx_r1.searchform.valid)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](2, _c0, !ctx_r1.searchform.valid, ctx_r1.searchform.valid));
} }
function RdapSharedConfigSearchComponent_mat_card_5_button_11_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RdapSharedConfigSearchComponent_mat_card_5_button_11_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r24); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r23.addnewrecord(ctx_r23.route); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Add New Record");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function RdapSharedConfigSearchComponent_mat_card_5_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-card");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Search Results");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "app-rdap-shared-igx-grid-search-result", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "mat-card-actions", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RdapSharedConfigSearchComponent_mat_card_5_Template_button_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r26); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r25.submit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Open");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, RdapSharedConfigSearchComponent_mat_card_5_button_11_Template, 2, 0, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("searchGridData", ctx_r2.searchGridData)("appString", ctx_r2.appString);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r2.route);
} }
const ELEMENT_DATA = [
    { position: 1, name: 'Game Title#1' },
    { position: 2, name: 'Game Title#2' },
    { position: 3, name: 'Game Title#3' },
    // { position: 4, name: 'Game Title#4'},
    // { position: 5, name: 'Game Title#5'},
    // { position: 6, name: 'Game Title#6'},
    // { position: 7, name: 'Game Title#7'},
    // { position: 8, name: 'Game Title#8'}
];
class RdapSharedConfigSearchComponent {
    constructor(httpClient, location, _router, fb, _snackBar) {
        this.httpClient = httpClient;
        this._router = _router;
        this.fb = fb;
        this._snackBar = _snackBar;
        this.horizontalPosition = 'right';
        this.verticalPosition = 'top';
        this.onSearchSumbit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.timeOut = 500;
        //= ['select', 'position'];
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_2__.MatTableDataSource(ELEMENT_DATA);
        this.checkError = (controlName, errorName) => {
            return this.searchform.controls[controlName].hasError(errorName);
        };
        _router.events.subscribe((val) => {
            if (location.path() != '') {
                this.route = location.path();
                this.routeName = this.route.split('/')[this.route.split('/').length - 1];
            }
            else {
                this.route = 'Home';
            }
        });
        this.httpClient.get("assets/config/masterScreenSearchCommonConfig.json").subscribe(data => {
            this.configdata = data;
            this.getFormData();
        });
        this.appString = [];
        this.httpClient.get("assets/config/app-string.json").subscribe(data => {
            this.appString = data;
        });
    }
    ngAfterViewInit() {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
    }
    ngOnInit() {
    }
    getFormData() {
        this.formSelectApiData = [];
        if (this.route.match("studio") && this.route.match("studio").length > 0) {
            this.formName = "studioSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.studio;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("version") && this.route.match("version").length > 0) {
            this.formName = "versionSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.version;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("epp") && this.route.match("epp").length > 0) {
            this.formName = "eppSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.EPP;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("region") && this.route.match("region").length > 0) {
            this.formName = "regionSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.region;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("pool") && this.route.match("pool").length > 0) {
            this.formName = "poolSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.pool;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat1") && this.route.match("prodcat1").length > 0) {
            this.formName = "prodcat1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat2") && this.route.match("prodcat2").length > 0) {
            this.formName = "prodcat2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat3") && this.route.match("prodcat3").length > 0) {
            this.formName = "prodcat3SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat3;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status1") && this.route.match("status1").length > 0) {
            this.formName = "status1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status2") && this.route.match("status2").length > 0) {
            this.formName = "status2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status3") && this.route.match("status3").length > 0) {
            this.formName = "status3SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status3;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("gravity") && this.route.match("gravity").length > 0) {
            this.formName = "gravitySearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.gravity;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devtype1") && this.route.match("devtype1").length > 0) {
            this.formName = "devtype1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devtype1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devtype2") && this.route.match("devtype2").length > 0) {
            this.formName = "devtype2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devtype2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("channeltype") && this.route.match("channeltype").length > 0) {
            this.formName = "channeltypeSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.channeltype;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("cabinets") && this.route.match("cabinets").length > 0) {
            this.formName = "cabinetsSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.cabinets;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("channel") && this.route.match("channel").length > 0) {
            this.formName = "channelSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.channel;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devefforttype") && this.route.match("devefforttype").length > 0) {
            this.formName = "devefforttypeSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devefforttype;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devcomplexity") && this.route.match("devcomplexity").length > 0) {
            this.formName = "devcomplexitySearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devcomplexity;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("market") && this.route.match("market").length > 0) {
            this.formName = "marketSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.market;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("quarter") && this.route.match("quarter").length > 0) {
            this.formName = "quarterSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.quarter;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
    }
    submit() {
        this.formGroupArr = [];
        this.gridsource = [];
        this.displayedColumns = [];
        this.loopGridContent = [];
        this.displayedColumns.push("select");
        let count = 1;
        let errorFlag = false;
        if (this.searchform.invalid) {
            return;
        }
        // this.formdata.forEach((x, index) => {
        //   if (isEmptyString(this.searchform.get(x.formcontrolname).value)) {
        //     setTimeout(() => {
        //       this.openSnackBar("Enter " + x.label + " !!");
        //       errorFlag = true;
        //     }, count * (this.timeOut + 500));
        //     count++;
        //   }
        //   this.formGroupArr.push({ key: x.formcontrolname, value: this.searchform.get(x.formcontrolname).value });
        // });
        // this.httpClient.get(this.griddata.api).subscribe(data => {
        //   this.gridsource.push(data);
        //   this.gridsource.filter(x => {
        //     x.filter(y => {
        //       if(this.route.match(y.pagename)){
        //         this.tempFilterData = y.data;
        //       };
        //     })
        //   })
        //   if (this.tempFilterData) {
        //   Object.keys(this.tempFilterData[0]).forEach(x =>{
        //     this.displayedColumns.push(x);
        //     this.loopGridContent.push({"title":x,"data":("element."+x)});
        //   });
        // }
        // });
        // this.onSearchSumbit.emit(this.formGroupArr);
        this.searchGridData = [];
        this.gridsource = [];
        this.httpClient.get("assets/config/search-data-mockup.json").subscribe(data => {
            this.gridsource.push(data);
            this.gridsource.filter(x => {
                x.filter(y => {
                    if ("studio" == y.pagename) {
                        this.searchGridData = y.data;
                        console.log("this.searchGridData= y", this.searchGridData);
                    }
                    ;
                });
            });
        });
    }
    createFormControl() {
        let frmgrp = {};
        this.formdata.forEach(x => {
            if (x.type == "select") {
                this.httpClient.get(x.api).subscribe(data => {
                    x.apidata = data;
                });
                frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl();
            }
            else {
                if (x.required == "required") {
                    frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
                }
                else {
                    frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('');
                }
            }
        });
        this.searchform = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup(frmgrp);
    }
    openSnackBar(errormsg) {
        this._snackBar.open(errormsg, 'X', {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 4000,
            panelClass: ['warn-snackbar']
        });
    }
    addnewrecord(url) {
        let tempUrl;
        tempUrl = this.route.replace('search', 'add');
        console.log(tempUrl);
        this._router.navigate([tempUrl.toString()]);
    }
}
RdapSharedConfigSearchComponent.ɵfac = function RdapSharedConfigSearchComponent_Factory(t) { return new (t || RdapSharedConfigSearchComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_5__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_7__.MatSnackBar)); };
RdapSharedConfigSearchComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: RdapSharedConfigSearchComponent, selectors: [["app-rdap-shared-config-search"]], viewQuery: function RdapSharedConfigSearchComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_angular_material_sort__WEBPACK_IMPORTED_MODULE_8__.MatSort, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_9__.MatPaginator, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.sort = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, outputs: { onSearchSumbit: "onSearchSumbit" }, decls: 6, vars: 3, consts: [[2, "margin-bottom", "2%"], [1, "col-lg-12"], ["action", "", 3, "formGroup", 4, "ngIf"], ["style", "text-align: left;", 4, "ngIf"], [4, "ngIf"], ["action", "", 3, "formGroup"], [1, "row"], ["class", "col-lg-4 form-group", 4, "ngFor", "ngForOf"], [1, "col-lg-4", "form-group"], ["class", "form-group", 4, "ngIf"], ["style", "color: red;", "class", "compulsary-mark", 4, "ngIf"], ["type", "text", "matInput", "", 3, "name", "formControlName", "disabled"], [1, "compulsary-mark", 2, "color", "red"], ["matInput", "", "cdkTextareaAutosize", "", "cdkAutosizeMinRows", "1", "cdkAutosizeMaxRows", "5", 3, "name", "formControlName", "placeholder"], ["autosize", "cdkTextareaAutosize"], [1, "form-group"], ["appendTo", "body", "required", "", 3, "labelForId", "items", "placeholder", "bindLabel", "formControlName", "clearable", "virtualScroll", "multiple"], ["ng-option-tmp", ""], [2, "text-align", "left"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white", 3, "disabled", "ngClass", "click"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white"], [3, "searchGridData", "appString"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white", 3, "click"], ["mat-raised-button", "", "style", "width: 20%;background-color: #300c46;color:white", 3, "click", 4, "ngIf"], ["mat-raised-button", "", 2, "width", "20%", "background-color", "#300c46", "color", "white", 3, "click"]], template: function RdapSharedConfigSearchComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSearchComponent_form_3_Template, 3, 2, "form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, RdapSharedConfigSearchComponent_mat_card_actions_4_Template, 5, 5, "mat-card-actions", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, RdapSharedConfigSearchComponent_mat_card_5_Template, 12, 3, "mat-card", 4);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.searchform);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.searchform);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.searchGridData);
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_12__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__.MatError, _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_13__.CdkTextareaAutosize, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_14__.NgSelectComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_14__["ɵf"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardActions, _angular_material_button__WEBPACK_IMPORTED_MODULE_15__.MatButton, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgClass, _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardTitle, _rdap_shared_igx_grid_search_result_rdap_shared_igx_grid_search_result_component__WEBPACK_IMPORTED_MODULE_0__.RdapSharedIgxGridSearchResultComponent], styles: [".mat-form-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .mat-form-field .mat-input-element {\n  margin-top: 0.9em !important;\n}\n\n.mat-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\ntable[_ngcontent-%COMP%] {\n  width: 100%;\n  table-layout: fixed;\n}\n\nth[_ngcontent-%COMP%], td[_ngcontent-%COMP%] {\n  overflow: hidden;\n  width: 100%;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\nth[_ngcontent-%COMP%] {\n  background-color: #9e9e9a;\n  color: white;\n  font-weight: 500;\n  font-size: 14px;\n  height: 50%;\n  text-align: center;\n}\n\ntd[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\ntr.mat-header-row[_ngcontent-%COMP%] {\n  height: 30px;\n}\n\n.cdk-overlay-container[_ngcontent-%COMP%] {\n  position: fixed !important;\n  z-index: 10000 !important;\n}\n\n.errorbtn[_ngcontent-%COMP%] {\n  width: 10%;\n  background-color: #c2c2c2 !important;\n  color: black;\n}\n\n.successbtn[_ngcontent-%COMP%] {\n  width: 10%;\n  background-color: #300c46;\n  color: white;\n}\n\n[_nghost-%COMP%]  .igx-paginator__select {\n  display: none !important;\n}\n\n[_nghost-%COMP%]     .igx-grid__td {\n  font-size: 0.7rem;\n  min-height: 0.8rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtc2hhcmVkLWNvbmZpZy1zZWFyY2guY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0FBQ0o7O0FBR0k7RUFDSSw0QkFBQTtBQUFSOztBQUlBO0VBQ0ksZUFBQTtBQURKOztBQUlBO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FBREo7O0FBSUU7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBREo7O0FBR0U7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFBTjs7QUFFRTtFQUNFLGVBQUE7QUFDSjs7QUFDRTtFQUNFLFlBQUE7QUFFSjs7QUFBQTtFQUNFLDBCQUFBO0VBQ0EseUJBQUE7QUFHRjs7QUFBQTtFQUNFLFVBQUE7RUFBVyxvQ0FBQTtFQUFxQyxZQUFBO0FBS2xEOztBQUhBO0VBQ0UsVUFBQTtFQUFXLHlCQUFBO0VBQTBCLFlBQUE7QUFRdkM7O0FBTEE7RUFDRSx3QkFBQTtBQVFGOztBQUZNO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtBQUtWIiwiZmlsZSI6InJkYXAtc2hhcmVkLWNvbmZpZy1zZWFyY2guY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWF0LWZvcm0tZmllbGR7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkIHtcclxuICAgIC5tYXQtaW5wdXQtZWxlbWVudCB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMC45ZW0gIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLm1hdC1jYXJkLXRpdGxle1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG50YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRhYmxlLWxheW91dDogZml4ZWQ7XHJcbiAgfVxyXG4gIFxyXG4gIHRoLCB0ZCB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgfVxyXG4gIHRoe1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOnJnYigxNTgsIDE1OCwgMTU0KTs7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBoZWlnaHQ6IDUwJTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuICB0ZHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICB9XHJcbiAgdHIubWF0LWhlYWRlci1yb3cge1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG59XHJcbi5jZGstb3ZlcmxheS1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xyXG4gIHotaW5kZXg6IDEwMDAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5lcnJvcmJ0bntcclxuICB3aWR0aDogMTAlO2JhY2tncm91bmQtY29sb3I6ICNjMmMyYzIgIWltcG9ydGFudDtjb2xvcjpyZ2IoMCwgMCwgMClcclxufVxyXG4uc3VjY2Vzc2J0bntcclxuICB3aWR0aDogMTAlO2JhY2tncm91bmQtY29sb3I6ICMzMDBjNDY7Y29sb3I6d2hpdGUgXHJcbn1cclxuXHJcbjpob3N0OjpuZy1kZWVwIC5pZ3gtcGFnaW5hdG9yX19zZWxlY3R7XHJcbiAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuOmhvc3Qge1xyXG4gIDo6bmctZGVlcCB7XHJcbiAgICAgIC5pZ3gtZ3JpZF9fdGQge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAwLjdyZW07XHJcbiAgICAgICAgICBtaW4taGVpZ2h0OiAwLjhyZW07XHJcbiAgfVxyXG59XHJcbn0iXX0= */"] });


/***/ }),

/***/ 46448:
/*!**********************************************************************************************************************************************!*\
  !*** ./src/app/package/core/core-shared-components/rdap-shared-config-setuptable-addedit/rdap-shared-config-setuptable-addedit.component.ts ***!
  \**********************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RdapSharedConfigSetuptableAddeditComponent": function() { return /* binding */ RdapSharedConfigSetuptableAddeditComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/sort */ 11494);
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/paginator */ 99692);
/* harmony import */ var src_app_package_modules_rdap_shared_components_utils_shared_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/package/modules/rdap-shared-components/utils/shared-utils */ 87366);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/snack-bar */ 77001);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/form-field */ 98295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/input */ 83166);
/* harmony import */ var _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/text-field */ 96109);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-select/ng-select */ 86640);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/button */ 51095);


















function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_1_mat_error_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.label, " required");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "input", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_1_mat_error_5_Template, 2, 1, "mat-error", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.label, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("id", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("name", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r3.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r4.checkError(item_r3.formcontrolname, item_r3.required));
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_2_mat_error_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.label, " required");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "textarea", 14, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_2_mat_error_6_Template, 2, 1, "mat-error", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.label, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("id", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("name", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r3.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("placeholder", item_r3.placeholder);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r5.checkError(item_r3.formcontrolname, item_r3.required));
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_ng_select_3_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0);
} if (rf & 2) {
    const item_r17 = ctx.item;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r17.name, " ");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_ng_select_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ng-select", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_ng_select_3_ng_template_1_Template, 1, 1, "ng-template", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("id", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("placeholder", item_r3.placeholder);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("bindLabel", item_r3.bindname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("formControlName", item_r3.formcontrolname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("items", item_r3.apidata)("clearable", item_r3.clearable)("virtualScroll", item_r3.virtualScroll)("multiple", item_r3.multiple);
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_checkbox_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-checkbox", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("id", item_r3.controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.label, " ");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_label_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("id", item_r3.innercontrol[0].controlname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", item_r3.innercontrol[0].label, "");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_1_Template, 6, 6, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_form_field_2_Template, 7, 6, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_ng_select_3_Template, 2, 8, "ng-select", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_mat_checkbox_4_Template, 2, 2, "mat-checkbox", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_label_5_Template, 2, 2, "label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r3.type == "text");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r3.type == "textarea");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r3.type == "select");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r3.type == "checkbox");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r3.innercontrol && item_r3.innercontrol[0].type == "label");
} }
function RdapSharedConfigSetuptableAddeditComponent_form_3_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "form", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function RdapSharedConfigSetuptableAddeditComponent_form_3_Template_form_ngSubmit_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r22); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r21.submit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, RdapSharedConfigSetuptableAddeditComponent_form_3_div_2_Template, 6, 5, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx_r0.searchform);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.formdata);
} }
const _c0 = function (a0, a1) { return { "errorbtn": a0, "successbtn": a1 }; };
function RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_button_1_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r26); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r25.submit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", !ctx_r23.searchform.valid)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](2, _c0, !ctx_r23.searchform.valid, ctx_r23.searchform.valid));
} }
function RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_button_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Delete");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-card-actions", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_button_1_Template, 2, 5, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_button_4_Template, 2, 0, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.transactionFlag == "A" || ctx_r1.transactionFlag == "E");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.transactionFlag == "D");
} }
class RdapSharedConfigSetuptableAddeditComponent {
    constructor(httpClient, location, router, fb, _snackBar) {
        this.httpClient = httpClient;
        this.fb = fb;
        this._snackBar = _snackBar;
        this.horizontalPosition = 'right';
        this.verticalPosition = 'top';
        this.onSearchSumbit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.timeOut = 500;
        this.transactionFlag = "A";
        this.checkError = (controlName, errorName) => {
            return this.searchform.controls[controlName].hasError(errorName);
        };
        router.events.subscribe((val) => {
            if (location.path() != '') {
                this.route = location.path();
                if (this.route.match("add").length) {
                    this.transactionFlag = "A";
                }
                else if (this.route.match("edit").length) {
                    this.transactionFlag = "E";
                }
                else if (this.route.match("view").length) {
                    this.transactionFlag = "v";
                }
                this.routeName = this.route.split('/')[this.route.split('/').length - 1];
            }
            else {
                this.route = 'Home';
            }
        });
        this.httpClient.get("assets/config/masterScreenCommonAddEdit.json").subscribe(data => {
            this.configdata = data;
            this.getFormData();
        });
    }
    // ngAfterViewInit() {
    //   this.dataSource.sort = this.sort;
    //   this.dataSource.paginator = this.paginator;
    // }
    ngOnInit() {
    }
    getFormData() {
        this.formSelectApiData = [];
        if (this.route.match("channeltype") && this.route.match("channeltype").length) {
            this.formName = "channeltypeSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.channeltype;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("cabinets") && this.route.match("cabinets").length) {
            this.formName = "cabinetsSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.cabinets;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("channel") && this.route.match("channel").length) {
            this.formName = "channelSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.channel;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devefforttype") && this.route.match("devefforttype").length) {
            this.formName = "devefforttypeSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devefforttype;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devcomplexity") && this.route.match("devcomplexity").length > 0) {
            this.formName = "devcomplexitySearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devcomplexity;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("gravity") && this.route.match("gravity").length > 0) {
            this.formName = "gravitySearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.gravity;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devtype1") && this.route.match("devtype1").length > 0) {
            this.formName = "devtype1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devtype1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("devtype2") && this.route.match("devtype2").length > 0) {
            this.formName = "devtype2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.devtype2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("market") && this.route.match("market").length > 0) {
            this.formName = "marketSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.market;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("studio") && this.route.match("studio").length > 0) {
            this.formName = "studioSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.studio;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("quarter") && this.route.match("quarter").length > 0) {
            this.formName = "quarterSearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.quarter;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status1") && this.route.match("status1").length > 0) {
            this.formName = "status1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status2") && this.route.match("status2").length > 0) {
            this.formName = "status2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("status3") && this.route.match("status3").length > 0) {
            this.formName = "status3SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.status3;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat1") && this.route.match("prodcat1").length > 0) {
            this.formName = "prodcat1SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat1;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat2") && this.route.match("prodcat2").length > 0) {
            this.formName = "prodcat2SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat2;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
        else if (this.route.match("prodcat3") && this.route.match("prodcat3").length > 0) {
            this.formName = "prodcat3SearchForm";
            this.configdata[0].master.filter(x => {
                this.routedata = x.prodcat3;
                this.formdata = this.routedata[0].fieldprop;
                this.griddata = this.routedata[0].api[0];
            });
            this.createFormControl();
        }
    }
    submit() {
        this.formGroupArr = [];
        this.gridsource = [];
        this.displayedColumns = [];
        this.loopGridContent = [];
        this.displayedColumns.push("select");
        let count = 1;
        let errorFlag = false;
        if (this.searchform.invalid) {
            return;
        }
        this.formdata.forEach((x, index) => {
            if ((0,src_app_package_modules_rdap_shared_components_utils_shared_utils__WEBPACK_IMPORTED_MODULE_0__.isEmptyString)(this.searchform.get(x.formcontrolname).value)) {
                document.getElementById(x.formcontrolname).focus();
                setTimeout(() => {
                    this.openSnackBar("Enter " + x.label + " !!");
                    errorFlag = true;
                    //this.searchform.get(x.formcontrolname).validator
                }, count * (this.timeOut + 500));
                count++;
            }
            this.formGroupArr.push({ key: x.formcontrolname, value: this.searchform.get(x.formcontrolname).value });
        });
        this.httpClient.get(this.griddata.api).subscribe(data => {
            this.gridsource.push(data);
            this.gridsource.filter(x => {
                x.filter(y => {
                    if (y.pagename == this.routeName) {
                        this.tempFilterData = y.data;
                    }
                    ;
                });
            });
            if (this.tempFilterData) {
                Object.keys(this.tempFilterData[0]).forEach(x => {
                    this.displayedColumns.push(x);
                    this.loopGridContent.push({ "title": x, "data": ("element." + x) });
                });
            }
        });
        //this.onSearchSumbit.emit(this.formGroupArr);
    }
    createFormControl() {
        let frmgrp = {};
        this.formdata.forEach(x => {
            if (x.type == "select") {
                this.httpClient.get(x.api).subscribe(data => {
                    x.apidata = data;
                });
                frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl();
            }
            else {
                if (x.required == "required") {
                    frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required);
                }
                else {
                    frmgrp[x.formcontrolname] = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl('');
                }
            }
        });
        this.searchform = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup(frmgrp);
    }
    openSnackBar(errormsg) {
        this._snackBar.open(errormsg, 'X', {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 1000,
            panelClass: ['warn-snackbar']
        });
    }
}
RdapSharedConfigSetuptableAddeditComponent.ɵfac = function RdapSharedConfigSetuptableAddeditComponent_Factory(t) { return new (t || RdapSharedConfigSetuptableAddeditComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_6__.MatSnackBar)); };
RdapSharedConfigSetuptableAddeditComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: RdapSharedConfigSetuptableAddeditComponent, selectors: [["app-rdap-shared-config-setuptable-addedit"]], viewQuery: function RdapSharedConfigSetuptableAddeditComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__.MatSort, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__.MatPaginator, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.sort = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, outputs: { onSearchSumbit: "onSearchSumbit" }, decls: 5, vars: 2, consts: [[2, "margin-bottom", "2%"], [1, "col-lg-12"], ["action", "", 3, "formGroup", "ngSubmit", 4, "ngIf"], ["style", "text-align: left;", 4, "ngIf"], ["action", "", 3, "formGroup", "ngSubmit"], [1, "row"], ["class", "col-lg-4 form-group", 4, "ngFor", "ngForOf"], [1, "col-lg-4", "form-group"], [4, "ngIf"], ["appendTo", "body", "required", "", 3, "id", "items", "placeholder", "bindLabel", "formControlName", "clearable", "virtualScroll", "multiple", 4, "ngIf"], ["labelPosition", "after", 3, "id", 4, "ngIf"], ["style", "background-color: rgb(161, 161, 161);color: rgb(0, 0, 0);", 3, "id", 4, "ngIf"], [1, "compulsary-mark"], ["type", "text", "matInput", "", 3, "id", "name", "formControlName", "disabled"], ["matInput", "", "cdkTextareaAutosize", "", "cdkAutosizeMinRows", "1", "cdkAutosizeMaxRows", "5", 3, "id", "name", "formControlName", "placeholder"], ["autosize", "cdkTextareaAutosize"], ["appendTo", "body", "required", "", 3, "id", "items", "placeholder", "bindLabel", "formControlName", "clearable", "virtualScroll", "multiple"], ["ng-option-tmp", ""], ["labelPosition", "after", 3, "id"], [2, "background-color", "rgb(161, 161, 161)", "color", "rgb(0, 0, 0)", 3, "id"], [2, "text-align", "left"], ["mat-raised-button", "", 3, "disabled", "ngClass", "click", 4, "ngIf"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white"], ["mat-raised-button", "", "style", "width: 10%;background-color: #300c46;color:white", 4, "ngIf"], ["mat-raised-button", "", 3, "disabled", "ngClass", "click"]], template: function RdapSharedConfigSetuptableAddeditComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, RdapSharedConfigSetuptableAddeditComponent_form_3_Template, 3, 2, "form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, RdapSharedConfigSetuptableAddeditComponent_mat_card_actions_4_Template, 5, 2, "mat-card-actions", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.searchform);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.searchform);
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_9__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_9__.MatCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_11__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__.MatError, _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_12__.CdkTextareaAutosize, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__.NgSelectComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.RequiredValidator, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__["ɵf"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckbox, _angular_material_card__WEBPACK_IMPORTED_MODULE_9__.MatCardActions, _angular_material_button__WEBPACK_IMPORTED_MODULE_15__.MatButton, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgClass], styles: [".mat-form-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .mat-form-field .mat-input-element {\n  margin-top: 0.9em !important;\n}\n\n.mat-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\ntable[_ngcontent-%COMP%] {\n  width: 100%;\n  table-layout: fixed;\n}\n\nth[_ngcontent-%COMP%], td[_ngcontent-%COMP%] {\n  overflow: hidden;\n  width: 100%;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\nth[_ngcontent-%COMP%] {\n  background-color: #9e9e9a;\n  color: white;\n  font-weight: 500;\n  font-size: 14px;\n  height: 50%;\n  text-align: center;\n}\n\ntd[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\ntr.mat-header-row[_ngcontent-%COMP%] {\n  height: 30px;\n}\n\n.cdk-overlay-container[_ngcontent-%COMP%] {\n  position: fixed !important;\n  z-index: 10000 !important;\n}\n\n.errorbtn[_ngcontent-%COMP%] {\n  width: 10%;\n  background-color: #c2c2c2 !important;\n  color: black;\n}\n\n.successbtn[_ngcontent-%COMP%] {\n  width: 10%;\n  background-color: #300c46;\n  color: white;\n}\n\n.mat-checkbox[_ngcontent-%COMP%] {\n  margin-top: 9%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtc2hhcmVkLWNvbmZpZy1zZXR1cHRhYmxlLWFkZGVkaXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0FBQ0o7O0FBR0k7RUFDSSw0QkFBQTtBQUFSOztBQUlBO0VBQ0ksZUFBQTtBQURKOztBQUlBO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FBREo7O0FBSUU7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBREo7O0FBR0U7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFBTjs7QUFFRTtFQUNFLGVBQUE7QUFDSjs7QUFDRTtFQUNFLFlBQUE7QUFFSjs7QUFBQTtFQUNFLDBCQUFBO0VBQ0EseUJBQUE7QUFHRjs7QUFEQTtFQUNFLFVBQUE7RUFBVyxvQ0FBQTtFQUFxQyxZQUFBO0FBTWxEOztBQUpBO0VBQ0UsVUFBQTtFQUFXLHlCQUFBO0VBQTBCLFlBQUE7QUFTdkM7O0FBUEE7RUFDRSxjQUFBO0FBVUYiLCJmaWxlIjoicmRhcC1zaGFyZWQtY29uZmlnLXNldHVwdGFibGUtYWRkZWRpdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZm9ybS1maWVsZHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG46aG9zdDo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQge1xyXG4gICAgLm1hdC1pbnB1dC1lbGVtZW50IHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAwLjllbSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4ubWF0LWNhcmQtdGl0bGV7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZDtcclxuICB9XHJcbiAgXHJcbiAgdGgsIHRkIHtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICB9XHJcbiAgdGh7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDE1OCwgMTU4LCAxNTQpOztcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGhlaWdodDogNTAlO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gIHRke1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxuICB0ci5tYXQtaGVhZGVyLXJvdyB7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbn1cclxuLmNkay1vdmVybGF5LWNvbnRhaW5lciB7XHJcbiAgcG9zaXRpb246IGZpeGVkICFpbXBvcnRhbnQ7XHJcbiAgei1pbmRleDogMTAwMDAgIWltcG9ydGFudDtcclxufVxyXG4uZXJyb3JidG57XHJcbiAgd2lkdGg6IDEwJTtiYWNrZ3JvdW5kLWNvbG9yOiAjYzJjMmMyICFpbXBvcnRhbnQ7Y29sb3I6cmdiKDAsIDAsIDApXHJcbn1cclxuLnN1Y2Nlc3NidG57XHJcbiAgd2lkdGg6IDEwJTtiYWNrZ3JvdW5kLWNvbG9yOiAjMzAwYzQ2O2NvbG9yOndoaXRlIFxyXG59XHJcbi5tYXQtY2hlY2tib3h7XHJcbiAgbWFyZ2luLXRvcDogOSU7XHJcbn1cclxuXHJcblxyXG4iXX0= */"] });


/***/ }),

/***/ 78076:
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/package/core/core-shared-components/rdap-shared-igx-grid-search-result/rdap-shared-igx-grid-search-result.component.ts ***!
  \****************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RdapSharedIgxGridSearchResultComponent": function() { return /* binding */ RdapSharedIgxGridSearchResultComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var igniteui_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! igniteui-angular */ 84951);




const _c0 = ["grid1"];
function RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_2_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const val_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](val_r7);
} }
function RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_2_ng_template_0_Template, 2, 1, "ng-template", 8);
} }
function RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "igx-column", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_2_Template, 1, 0, undefined, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const c_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("sortable", true)("width", c_r3.width)("filterable", true)("field", c_r3.field)("header", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 7, c_r3.title))("dataType", c_r3.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", c_r3.field == "document");
} }
function RdapSharedIgxGridSearchResultComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "igx-grid", 2, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "igx-paginator", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, RdapSharedIgxGridSearchResultComponent_div_0_igx_column_4_Template, 3, 9, "igx-column", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("data", ctx_r0.data)("paging", true)("perPage", 10)("rowHeight", 25)("allowFiltering", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("perPage", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.columndata);
} }
class RdapSharedIgxGridSearchResultComponent {
    constructor(httpClient, cdr) {
        this.httpClient = httpClient;
        this.cdr = cdr;
        this.searchText = '';
        this.caseSensitive = false;
        this.exactMatch = false;
        this.appString = [];
        this.httpClient.get("assets/config/app-string.json").subscribe(y => {
            this.appString = y;
        });
    }
    ngOnInit() {
        // this.gridDataLoad();   
    }
    ngOnChanges() {
        if (this.searchGridData.length > 0) {
            this.gridDataLoad();
        }
        //this.getDoctypeSearchFormData(this.selbasedoctype);
    }
    ngAfterViewInit() {
        //this.grid.selectColumns(['City', 'PostalCode']);
        //this.cdr.detectChanges();
    }
    gridDataLoad() {
        this.columndata = [];
        this.loopGridContent = [];
        this.data = this.searchGridData;
        Object.keys(this.searchGridData[0]).forEach(x => {
            this.appString.filter(g => {
                if (x == g.modelname) {
                    this.columndata.push({ field: x, title: g.title, width: "150px", height: "10px", type: "string", pinned: true });
                }
            });
            this.loopGridContent.push({ "title": x, "data": ("element." + x) });
        });
    }
    clearSearch() {
        this.searchText = '';
        this.grid.clearSearch();
    }
    searchKeyDown(ev) {
        if (ev.key === 'Enter' || ev.key === 'ArrowDown' || ev.key === 'ArrowRight') {
            ev.preventDefault();
            this.grid.findNext(this.searchText, this.caseSensitive, this.exactMatch);
        }
        else if (ev.key === 'ArrowUp' || ev.key === 'ArrowLeft') {
            ev.preventDefault();
            this.grid.findPrev(this.searchText, this.caseSensitive, this.exactMatch);
        }
    }
    updateSearch() {
        this.caseSensitive = !this.caseSensitive;
        this.grid.findNext(this.searchText, this.caseSensitive, this.exactMatch);
    }
    updateExactSearch() {
        this.exactMatch = !this.exactMatch;
        this.grid.findNext(this.searchText, this.caseSensitive, this.exactMatch);
    }
}
RdapSharedIgxGridSearchResultComponent.ɵfac = function RdapSharedIgxGridSearchResultComponent_Factory(t) { return new (t || RdapSharedIgxGridSearchResultComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef)); };
RdapSharedIgxGridSearchResultComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: RdapSharedIgxGridSearchResultComponent, selectors: [["app-rdap-shared-igx-grid-search-result"]], viewQuery: function RdapSharedIgxGridSearchResultComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 7);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.grid = _t.first);
    } }, inputs: { searchGridData: "searchGridData", appString: "appString" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 1, vars: 1, consts: [["class", "grid__wrapper", 4, "ngIf"], [1, "grid__wrapper"], ["igxPreventDocumentScroll", "", "id", "grid1", "height", "auto", "width", "100%", 3, "data", "paging", "perPage", "rowHeight", "allowFiltering"], ["grid1", ""], [3, "perPage"], [3, "sortable", "width", "filterable", "field", "header", "dataType", 4, "ngFor", "ngForOf"], [3, "sortable", "width", "filterable", "field", "header", "dataType"], [4, "ngIf"], ["igxCell", ""]], template: function RdapSharedIgxGridSearchResultComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, RdapSharedIgxGridSearchResultComponent_div_0_Template, 5, 7, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.searchGridData.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, igniteui_angular__WEBPACK_IMPORTED_MODULE_3__.IgxGridComponent, igniteui_angular__WEBPACK_IMPORTED_MODULE_3__.IgxPaginatorComponent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, igniteui_angular__WEBPACK_IMPORTED_MODULE_3__.IgxColumnComponent, igniteui_angular__WEBPACK_IMPORTED_MODULE_3__.IgxCellTemplateDirective], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.TitleCasePipe], styles: ["[_nghost-%COMP%]  .igx-paginator__select {\n  display: none !important;\n}\n\n[_nghost-%COMP%]     .igx-grid__td {\n  font-size: 0.7rem;\n  min-height: 0.8rem;\n}\n\n[_nghost-%COMP%]  .igx-page-size {\n  display: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJkYXAtc2hhcmVkLWlneC1ncmlkLXNlYXJjaC1yZXN1bHQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx3QkFBQTtBQUNKOztBQUtRO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtBQUZaOztBQU9BO0VBQ0ksd0JBQUE7QUFKSiIsImZpbGUiOiJyZGFwLXNoYXJlZC1pZ3gtZ3JpZC1zZWFyY2gtcmVzdWx0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXAgLmlneC1wYWdpbmF0b3JfX3NlbGVjdHtcclxuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbjpob3N0IHtcclxuICAgIDo6bmctZGVlcCB7XHJcbiAgICAgICAgLmlneC1ncmlkX190ZCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMC43cmVtO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiAwLjhyZW07XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG46aG9zdDo6bmctZGVlcCAuaWd4LXBhZ2Utc2l6ZXtcclxuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcclxufSJdfQ== */"] });


/***/ }),

/***/ 37713:
/*!*********************************************!*\
  !*** ./src/app/package/core/core.module.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreModule": function() { return /* binding */ CoreModule; }
/* harmony export */ });
/* harmony import */ var _core_core_routing__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/core-routing */ 99020);
/* harmony import */ var _login_login_footer_login_footer_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login-footer/login-footer.component */ 5497);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home/home.component */ 73964);
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./header/header.component */ 26990);
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./footer/footer.component */ 21707);
/* harmony import */ var _main_menu_bar_main_menu_bar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./main-menu-bar/main-menu-bar.component */ 93164);
/* harmony import */ var _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../mat-modules/material.module */ 54364);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _launcher_launcher_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./launcher/launcher.component */ 24466);
/* harmony import */ var _side_menu_bar_side_menu_bar_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./side-menu-bar/side-menu-bar.component */ 23414);
/* harmony import */ var _d_board_d_board_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./d-board/d-board.component */ 67584);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/grid-list */ 4929);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/menu */ 33935);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/cdk/layout */ 65072);
/* harmony import */ var _components_datatable_datatable_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/datatable/datatable.component */ 27497);
/* harmony import */ var _core_shared_components_rdap_shared_config_search_rdap_shared_config_search_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./core-shared-components/rdap-shared-config-search/rdap-shared-config-search.component */ 70482);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core-shared-components/rdap-shared-breadcrumb/rdap-shared-breadcrumb.component */ 16971);
/* harmony import */ var _core_shared_components_rdap_shared_config_setuptable_addedit_rdap_shared_config_setuptable_addedit_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./core-shared-components/rdap-shared-config-setuptable-addedit/rdap-shared-config-setuptable-addedit.component */ 46448);
/* harmony import */ var _core_shared_components_rdap_shared_igx_grid_search_result_rdap_shared_igx_grid_search_result_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./core-shared-components/rdap-shared-igx-grid-search-result/rdap-shared-igx-grid-search-result.component */ 78076);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/router */ 39895);

























class CoreModule {
}
CoreModule.ɵfac = function CoreModule_Factory(t) { return new (t || CoreModule)(); };
CoreModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineNgModule"]({ type: CoreModule });
CoreModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule,
            _core_core_routing__WEBPACK_IMPORTED_MODULE_0__.CoreRoutes,
            _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_6__.MaterialModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule,
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__.MatGridListModule,
            _angular_material_card__WEBPACK_IMPORTED_MODULE_19__.MatCardModule,
            _angular_material_menu__WEBPACK_IMPORTED_MODULE_20__.MatMenuModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_21__.MatIconModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_22__.MatButtonModule,
            _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_23__.LayoutModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsetNgModuleScope"](CoreModule, { declarations: [_login_login_footer_login_footer_component__WEBPACK_IMPORTED_MODULE_1__.LoginFooterComponent,
        _home_home_component__WEBPACK_IMPORTED_MODULE_2__.HomeComponent,
        _header_header_component__WEBPACK_IMPORTED_MODULE_3__.HeaderComponent,
        _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterComponent,
        _main_menu_bar_main_menu_bar_component__WEBPACK_IMPORTED_MODULE_5__.MainMenuBarComponent,
        _launcher_launcher_component__WEBPACK_IMPORTED_MODULE_7__.LauncherComponent,
        _side_menu_bar_side_menu_bar_component__WEBPACK_IMPORTED_MODULE_8__.SideMenuBarComponent,
        _d_board_d_board_component__WEBPACK_IMPORTED_MODULE_9__.DBoardComponent,
        _components_datatable_datatable_component__WEBPACK_IMPORTED_MODULE_10__.DatatableComponent,
        _core_shared_components_rdap_shared_config_search_rdap_shared_config_search_component__WEBPACK_IMPORTED_MODULE_11__.RdapSharedConfigSearchComponent,
        _core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__.RdapSharedBreadcrumbComponent,
        _core_shared_components_rdap_shared_config_setuptable_addedit_rdap_shared_config_setuptable_addedit_component__WEBPACK_IMPORTED_MODULE_13__.RdapSharedConfigSetuptableAddeditComponent,
        _core_shared_components_rdap_shared_igx_grid_search_result_rdap_shared_igx_grid_search_result_component__WEBPACK_IMPORTED_MODULE_14__.RdapSharedIgxGridSearchResultComponent], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_24__.RouterModule, _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_6__.MaterialModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule,
        _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__.MatGridListModule,
        _angular_material_card__WEBPACK_IMPORTED_MODULE_19__.MatCardModule,
        _angular_material_menu__WEBPACK_IMPORTED_MODULE_20__.MatMenuModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_21__.MatIconModule,
        _angular_material_button__WEBPACK_IMPORTED_MODULE_22__.MatButtonModule,
        _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_23__.LayoutModule], exports: [_login_login_footer_login_footer_component__WEBPACK_IMPORTED_MODULE_1__.LoginFooterComponent,
        _side_menu_bar_side_menu_bar_component__WEBPACK_IMPORTED_MODULE_8__.SideMenuBarComponent,
        _core_shared_components_rdap_shared_config_search_rdap_shared_config_search_component__WEBPACK_IMPORTED_MODULE_11__.RdapSharedConfigSearchComponent,
        _core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__.RdapSharedBreadcrumbComponent,
        _core_shared_components_rdap_shared_config_setuptable_addedit_rdap_shared_config_setuptable_addedit_component__WEBPACK_IMPORTED_MODULE_13__.RdapSharedConfigSetuptableAddeditComponent,
        _core_shared_components_rdap_shared_igx_grid_search_result_rdap_shared_igx_grid_search_result_component__WEBPACK_IMPORTED_MODULE_14__.RdapSharedIgxGridSearchResultComponent] }); })();


/***/ }),

/***/ 67584:
/*!***********************************************************!*\
  !*** ./src/app/package/core/d-board/d-board.component.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DBoardComponent": function() { return /* binding */ DBoardComponent; }
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 88002);
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/layout */ 65072);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core-shared-components/rdap-shared-breadcrumb/rdap-shared-breadcrumb.component */ 16971);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/grid-list */ 4929);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/menu */ 33935);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var angular_google_charts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angular-google-charts */ 30159);











class DBoardComponent {
    constructor(breakpointObserver) {
        this.breakpointObserver = breakpointObserver;
        /** Based on the screen size, switch from standard to one column per row */
        this.cards = this.breakpointObserver.observe(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_1__.Breakpoints.Handset).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(({ matches }) => {
            if (matches) {
                return [
                    { title: 'Card 1', cols: 1, rows: 1 },
                    { title: 'Card 2', cols: 1, rows: 1 },
                    { title: 'Card 3', cols: 1, rows: 1 },
                    { title: 'Card 4', cols: 1, rows: 1 }
                ];
            }
            return [
                { title: 'Card 1', cols: 2, rows: 1 },
                { title: 'Card 2', cols: 1, rows: 1 },
                { title: 'Card 3', cols: 1, rows: 2 },
                { title: 'Card 4', cols: 1, rows: 1 }
            ];
        }));
        this.chartData = {
            type: 'ComboChart',
            data: [
                ["Jan", 500, 600, 700],
                ["Feb", 800, 900, 1000],
                ["Mar", 400, 600, 500],
                ["Apr", 600, 500, 800],
                ["May", 400, 300, 200],
                ["Jun", 750, 700, 700],
                ["Jul", 800, 710, 700],
                ["Aug", 810, 720, 700],
                ["Sep", 820, 730, 1000],
                ["Oct", 900, 840, 700],
                ["Nov", 910, 850, 100],
                ["Dec", 920, 890, 0]
            ],
            columnNames: ["Month", "AP", "IP", "RE"],
            options: {
                hAxis: {
                    title: 'Month'
                },
                vAxis: {
                    title: 'Count'
                },
                colors: ['#79e2f2', '#ff8f73', '#ffe380']
            },
            seriesType: 'bars',
            series: { 2: { type: 'line' } },
            width: 350,
            height: 250
        };
        this.pieChartData = {
            type: 'PieChart',
            data: [
                ["AP", 500, 600, 700],
                ["IP", 800, 900, 1000],
                ["RE", 400, 600, 500],
            ],
            columnNames: ["Month", "AP", "IP", "RE"],
            options: {
                slices: {
                    1: { offset: 0.2 },
                    3: { offset: 0.3 }
                },
                colors: ['#79e2f2', '#ff8f73', '#ffe380']
            },
            width: 350,
            height: 250
        };
        this.columnChartData = {
            type: 'ColumnChart',
            data: [
                ["Jan", 500, 600, 700],
                ["Feb", 800, 900, 1000],
                ["Mar", 400, 600, 500],
                ["Apr", 600, 500, 800],
                ["May", 400, 300, 200],
                ["Jun", 750, 700, 700],
                ["Jul", 800, 710, 700],
                ["Aug", 810, 720, 700],
                ["Sep", 820, 730, 1000],
                ["Oct", 900, 840, 700],
                ["Nov", 910, 850, 100],
                ["Dec", 920, 890, 0]
            ],
            columnNames: ["Month", "AP", "IP", "RE"],
            options: {
                hAxis: {
                    title: 'Month'
                },
                vAxis: {
                    title: 'Count'
                },
                colors: ['#79e2f2', '#ff8f73', '#ffe380']
            },
            width: 850,
            height: 250
        };
    }
}
DBoardComponent.ɵfac = function DBoardComponent_Factory(t) { return new (t || DBoardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_1__.BreakpointObserver)); };
DBoardComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: DBoardComponent, selectors: [["app-d-board"]], decls: 52, vars: 27, consts: [[1, "grid-container"], ["cols", "2", "rowHeight", "350px"], [3, "colspan", "rowspan"], [1, "dashboard-card"], ["mat-icon-button", "", "aria-label", "Toggle menu", 1, "more-button", 3, "matMenuTriggerFor"], ["xPosition", "before"], ["menu", "matMenu"], ["mat-menu-item", ""], [1, "dashboard-card-content"], [3, "type", "data", "columns", "options", "width", "height"]], template: function DBoardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "app-rdap-shared-breadcrumb");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "mat-grid-list", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "mat-grid-tile", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "mat-card", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, " PIN Request ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, "more_vert");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "mat-menu", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14, "Expand");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16, "Remove");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "mat-card-content", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](18, "google-chart", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "mat-grid-list", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "mat-grid-tile", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "mat-card", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, " Change Request ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, "more_vert");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "mat-menu", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](31, "Expand");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, "Remove");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "mat-card-content", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](35, "google-chart", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "mat-grid-tile", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "mat-card", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](40, " Delay Notification ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43, "more_vert");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "mat-menu", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47, "Expand");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](48, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](49, "Remove");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](50, "mat-card-content", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](51, "google-chart", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("colspan", 2)("rowspan", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("matMenuTriggerFor", _r0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("type", ctx.columnChartData.type)("data", ctx.columnChartData.data)("columns", ctx.columnChartData.columnNames)("options", ctx.columnChartData.options)("width", ctx.columnChartData.width)("height", ctx.columnChartData.height);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("colspan", 1)("rowspan", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("matMenuTriggerFor", _r0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("type", ctx.pieChartData.type)("data", ctx.pieChartData.data)("columns", ctx.pieChartData.columnNames)("options", ctx.pieChartData.options)("width", ctx.pieChartData.width)("height", ctx.pieChartData.height);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("colspan", 1)("rowspan", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("matMenuTriggerFor", _r0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("type", ctx.chartData.type)("data", ctx.chartData.data)("columns", ctx.chartData.columnNames)("options", ctx.chartData.options)("width", ctx.chartData.width)("height", ctx.chartData.height);
    } }, directives: [_core_shared_components_rdap_shared_breadcrumb_rdap_shared_breadcrumb_component__WEBPACK_IMPORTED_MODULE_0__.RdapSharedBreadcrumbComponent, _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_4__.MatGridList, _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_4__.MatGridTile, _angular_material_card__WEBPACK_IMPORTED_MODULE_5__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_5__.MatCardHeader, _angular_material_card__WEBPACK_IMPORTED_MODULE_5__.MatCardTitle, _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButton, _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__.MatMenuTrigger, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__.MatIcon, _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__.MatMenu, _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__.MatMenuItem, _angular_material_card__WEBPACK_IMPORTED_MODULE_5__.MatCardContent, angular_google_charts__WEBPACK_IMPORTED_MODULE_9__.GoogleChartComponent], styles: [".grid-container[_ngcontent-%COMP%] {\n  margin: 20px;\n  min-height: calc(100vh - 100px);\n}\n\n.dashboard-card[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 15px;\n  left: 15px;\n  right: 15px;\n  bottom: 15px;\n}\n\n.more-button[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 5px;\n  right: 10px;\n}\n\n.dashboard-card-content[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImQtYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsK0JBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7QUFDRiIsImZpbGUiOiJkLWJvYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmdyaWQtY29udGFpbmVyIHtcclxuICBtYXJnaW46IDIwcHg7XHJcbiAgbWluLWhlaWdodDpjYWxjKDEwMHZoIC0gMTAwcHgpOyBcclxufVxyXG5cclxuLmRhc2hib2FyZC1jYXJkIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxNXB4O1xyXG4gIGxlZnQ6IDE1cHg7XHJcbiAgcmlnaHQ6IDE1cHg7XHJcbiAgYm90dG9tOiAxNXB4O1xyXG59XHJcblxyXG4ubW9yZS1idXR0b24ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDVweDtcclxuICByaWdodDogMTBweDtcclxufVxyXG5cclxuLmRhc2hib2FyZC1jYXJkLWNvbnRlbnQge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 21707:
/*!*********************************************************!*\
  !*** ./src/app/package/core/footer/footer.component.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterComponent": function() { return /* binding */ FooterComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/toolbar */ 12522);


class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(); };
FooterComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FooterComponent, selectors: [["app-footer"]], decls: 4, vars: 0, consts: [[1, "bottom-text"], [1, "col-lg-12"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-toolbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " \u00A9 2021 Aristocrat, Inc. All rights reserved. All logos and brands are property of their respective owners. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    } }, directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_1__.MatToolbar], styles: [".bottom-text[_ngcontent-%COMP%] {\n  background-color: white;\n  color: #300c46;\n  font-size: 12px;\n  bottom: 5px;\n  text-align: center;\n  height: 3%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvb3Rlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHVCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBQ0oiLCJmaWxlIjoiZm9vdGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJvdHRvbS10ZXh0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6aHNsKDAsIDAlLCAxMDAlKTtcclxuICAgIGNvbG9yOiMzMDBjNDY7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBib3R0b206IDVweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGhlaWdodDogMyU7XHJcbn0iXX0= */"] });


/***/ }),

/***/ 26990:
/*!*********************************************************!*\
  !*** ./src/app/package/core/header/header.component.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": function() { return /* binding */ HeaderComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/toolbar */ 12522);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 98295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/input */ 83166);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _main_menu_bar_main_menu_bar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../main-menu-bar/main-menu-bar.component */ 93164);







class HeaderComponent {
    constructor() { }
    ngOnInit() {
    }
}
HeaderComponent.ɵfac = function HeaderComponent_Factory(t) { return new (t || HeaderComponent)(); };
HeaderComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderComponent, selectors: [["app-header"]], inputs: { sidenav: "sidenav" }, decls: 18, vars: 1, consts: [[2, "position", "fixed", "width", "100%", "padding-right", "8%", "padding-left", "8%", "z-index", "9999"], [1, "main-header"], [1, "col-lg-3"], ["routerLink", "/main/launcher"], ["c-portalfooter_portalfooter", "", "src", "https://qa1-aristocrat.cs117.force.com/CustomerPortal/resource/1611730979000/PortalAssets/Logo/Aristocrat_Gaming_Logo_white.png", "alt", "Aristocrat", 1, "footerImage"], [1, "col-lg-5", 2, "text-align", "center"], ["c-portalfooter_portalfooter", "", "src", "../../../../assets/images/menu/Top-Banner_Gold-Stacks-88-removebg-preview (2).png", "alt", "Aristocrat", 1, "headerImage"], [1, "col-lg-3", 2, "justify-content", "right"], [1, "form-group"], ["appearance", "outline", 2, "width", "100%"], ["matPrefix", "", 1, "material-icons", "md-24"], ["matInput", "", "placeholder", "search", "name", "search", "required", "", "autocomplete", "off"], [1, "col-lg-1"], ["mat-icon-button", "", 2, "float", "right", "color", "white"], [1, "material-icons-round"], [3, "sidenav"]], template: function HeaderComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "mat-form-field", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "search");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "span", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, " account_circle ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](17, "app-main-menu-bar", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("sidenav", ctx.sidenav);
    } }, directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__.MatToolbar, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLinkWithHref, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatPrefix, _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInput, _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButton, _main_menu_bar_main_menu_bar_component__WEBPACK_IMPORTED_MODULE_0__.MainMenuBarComponent], styles: [".rdaplogo[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  height: 2.5rem;\n  display: block;\n  margin-left: 0;\n  margin-right: auto;\n  margin-top: -0.8rem;\n}\n.rdaptext[_ngcontent-%COMP%] {\n  height: 2.5rem;\n  display: block;\n  margin-left: 0;\n  margin-right: auto;\n  margin-top: -1.3rem;\n  position: relative;\n}\n.rdapcharimg[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  height: 2.5rem;\n  display: block;\n  margin-left: auto;\n  margin-right: 0;\n}\n.main-header[_ngcontent-%COMP%] {\n  background: linear-gradient(to right, #300c46 0%, #300c46 100%);\n}\n.footerImage[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  height: 2.5rem;\n  display: block;\n  margin-left: 0;\n  margin-right: auto;\n}\n.headerImage[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  height: 3.5rem;\n}\n.mat-form-field-appearance-outline[_ngcontent-%COMP%]   .mat-form-field-outline[_ngcontent-%COMP%] {\n  color: white !important;\n  background-color: white;\n  border-radius: 3px !important;\n}\n.material-icons.md-24[_ngcontent-%COMP%] {\n  font-size: 24px !important;\n}\n[_nghost-%COMP%]  .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: white !important;\n  background-color: white;\n  border-radius: 3px;\n}\na[_ngcontent-%COMP%] {\n  color: #ffffff;\n  text-decoration: none;\n}\n[_nghost-%COMP%] .mat-form-field-wrapper {\n  padding-bottom: 0em !important;\n}\n[_nghost-%COMP%] .mat-form-field-appearance-outline .mat-form-field-infix {\n  padding: 0 0 0 0;\n}\n[_nghost-%COMP%] .mat-form-field {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhc3NldHNcXGNzc1xcc2Nzc1xccmRhcC12YXJpYWJsZXMuc2NzcyIsImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUE2R0EsdUJBQUE7QUMzR0E7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBQUY7QUFHQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUFGO0FBR0E7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQUFGO0FBS0E7RUFDRSwrREFBQTtBQUZGO0FBSUE7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQURKO0FBR0E7RUFDSSxjQUFBO0FBQUo7QUFJQTtFQUNJLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSw2QkFBQTtBQURKO0FBR0U7RUFBd0IsMEJBQUE7QUFDMUI7QUFDQTtFQUNFLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUVGO0FBQUE7RUFDSSxjQUFBO0VBQ0EscUJBQUE7QUFHSjtBQUFBO0VBQ0ssOEJBQUE7QUFHTDtBQUFDO0VBQ0MsZ0JBQUE7QUFHRjtBQUFBO0VBQ0UsZUFBQTtBQUdGIiwiZmlsZSI6ImhlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiRjbG91ZGxleGJsdWU6ICMwMDRlNzU7XHJcbiRoZWFkZXJibHVlOiAjMTljMWQ5O1xyXG4kd2hpdGUtY29sb3I6ICNmZmY7XHJcbiRibGFjazogIzAwMDAwMDtcclxuJGRhcmtncmF5OiAjMzQzYzNkO1xyXG4kbGluazogIzI5OTljOTtcclxuJGFjdGl2ZWJsdWU6ICMyYTgzYjE7XHJcbiRncmlkaGVhZGVyOiAjZTllZWYwO1xyXG4kZGVmYXVsdGJsdWU6ICMyMDk3YzY7XHJcbiRncmF5OiAjMzMzMzMzO1xyXG4kYWxpY2VCbHVlOiAjZjBmOGZmO1xyXG4kdmVsYW5jaWE6ICNkOTUzNGY7XHJcbiRwYWNpZmljYmx1ZTogI2YxZjdmOTtcclxuJGJ0bmhvdmVyLWRlZmF1bHRiZzogI2U2ZTZlNjtcclxuJHBsYWNlaG9sZGVyY29sb3I6ICM5OTk5OTk7XHJcbiRncmFncmFkaWVudDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMTZiZGRmLCAjMjhkNmJmKTtcclxuJGNsb3VkbGV4LWxpZ2h0LWdyZWVuOiAjZGZmMGQ4O1xyXG4kY2xvdWRsZXgtc3VjY2Vzcy1ncmVlbjogIzNjNzYzZDtcclxuJGdyeWRhcms6ICM1NTU1NTU7XHJcbiRmb3JtbGFiZWw6ICMzNDNlNDU7XHJcbiR0ZXh0LWNlbnRlcjogY2VudGVyO1xyXG4kdGV4dHJpZ2h0OiByaWdodDtcclxuJHRleHRsZWZ0OiBsZWZ0O1xyXG4kc25hY2tiYXItZXJyb3I6ICNmMmRlZGU7XHJcbiRzbmFja2Jhci1lcnJvci10ZXh0OiAjYTk0NDQyO1xyXG4kYnJlYWRjcnVtZC1jb2xvcjogIzI0MjQyNDtcclxuJGxpZ2h0Z3JheTogI2NjY2NjYztcclxuJGJvcmRlcmdyYXk6ICNmNWY1ZjU7XHJcbiRsYXVuY2hlcmRyb3Bkb3duOiAjMzAzMDMwO1xyXG4kbGF1bmNoZXJ0aXRsZTogIzQ4NDg0ODtcclxuJGJvcmRlcjogI2U1ZTVlNTtcclxuJHRhYnNhY3RpdmU6ICMyYTk4Yzc7XHJcbiRzbmFja2Jhci1zY3VjZXNzYm9yZGVyOiAjZDZlOWM2O1xyXG4kd2F0c25ld2JvcmRlcjogIzI5ODNiODtcclxuJG1vdmVsZWZ0OiBsZWZ0O1xyXG4kbW92ZXJpZ2h0OiByaWdodDtcclxuJHNlbGVjdGJvcmRlcjogIzk0OTQ5NDtcclxuJHRhZ2Nsb3NlOiAjMmE4M2IxO1xyXG4kYm9yZGVycmlnaHQ6ICNkM2Q5ZGU7XHJcbiRib3JkZXJib3R0b206ICNkM2Q5ZGU7XHJcbiRkb2xsb3JiZzogI2FkZDE4MTtcclxuJGRvbGxvcmJvcmRlcjogIzhmYjg1ZDtcclxuJGRvbGxvcmxpZ2h0Ymc6ICNiN2RhOGM7XHJcbiRtYXJrZXRiZzogI2UzZjFmNjtcclxuJHRleHR3YXJuaW5nOiAjZjQ4MjY3O1xyXG4kY2Fyb3VzZWxub3JtYWw6ICNjNWQ3ZTE7XHJcbiRjYXJvdXNlbGFjdGl2ZTogIzAyNGQ3NDtcclxuJHNoYXJlcG9wdXBhdXRvYmc6ICNmNWZhZmQ7XHJcbiRzaGFyZXBvcHVwdHh0OiAjNDk1YzY4O1xyXG4kYm9yZGVyOiAjZDNkOWRlO1xyXG4kdGFiYWN0aXZlYmc6ICNlOWY0Zjk7XHJcbiRyZXBvcnRoZWFkZXJ0aXRsZTogIzAwNGQ3NDtcclxuJHJlcG9ydGxlZnR0YWJzOiAjZGFkOWQ5O1xyXG4kaW5wdXR2YWx1ZTogI2U0ZTRlNDtcclxuJGNpcmNsZWJvcmRlcjogI2FhYjdiZDtcclxuJGRhdGVsaW5lYmc6ICNlZWVlZWU7XHJcbiRncmF5dHh0OiAjNzY3MzczO1xyXG4kdG9nZ2xlZ3JlZW46ICM3NGJiMmY7XHJcbiRldmVudHNzZWxlY3RlZHVzZXI6ICNmNGY0ZjQ7XHJcbiRldmVudHNzZWxlY3RlZHVzZXJicjogI2RkZGRkZDtcclxuJGV2ZW50c2NpcmNsZWFjdGl2ZTogI2ZmZjllNTtcclxuJGV2ZW50c2NpcmNsZTogI2Y0ODI2NztcclxuJGV2ZW50c2FjdGl2ZTogIzY3Nzg4NTtcclxuJGV2ZW50c2NpcmNsZWFjdGl2ZWRhcms6ICNmZmY5ZTU7XHJcbiRldmVudHNjaXJjbGVkYXJrOiAjNjc3ODg1O1xyXG4kZXZlbnRzYWN0aXZlZGFyazogIzY3Nzg4NTtcclxuJGV2ZW50c2NpcmNsZWFjdGl2ZWdyZWVuOiAjZmZmOWU1O1xyXG4kZXZlbnRzY2lyY2xlZ3JlZW46ICNhZGQxODE7XHJcbiRldmVudHNhY3RpdmVncmVlbjogIzY3Nzg4NTtcclxuJG1taW50YWtlbGVmdGFjdGl2ZTogI2YzZTJhYztcclxuJG1tcmlnaHRjb250ZW50OiAjZjNmNmY3O1xyXG4kZG93bmxvYWRoZXJlaG92ZXI6ICM1ZDliZmI7XHJcbiR0b2dnbGVidG46ICNlMGUwZTA7XHJcbiR0YXNrLXNlbGVjdC1ncmVlbjogIzVjYjg1YztcclxuJGJveC1zaGFkb3c6ICMyYTk4ZDI7XHJcbiRkYXJraGVhZGVyOiAjY2NjY2NjO1xyXG4kbGlnaHQtZ3JheWlzaDogI2VmZjNmNjtcclxuJGxpZ2h0LWdyYXlib3JkZXI6ICNmZmY0Y2E7XHJcbiRsaWdodC1ncmF5Ym9yZGVyc2hhZGU6ICNmOGViZWI7XHJcbiRib3gtc2hhZG93LWdyYXk6ICM5ZTllOWU7XHJcbiRib3gtc2hhZG93LWdyYXk6ICM5ZTllOWU7XHJcbiRjYWxlbmRlcnRvZGF5OiAjZmNmOGUzO1xyXG4kc2Nyb2xiYXJjb2xvcjogIzMxMzEzMTtcclxuJG5nZHJvcGRvd24taXRlbXM6ICMzODc1ZDc7XHJcbiR1YmVyLWxvY2F0aW9uLWFkZHJlc3M6ICM2YzdlOTE7XHJcbiR1YmVyLWRyb3Bkb3duLWFjdGl2ZWJnOiAjZmZmOGU2O1xyXG4kdml2aWRPcmFuZ2U6ICNmMzhmMTg7XHJcbiRib3JkZXItY29sb3JncmF5OiAjY2FjNGM0O1xyXG4kdWJlci10cmlwY2FuY2VsbGVkOiAjZTU0OTM3O1xyXG4kdWJlci10cmlwY29tcGxldGVkOiAjMDBjODUzO1xyXG4kdHJpcC10aXRsZTogIzZjN2U5MTtcclxuJGFjY29yZGlhbi1mb290ZXI6ICNlOWVlZmU7XHJcbiR1YmVyLXRyaXBwcm9ncmVzczogI2YzOTUwMDtcclxuJGxpZ2h0LWdyYXljb2xvcjogI2UyZTJlMjtcclxuJHN1YnNjcmlwdGlvbi1yZWQ6ICNmMzBlM2Y7XHJcbiRsaWdodGdyYXlib3JkZXJjb2xvcjogI2FhYTtcclxuJG9saXZlY29sb3VyOiAjZWRmMmUyO1xyXG4kYmdibHVlY29sb3I6ICMxNmJkZGY7XHJcbiRsaWdodGdyYXltaXhib3JkZXI6ICNmNmY4Zjk7XHJcbiRsaWdodC1ncmF5aXNoY29sb3JtaXg6ICM3YTgwODU7XHJcbiRzb2Z0Qmx1ZTogIzUxYTdmOTtcclxuJHJlZDogI2ZmMDAwMDtcclxuJGxpZ2h0LWJvcmRlcmdyYXk6ICMzZTNlM2U7XHJcbiRwcmludC1ub3JtYWx0eHRjb2xvcjogIzIxMjUyOTtcclxuJGJsdWVncmF5OiAjNjZhZmU5O1xyXG4kbGF1bmNocGFkLXR4dC1kaXZpZGVyOiAjOTA5MDkyO1xyXG4kbGF1bmNocGFkLWJsb2Nrcy1ob3ZlcjogI2YwZjRmNTtcclxuJGJvZHktc2Nyb2xsOiAjNjY2NjY2O1xyXG5cclxuLyogU2NyZWVuIEJyZWFrcG9pbnRzICovXHJcbiRsYXJnZS1zY3JlZW46IDE2MDBweDtcclxuJG1lZGl1bS1zY3JlZW46IDk5MnB4O1xyXG4iLCJAaW1wb3J0IFwic3JjL2Fzc2V0cy9jc3Mvc2Nzcy9yZGFwLXZhcmlhYmxlcy5zY3NzXCI7XHJcblxyXG4ucmRhcGxvZ29bYy1wb3J0YWxGb290ZXJfcG9ydGFsRm9vdGVyXSB7XHJcbiAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIG1hcmdpbi10b3A6IC0wLjhyZW07XHJcbn1cclxuXHJcbi5yZGFwdGV4dCB7XHJcbiAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIG1hcmdpbi10b3A6IC0xLjNyZW07XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4ucmRhcGNoYXJpbWdbYy1wb3J0YWxGb290ZXJfcG9ydGFsRm9vdGVyXSB7XHJcbiAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXJpZ2h0OiAwO1xyXG59XHJcbi8vIDo6bmctZGVlcC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUgLm1hdC1mb3JtLWZpZWxkLWluZml4e1xyXG4vLyAgICAgcGFkZGluZzowIDAgMCAwO1xyXG4vLyB9XHJcbi5tYWluLWhlYWRlciB7XHJcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMzAwYzQ2IDAlLCAjMzAwYzQ2IDEwMCUpO1xyXG59XHJcbi5mb290ZXJJbWFnZVtjLXBvcnRhbEZvb3Rlcl9wb3J0YWxGb290ZXJdIHtcclxuICAgIGhlaWdodDogMi41cmVtO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxufVxyXG4uaGVhZGVySW1hZ2VbYy1wb3J0YWxGb290ZXJfcG9ydGFsRm9vdGVyXXtcclxuICAgIGhlaWdodDogMy41cmVtO1xyXG59XHJcblxyXG5cclxuLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2Utb3V0bGluZSAubWF0LWZvcm0tZmllbGQtb3V0bGluZSB7XHJcbiAgICBjb2xvcjogd2hpdGUhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHggIWltcG9ydGFudDtcclxufVxyXG4gIC5tYXRlcmlhbC1pY29ucy5tZC0yNCB7IGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50OyB9XHJcblxyXG46aG9zdDo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lIHtcclxuICBjb2xvcjogd2hpdGUhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDNweDtcclxufVxyXG5hIHtcclxuICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG46aG9zdDo6bmctZGVlcC5tYXQtZm9ybS1maWVsZC13cmFwcGVyIHtcclxuICAgICBwYWRkaW5nLWJvdHRvbTogMGVtICFpbXBvcnRhbnQ7XHJcbiB9XHJcblxyXG4gOmhvc3Q6Om5nLWRlZXAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1pbmZpeCB7XHJcbiAgcGFkZGluZzogMCAwIDAgMDtcclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAubWF0LWZvcm0tZmllbGQge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufSJdfQ== */"] });


/***/ }),

/***/ 73964:
/*!*****************************************************!*\
  !*** ./src/app/package/core/home/home.component.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": function() { return /* binding */ HomeComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _side_menu_bar_sidenav_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../side-menu-bar/sidenav.service */ 14295);
/* harmony import */ var _okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../okta-auth/okta-auth-service */ 59841);
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../header/header.component */ 26990);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/sidenav */ 94935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _side_menu_bar_side_menu_bar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../side-menu-bar/side-menu-bar.component */ 23414);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../footer/footer.component */ 21707);









const _c0 = function (a0) { return { "height": a0 }; };
class HomeComponent {
    constructor(_sidenavService, okta) {
        this._sidenavService = _sidenavService;
        this.okta = okta;
        this.clientheight = document.documentElement.clientHeight;
        this._sidenavService.sideNavState$.subscribe(res => {
            console.log(res);
            this.onSideNavChange = res;
        });
    }
    ngOnInit() {
    }
    sideNavClose() {
        this._sidenavService.sideNavState$.subscribe(res => {
            console.log("sideNavClose", res);
            this.onSideNavChange = res;
        });
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_side_menu_bar_sidenav_service__WEBPACK_IMPORTED_MODULE_0__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_1__.OktaAuthService)); };
HomeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["app-home"]], decls: 9, vars: 4, consts: [[3, "sidenav"], [1, "sidenav-container", "side_nav_shadow", 2, "margin-left", "8%", "margin-right", "8%", 3, "ngStyle"], ["mode", "side", 1, "side_nav_shadow", 2, "padding-top", "0%", "color", "white", "background-color", "#300c46"], ["leftSidenav", ""], [1, "main_content", 3, "mouseover"]], template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "mat-sidenav-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "mat-sidenav", 2, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "app-side-menu-bar");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "mat-sidenav-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("mouseover", function HomeComponent_Template_div_mouseover_6_listener() { return ctx.sideNavClose(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](8, "app-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("sidenav", _r0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](2, _c0, ctx.clientheight + "px"));
    } }, directives: [_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavContainer, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenav, _side_menu_bar_side_menu_bar_component__WEBPACK_IMPORTED_MODULE_3__.SideMenuBarComponent, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavContent, _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterOutlet, _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterComponent], styles: ["html[_ngcontent-%COMP%], body[_ngcontent-%COMP%] {\n  height: 100%;\n}\n\np[_ngcontent-%COMP%] {\n  font-family: Lato;\n}\n\n.main_content[_ngcontent-%COMP%] {\n  width: 100%;\n  background: #efefef;\n  padding-top: 9%;\n  overflow: auto;\n}\n\n.scrollbar-thin[_ngcontent-%COMP%] {\n  scrollbar-width: thin;\n  overflow-y: scroll;\n}\n\n.side_nav_shadow[_ngcontent-%COMP%] {\n  box-shadow: 0px 0px 15px 5px #adadad;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBR0E7RUFDSSxpQkFBQTtBQUFKOztBQUdFO0VBQ0UsV0FBQTtFQUVBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFESjs7QUFNRTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7QUFISjs7QUFLQTtFQUdFLG9DQUFBO0FBRkYiLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImh0bWwsIGJvZHkge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICAvL292ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcclxufVxyXG5cclxucCB7XHJcbiAgICBmb250LWZhbWlseTogTGF0bztcclxuICB9XHJcbiAgXHJcbiAgLm1haW5fY29udGVudCB7XHJcbiAgICB3aWR0aDoxMDAlOyBcclxuICAgIC8vaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMTAwJSk7IFxyXG4gICAgYmFja2dyb3VuZDogI2VmZWZlZjtcclxuICAgIHBhZGRpbmctdG9wOiA5JTtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gIH1cclxuICAvLyA6aG9zdDo6bmctZGVlcC5tYXQtZHJhd2VyLWNvbnRlbnR7XHJcbiAgLy8gIG1hcmdpbi10b3A6IC00JTtcclxuICAvLyB9XHJcbiAgLnNjcm9sbGJhci10aGluIHtcclxuICAgIHNjcm9sbGJhci13aWR0aDogdGhpbjtcclxuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcclxufVxyXG4uc2lkZV9uYXZfc2hhZG93e1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMHB4IDBweCAxNXB4IDVweCByZ2JhKDE3MywxNzMsMTczLDEpO1xyXG4gIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCAxNXB4IDVweCByZ2JhKDE3MywxNzMsMTczLDEpO1xyXG4gIGJveC1zaGFkb3c6IDBweCAwcHggMTVweCA1cHggcmdiYSgxNzMsMTczLDE3MywxKTsgIFxyXG59XHJcbiJdfQ== */"] });


/***/ }),

/***/ 24466:
/*!*************************************************************!*\
  !*** ./src/app/package/core/launcher/launcher.component.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LauncherComponent": function() { return /* binding */ LauncherComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../okta-auth/okta-auth-service */ 59841);


class LauncherComponent {
    constructor(okta) {
        this.okta = okta;
    }
    ngOnInit() {
        this.okta.handleAuthentication();
    }
}
LauncherComponent.ɵfac = function LauncherComponent_Factory(t) { return new (t || LauncherComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__.OktaAuthService)); };
LauncherComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: LauncherComponent, selectors: [["app-launcher"]], decls: 3, vars: 0, consts: [[1, "col-lg-12", 2, "height", "100%", "background-color", "white"]], template: function LauncherComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "ARISTOCRAT");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsYXVuY2hlci5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 5497:
/*!***************************************************************************!*\
  !*** ./src/app/package/core/login/login-footer/login-footer.component.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginFooterComponent": function() { return /* binding */ LoginFooterComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);

class LoginFooterComponent {
    constructor() { }
    ngOnInit() {
    }
}
LoginFooterComponent.ɵfac = function LoginFooterComponent_Factory(t) { return new (t || LoginFooterComponent)(); };
LoginFooterComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginFooterComponent, selectors: [["app-login-footer"]], decls: 19, vars: 0, consts: [[1, "row"], ["c-portalfooter_portalfooter", "", 1, "footerWrap"], ["c-portalfooter_portalfooter", "", 1, "footerTop"], ["c-portalfooter_portalfooter", "", 1, "loginBg"], ["c-portalfooter_portalfooter", "", 1, "container"], ["c-portalfooter_portalfooter", "", 1, "slds-align_absolute-center"], ["c-portalfooter_portalfooter", "", "href", "https://www.aristocrat.com/privacy/", "target", "_blank"], ["c-portalfooter_portalfooter", "", 1, "footerLinkPipe"], ["c-portalfooter_portalfooter", "", "href", "https://theviportal.com/termsofuse", "target", "_blank"], ["c-portalfooter_portalfooter", "", "href", "https://theviportal.com/ip-notice", "target", "_blank"], ["c-portalfooter_portalfooter", "", 1, "slds-col", "slds-large-size_1-of-2", "slds-medium-size_1-of-2", "slds-small-size_1-of-1", 2, "padding-top", "1.5rem"], ["c-portalfooter_portalfooter", "", "src", "https://qa1-aristocrat.cs117.force.com/CustomerPortal/resource/1611730979000/PortalAssets/Logo/Aristocrat_Gaming_Logo_white.png", "alt", "Aristocrat", 1, "footerImage"]], template: function LoginFooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "a", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Privacy Policy");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "\u00A0|\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Terms of Use");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "\u00A0|\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "a", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "IP Notice");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".slds-align_absolute-center[_ngcontent-%COMP%], .slds-align--absolute-center[_ngcontent-%COMP%] {\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-pack: center;\n      justify-content: center;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  -ms-flex-align: center;\n      align-items: center;\n  margin: auto;\n}\n\n.footerLinkPipe[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  display: inline-block;\n  font-size: 14px;\n  margin-bottom: 5px;\n  padding: 0 5px;\n}\n\na[c-portalFooter_portalFooter][_ngcontent-%COMP%], a[_ngcontent-%COMP%]:hover[c-portalFooter_portalFooter] {\n  color: #fff;\n  fill: #fff;\n  font-size: 14px;\n  display: inline-block;\n  margin-bottom: 5px;\n}\n\n.contentBg[c-portalFooter_portalFooter][_ngcontent-%COMP%], .loginBg[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  color: #fff;\n  padding: 25px 0;\n}\n\n.slds-col[_ngcontent-%COMP%], [class*=slds-col_padded][_ngcontent-%COMP%], [class*=slds-col--padded][_ngcontent-%COMP%] {\n  -ms-flex: 1 1 auto;\n      flex: 1 1 auto;\n}\n\n.footerImage[c-portalFooter_portalFooter][_ngcontent-%COMP%] {\n  height: 2.5rem;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\naudio[_ngcontent-%COMP%], canvas[_ngcontent-%COMP%], iframe[_ngcontent-%COMP%], img[_ngcontent-%COMP%], svg[_ngcontent-%COMP%], video[_ngcontent-%COMP%] {\n  vertical-align: middle;\n}\n\nimg[_ngcontent-%COMP%] {\n  border: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLWZvb3Rlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHFCQUFBO01BQUEsdUJBQUE7RUFDQSwwQkFBQTtNQUFBLHFCQUFBO0VBQ0Esc0JBQUE7TUFBQSxtQkFBQTtFQUNBLFlBQUE7QUFDSjs7QUFDQTtFQUNJLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUVKOztBQUFBO0VBQ0ksV0FBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQUdKOztBQURBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFJSjs7QUFGQTtFQUNJLGtCQUFBO01BQUEsY0FBQTtBQUtKOztBQUhBO0VBQ0ksY0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBTUo7O0FBSEE7RUFDSSxzQkFBQTtBQU1KOztBQUhBO0VBQ0ksU0FBQTtBQU1KIiwiZmlsZSI6ImxvZ2luLWZvb3Rlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zbGRzLWFsaWduX2Fic29sdXRlLWNlbnRlciwgLnNsZHMtYWxpZ24tLWFic29sdXRlLWNlbnRlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5mb290ZXJMaW5rUGlwZVtjLXBvcnRhbEZvb3Rlcl9wb3J0YWxGb290ZXJdIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgIHBhZGRpbmc6IDAgNXB4O1xyXG59XHJcbmFbYy1wb3J0YWxGb290ZXJfcG9ydGFsRm9vdGVyXSwgYTpob3ZlcltjLXBvcnRhbEZvb3Rlcl9wb3J0YWxGb290ZXJdIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZmlsbDogI2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG4uY29udGVudEJnW2MtcG9ydGFsRm9vdGVyX3BvcnRhbEZvb3Rlcl0sIC5sb2dpbkJnW2MtcG9ydGFsRm9vdGVyX3BvcnRhbEZvb3Rlcl0ge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAyNXB4IDA7XHJcbn1cclxuLnNsZHMtY29sLCBbY2xhc3MqPXNsZHMtY29sX3BhZGRlZF0sIFtjbGFzcyo9c2xkcy1jb2wtLXBhZGRlZF0ge1xyXG4gICAgZmxleDogMSAxIGF1dG87XHJcbn1cclxuLmZvb3RlckltYWdlW2MtcG9ydGFsRm9vdGVyX3BvcnRhbEZvb3Rlcl0ge1xyXG4gICAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG5hdWRpbywgY2FudmFzLCBpZnJhbWUsIGltZywgc3ZnLCB2aWRlbyB7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG5pbWcge1xyXG4gICAgYm9yZGVyOiAwO1xyXG59Il19 */"] });


/***/ }),

/***/ 11005:
/*!*******************************************************!*\
  !*** ./src/app/package/core/login/login.component.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": function() { return /* binding */ LoginComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _core_utils_shared_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/utils/shared-utils */ 32418);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ 22238);
/* harmony import */ var _core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/okta-auth/okta-auth-service */ 59841);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/form-field */ 98295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/input */ 83166);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _login_footer_login_footer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login-footer/login-footer.component */ 5497);











const _c0 = function () { return ["/fpwd"]; };
class LoginComponent {
    constructor(fb, router, route, dialog, okta) {
        this.fb = fb;
        this.router = router;
        this.route = route;
        this.dialog = dialog;
        this.okta = okta;
        this.isAuthenticated = false;
    }
    ngOnInit() {
        this.okta.handleAuthentication();
        // this.createFormGroup();
    }
    createFormGroup() {
        this.loginForm = this.fb.group({
            username: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            password: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]
        });
    }
    loginData() {
        console.log('loginForm', this.loginForm.value.username);
        console.log('loginForm', this.loginForm.value.password);
        if ((0,_core_utils_shared_utils__WEBPACK_IMPORTED_MODULE_0__.isNotEmptyString)(this.loginForm.value.username) && (0,_core_utils_shared_utils__WEBPACK_IMPORTED_MODULE_0__.isNotEmptyString)(this.loginForm.value.password)) {
            this.router.navigate(["main/launcher"]);
        }
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__.MatDialog), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_1__.OktaAuthService)); };
LoginComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 35, vars: 3, consts: [[1, "salesforceIdentityLoginBody2", 2, "background-color", "#34276c"], [1, "row"], [1, "content", "col-sm-8", "col-md-6", "col-lg-3", "mx-auto"], [1, "form-group", 2, "margin-bottom", "5%"], ["src", "../../../../assets/images/login/Customer_Community_Logo.png", "title", "Logo", "alt", "aristocrat logo", 1, "img-responsive", 2, "display", "block", "max-width", "85%", "height", "auto"], ["src", "https://www.aristocrat.com/wp-content/uploads/2019/11/aristocrat-269.svg", "title", "Logo", "alt", "aristocrat logo", 1, "img-responsive", 2, "width", "100%", "display", "block", "position", "relative", "max-width", "100%", "height", "auto", "margin-top", "-8%"], [2, "margin-top", "5px"], [2, "font-size", "30px", "font-family", "'lato', 'arial', sans-serif", "color", "white"], [1, "form-group"], [2, "margin-top", "5px", "text-align", "center"], [2, "font-size", "30px", "font-family", "'lato', 'arial', sans-serif", "color", "#e50f7c", "font-weight", "bolder"], ["action", "", 3, "formGroup"], ["appearance", "outline", 2, "width", "100%"], ["matPrefix", "", 1, "material-icons", "md-24"], ["matInput", "", "placeholder", "Enter Username", "name", "username", "formControlName", "username", "required", "", "autocomplete", "off"], ["matInput", "", "type", "password", "placeholder", "Enter Password", "name", "password", "formControlName", "password", "required", "", "autocomplete", "off"], [1, "margin-bottom", "10px", "mt-3"], ["mat-raised-button", "", "color", "accent", "type", "submit", "value", "LOGIN", 1, "btn", "btn-primary", 2, "width", "100% !important", "height", "50px", "color", "#ffffff", "font-family", "'lato', 'arial', sans-serif", 3, "click"], [1, "forget-pass-main", 2, "font-size", "14px", "font-family", "'lato', 'arial', sans-serif", ";margin-top", "5px"], ["target", "_blank", "routerLinkActive", "router-link-active", 1, "forget-pass", "forget-pass-new", 3, "routerLink"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "bring joy to life");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "RDAP");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "mat-form-field", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "person");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](20, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "mat-form-field", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "lock");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](27, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_29_listener() { return ctx.loginData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, " Log in ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "a", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33, "Forgot your password?");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](34, "app-login-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.loginForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](2, _c0));
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_7__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_7__.MatPrefix, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_7__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_8__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_material_button__WEBPACK_IMPORTED_MODULE_9__.MatButton, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLinkWithHref, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLinkActive, _login_footer_login_footer_component__WEBPACK_IMPORTED_MODULE_2__.LoginFooterComponent], styles: [".logmaindiv[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  width: 25em;\n  height: 18em;\n  margin-top: -9em;\n  \n  margin-left: -15em;\n  \n  \n  \n}\n\n.parent[_ngcontent-%COMP%] {\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-pack: center;\n      justify-content: center;\n  -ms-flex-align: center;\n      align-items: center;\n  -ms-flex-direction: column;\n      flex-direction: column;\n}\n\n.salesforceIdentityLoginBody2[_ngcontent-%COMP%] {\n  padding-top: 1%;\n  padding-bottom: 5%;\n  font-family: \"lato\", \"arial\", sans-serif;\n}\n\n.loginImgOne[_ngcontent-%COMP%] {\n  margin-top: 3%;\n  margin-bottom: 3%;\n}\n\n.row[_ngcontent-%COMP%] {\n  --bs-gutter-x: -1.5rem;\n  --bs-gutter-y: 0;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  margin-top: calc(var(--bs-gutter-y) * -1);\n  margin-right: calc(var(--bs-gutter-x)/ -2);\n  margin-left: calc(var(--bs-gutter-x)/ -2);\n}\n\n[_nghost-%COMP%]  .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: white !important;\n  background-color: white;\n  border-radius: 3px;\n}\n\na[_ngcontent-%COMP%] {\n  color: #ffffff;\n  text-decoration: none;\n}\n\n[_nghost-%COMP%] .mat-form-field-wrapper {\n  padding-bottom: 0em !important;\n}\n\n[_nghost-%COMP%] .mat-form-field {\n  max-height: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUFrQiw4Q0FBQTtFQUNsQixrQkFBQTtFQUFvQiw2Q0FBQTtFQUNwQiwwQkFBQTtFQUNBLDRCQUFBO0FBR0o7O0FBQUE7RUFDSSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxxQkFBQTtNQUFBLHVCQUFBO0VBQ0Esc0JBQUE7TUFBQSxtQkFBQTtFQUNBLDBCQUFBO01BQUEsc0JBQUE7QUFHSjs7QUFBQztFQUNHLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHdDQUFBO0FBR0o7O0FBQUU7RUFDRSxjQUFBO0VBQWUsaUJBQUE7QUFJbkI7O0FBREM7RUFDRyxzQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EsbUJBQUE7TUFBQSxlQUFBO0VBQ0EseUNBQUE7RUFDQSwwQ0FBQTtFQUNBLHlDQUFBO0FBSUo7O0FBQUE7RUFDSSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFHSjs7QUFEQTtFQUNJLGNBQUE7RUFDQSxxQkFBQTtBQUlKOztBQUZBO0VBQ0ksOEJBQUE7QUFLSjs7QUFIQTtFQUNJLGdCQUFBO0FBTUoiLCJmaWxlIjoibG9naW4uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubG9nbWFpbmRpdiB7XHJcbiAgICBwb3NpdGlvbjpmaXhlZDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgd2lkdGg6MjVlbTtcclxuICAgIGhlaWdodDoxOGVtO1xyXG4gICAgbWFyZ2luLXRvcDogLTllbTsgLypzZXQgdG8gYSBuZWdhdGl2ZSBudW1iZXIgMS8yIG9mIHlvdXIgaGVpZ2h0Ki9cclxuICAgIG1hcmdpbi1sZWZ0OiAtMTVlbTsgLypzZXQgdG8gYSBuZWdhdGl2ZSBudW1iZXIgMS8yIG9mIHlvdXIgd2lkdGgqL1xyXG4gICAgLypib3JkZXI6IDFweCBzb2xpZCAjY2NjOyovXHJcbiAgICAvKmJhY2tncm91bmQtY29sb3I6ICNmM2YzZjMqLztcclxufVxyXG5cclxuLnBhcmVudCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcblxyXG4gLnNhbGVzZm9yY2VJZGVudGl0eUxvZ2luQm9keTJ7XHJcbiAgICBwYWRkaW5nLXRvcDogMSU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNSU7XHJcbiAgICBmb250LWZhbWlseTogJ2xhdG8nLCAnYXJpYWwnLCBzYW5zLXNlcmlmO1xyXG4gIH1cclxuXHJcbiAgLmxvZ2luSW1nT25le1xyXG4gICAgbWFyZ2luLXRvcDogMyU7bWFyZ2luLWJvdHRvbTogMyU7XHJcbiAgfVxyXG5cclxuIC5yb3cge1xyXG4gICAgLS1icy1ndXR0ZXIteDogLTEuNXJlbTtcclxuICAgIC0tYnMtZ3V0dGVyLXk6IDA7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC13cmFwOiB3cmFwO1xyXG4gICAgbWFyZ2luLXRvcDogY2FsYyh2YXIoLS1icy1ndXR0ZXIteSkgKiAtMSk7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGNhbGModmFyKC0tYnMtZ3V0dGVyLXgpLyAtMik7XHJcbiAgICBtYXJnaW4tbGVmdDogY2FsYyh2YXIoLS1icy1ndXR0ZXIteCkvIC0yKTtcclxufVxyXG5cclxuLy9pbnB1dCBjc3NcclxuOmhvc3Q6Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2Utb3V0bGluZSAubWF0LWZvcm0tZmllbGQtb3V0bGluZSB7XHJcbiAgICBjb2xvcjogd2hpdGUhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbn1cclxuYSB7XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG46aG9zdDo6bmctZGVlcC5tYXQtZm9ybS1maWVsZC13cmFwcGVyIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwZW0gIWltcG9ydGFudDtcclxufVxyXG46aG9zdDo6bmctZGVlcC5tYXQtZm9ybS1maWVsZHtcclxuICAgIG1heC1oZWlnaHQ6IDYwcHg7XHJcbn0iXX0= */"] });


/***/ }),

/***/ 93164:
/*!***********************************************************************!*\
  !*** ./src/app/package/core/main-menu-bar/main-menu-bar.component.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuBarComponent": function() { return /* binding */ MainMenuBarComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/toolbar */ 12522);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 76627);




class MainMenuBarComponent {
    ngOnInit() {
        // this.modulesList = ModulesList;
        // console.log(this.modulesList);
    }
}
MainMenuBarComponent.ɵfac = function MainMenuBarComponent_Factory(t) { return new (t || MainMenuBarComponent)(); };
MainMenuBarComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainMenuBarComponent, selectors: [["app-main-menu-bar"]], inputs: { sidenav: "sidenav" }, decls: 6, vars: 0, consts: [[1, "example-toolbar", "shadow", 2, "height", "5%", "background-color", "#e50f7c", "color", "white"], ["mat-icon-button", "", 2, "float", "left", 3, "click"], [1, "col-lg-12", 2, "text-align", "center", "white-space", "normal"]], template: function MainMenuBarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainMenuBarComponent_Template_button_click_1_listener() { return ctx.sidenav.toggle(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "menu");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Research & Development Advanced Planning");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_1__.MatToolbar, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIcon], styles: [".app_text {\n  background-color: #e50f7c;\n  color: white;\n  text-align: center;\n  font-size: 20px;\n  height: 2rem;\n  font-weight: bold;\n}\n\n.shadow {\n  box-shadow: 0px 0px 25px 5px rgba(201, 187, 201, 0.75);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4tbWVudS1iYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUdFLHNEQUFBO0FBQ0YiLCJmaWxlIjoibWFpbi1tZW51LWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hcHBfdGV4dCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U1MGY3YztcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBoZWlnaHQ6IDJyZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5zaGFkb3cge1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMHB4IDBweCAyNXB4IDVweCByZ2JhKDIwMSwxODcsMjAxLDAuNzUpO1xyXG4gIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCAyNXB4IDVweCByZ2JhKDIwMSwxODcsMjAxLDAuNzUpO1xyXG4gIGJveC1zaGFkb3c6IDBweCAwcHggMjVweCA1cHggcmdiYSgyMDEsMTg3LDIwMSwwLjc1KTtcclxufVxyXG5cclxuIl19 */"], encapsulation: 2 });


/***/ }),

/***/ 76793:
/*!***********************************************************!*\
  !*** ./src/app/package/core/okta-auth/okta-auth-guard.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OktaAuthGuard": function() { return /* binding */ OktaAuthGuard; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _okta_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./okta-auth-service */ 59841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);




class OktaAuthGuard {
    constructor(okta, router) {
        this.okta = okta;
        this.router = router;
    }
    canActivate(route, state) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            const authenticated = yield this.okta.isAuthenticated();
            if (authenticated) {
                return true;
            }
            // Redirect to login flow.
            this.okta.login(state.url);
            return false;
        });
    }
}
OktaAuthGuard.ɵfac = function OktaAuthGuard_Factory(t) { return new (t || OktaAuthGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__.OktaAuthService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router)); };
OktaAuthGuard.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: OktaAuthGuard, factory: OktaAuthGuard.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 59841:
/*!*************************************************************!*\
  !*** ./src/app/package/core/okta-auth/okta-auth-service.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OktaAuthService": function() { return /* binding */ OktaAuthService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 69165);
/* harmony import */ var _okta_okta_auth_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @okta/okta-auth-js */ 14163);
/* harmony import */ var _okta_okta_auth_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_okta_okta_auth_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);





class OktaAuthService {
    constructor(router) {
        this.router = router;
        // IMPORTANT!
        // Replace {clientId} with your actual Client ID
        // Replace {yourOktaDomain} with your actual Okta domain
        // If using a custom authorization server, ISSUER should be 'https://{yourOktaDomain}/oauth2/${authServerId}'
        // Dev App
        this.CLIENT_ID = '0oa1croj4yjrsRSR75d7';
        this.ISSUER = 'https://dev-88037208.okta.com';
        this.LOGIN_REDIRECT_URI = 'https://bg4ws1619:8080/main/launcher';
        this.LOGOUT_REDIRECT_URI = 'https://bg4ws1619:8080';
        this.SCOPE = ['openid', 'email'];
        //Aristocrat Portal App
        //   CLIENT_ID = '0oa9t7ifubUwIhATi357';
        //   ISSUER = 'https://aristocrat.okta.com'
        //   LOGIN_REDIRECT_URI = 'http://sydc-appdev-01:8080/home';
        //   LOGOUT_REDIRECT_URI = 'http://sydc-appdev-01:8080';
        //   SCOPE = ['openid','email'];
        this.oktaAuth = new _okta_okta_auth_js__WEBPACK_IMPORTED_MODULE_0__.OktaAuth({
            clientId: this.CLIENT_ID,
            issuer: this.ISSUER,
            redirectUri: this.LOGIN_REDIRECT_URI,
            pkce: true,
            scopes: this.SCOPE
        });
        this.$isAuthenticated = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Observable((observer) => {
            this.observer = observer;
            this.isAuthenticated().then(val => {
                observer.next(val);
            });
        });
    }
    isAuthenticated() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.oktaAuth.isAuthenticated().then(val => {
                console.log(val);
                if (val == true) {
                    this.handleAuthentication();
                    console.log(this.oktaAuth.token.parseFromUrl());
                }
            });
            // Checks if there is a current accessToken in the TokenManger.
            return !!(yield this.oktaAuth.tokenManager.get('accessToken'));
        });
    }
    login(originalUrl) {
        // Save current URL before redirect
        sessionStorage.setItem('okta-app-url', originalUrl || this.router.url);
        // Launches the login redirect.
        this.oktaAuth.token.getWithRedirect({
            scopes: ['openid', 'email', 'profile']
        });
    }
    handleAuthentication() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            if (this.oktaAuth.token) {
                const tokenContainer = yield this.oktaAuth.token.parseFromUrl();
                console.log("tokenContainer", tokenContainer);
                this.oktaAuth.tokenManager.add('idToken', tokenContainer.tokens.idToken);
                this.oktaAuth.tokenManager.add('accessToken', tokenContainer.tokens.accessToken);
                localStorage.setItem('testObject', JSON.stringify(this.oktaAuth));
                if (yield this.isAuthenticated()) {
                    (_a = this.observer) === null || _a === void 0 ? void 0 : _a.next(true);
                }
                // Retrieve the saved URL and navigate back
                const url = sessionStorage.getItem('okta-app-url');
                this.router.navigateByUrl(url);
            }
        });
    }
    logout() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.oktaAuth.signOut({
                postLogoutRedirectUri: this.LOGOUT_REDIRECT_URI
            });
        });
    }
}
OktaAuthService.ɵfac = function OktaAuthService_Factory(t) { return new (t || OktaAuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router)); };
OktaAuthService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: OktaAuthService, factory: OktaAuthService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 23414:
/*!***********************************************************************!*\
  !*** ./src/app/package/core/side-menu-bar/side-menu-bar.component.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SideMenuBarComponent": function() { return /* binding */ SideMenuBarComponent; }
/* harmony export */ });
/* harmony import */ var _animation_animation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../animation/animation */ 8101);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _sidenav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sidenav.service */ 14295);
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/list */ 77746);
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/divider */ 1769);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ 1562);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 39895);










function SideMenuBarComponent_div_9_mat_expansion_panel_1_a_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "a", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "mat-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const subitem_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate"]("routerLink", subitem_r7.link);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](subitem_r7 == null ? null : subitem_r7.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("@animateText", ctx_r6.linkText ? "show" : "hide");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", subitem_r7 == null ? null : subitem_r7.name, " ");
} }
function SideMenuBarComponent_div_9_mat_expansion_panel_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "mat-expansion-panel");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "mat-expansion-panel-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "mat-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "mat-nav-list");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, SideMenuBarComponent_div_9_mat_expansion_panel_1_a_7_Template, 6, 4, "a", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3 == null ? null : item_r3.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("@animateText", ctx_r4.linkText ? "show" : "hide");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r3 == null ? null : item_r3.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", item_r3.submenu);
} }
function SideMenuBarComponent_div_9_a_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", item_r3 == null ? null : item_r3.icon, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("@animateText", ctx_r5.linkText ? "show" : "hide");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r3 == null ? null : item_r3.name, " ");
} }
function SideMenuBarComponent_div_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, SideMenuBarComponent_div_9_mat_expansion_panel_1_Template, 8, 4, "mat-expansion-panel", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "mat-nav-list", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "mat-nav-list");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, SideMenuBarComponent_div_9_a_4_Template, 5, 3, "a", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r3.submenu.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r3.submenu.length == 0);
} }
function SideMenuBarComponent_mat_icon_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "arrow_left");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function SideMenuBarComponent_mat_icon_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "arrow_right");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class SideMenuBarComponent {
    constructor(_sidenavService) {
        this._sidenavService = _sidenavService;
        this.sideNavState = false;
        this.linkText = false;
        this.pages = [
            { name: 'Manage PIN', link: 'some-link', icon: 'lock', type: 'P', header: '0', submenu: [
                    //{
                    //   name: 'Master', link:'/main/expinreq/pinrequest', icon: 'grade',type:'C',header:'0'
                    // },
                    {
                        name: 'Studio', link: '/main/config/setuptable/studio/search', icon: 'admin_panel_settings', type: 'SC', header: '0'
                    }, {
                        name: 'Market', link: '/main/config/setuptable/market/search', icon: 'room_preferences', type: 'SC', header: '0'
                    }, {
                        name: 'Channel Type', link: '/main/config/setuptable/channeltype/search', icon: 'verified', type: 'SC', header: '0'
                    }, {
                        name: 'Channel', link: '/main/config/setuptable/channel/search', icon: 'thumb_up', type: 'SC', header: '0'
                    }, {
                        name: 'Cabinets', link: '/main/config/setuptable/cabinets/search', icon: 'event', type: 'SC', header: '0'
                    }, {
                        name: 'Dev Effort Type', link: '/main/config/setuptable/devefforttype/search', icon: 'lightbulb', type: 'SC', header: '0'
                    }, {
                        name: 'Dev Complexity', link: '/main/config/setuptable/devcomplexity/search', icon: 'highlight_off', type: 'SC', header: '0'
                    }, {
                        name: 'Gravity', link: '/main/config/setuptable/gravity/search', icon: 'task_alt', type: 'SC', header: '0'
                    }, {
                        name: 'Dev Type1', link: '/main/config/setuptable/devtype1/search', icon: 'question_answer', type: 'SC', header: '0'
                    }, {
                        name: 'Dev Type2', link: '/main/config/setuptable/devtype2/search', icon: 'room_preferences', type: 'SC', header: '0'
                    }, {
                        name: 'Dev Type2', link: '/main/config/setuptable/devtype2/search', icon: 'room_preferences', type: 'SC', header: '0'
                    }, {
                        name: 'Version', link: '/main/config/setuptable/version/search', icon: 'text_snippet', type: 'SC', header: '0'
                    }, {
                        name: 'Quarter', link: '/main/config/setuptable/quarter/search', icon: 'text_snippet', type: 'SC', header: '0'
                    }, {
                        name: 'EPP', link: '/main/config/setuptable/epp/search', icon: 'cloud', type: 'SC', header: '0'
                    }, {
                        name: 'Region', link: '/main/config/setuptable/region/search', icon: 'cloud', type: 'SC', header: '0'
                    }, {
                        name: 'Prodcat1', link: '/main/config/setuptable/prodcat1/search', icon: 'cloud', type: 'SC', header: '0'
                    }, {
                        name: 'Prodcat2', link: '/main/config/setuptable/prodcat2/search', icon: 'cloud', type: 'SC', header: '0'
                    }, {
                        name: 'Prodcat3', link: '/main/config/setuptable/prodcat3/search', icon: 'cloud', type: 'SC', header: '0'
                    }, {
                        name: 'Transaction', link: '/main/expinreq/pinrequest', icon: 'paid', type: 'C', header: '0'
                    }
                ] },
            { name: 'Rework', link: 'some-link', icon: 'all_inclusive', type: 'P', header: '0', submenu: [{
                        name: 'Master', link: 'some-link', icon: 'work', type: 'C', header: '0'
                    }, {
                        name: 'Transaction', link: 'some-link', icon: 'paid', type: 'C', header: '0'
                    }] },
            { name: 'Change Request', link: 'some-link', icon: 'published_with_changes', type: 'P', header: '0', submenu: [{
                        name: 'Master', link: 'some-link', icon: 'work', type: 'C', header: '0'
                    }, {
                        name: 'Transaction', link: 'some-link', icon: 'paid', type: 'C', header: '0'
                    }] },
            { name: 'Delay Notification', link: 'some-link', icon: 'circle_notifications', type: 'P', header: '0', submenu: [{
                        name: 'Master', link: 'some-link', icon: 'work', type: 'C', header: '0'
                    }, {
                        name: 'Transaction', link: 'some-link', icon: 'paid', type: 'C', header: '0'
                    }] },
            { name: 'Transfer Approval', link: 'some-link', icon: 'receipt_long', type: 'P', header: '0', submenu: [{
                        name: 'Master', link: 'some-link', icon: 'work', type: 'C', header: '0'
                    }, {
                        name: 'Transaction', link: 'some-link', icon: 'paid', type: 'C', header: '0'
                    }] },
            { name: 'User Authorization', link: 'some-link', icon: 'supervised_user_circle', type: 'P', header: '0', submenu: [] },
            { name: 'Auditing ', link: 'some-link', icon: 'admin_panel_settings', type: 'P', header: '0', submenu: [] },
            { name: 'System Setup', link: 'some-link', icon: 'phonelink_setup', type: 'P', header: '0', submenu: [] },
        ];
    }
    ngOnInit() {
    }
    onSinenavToggle() {
        console.log(this.sideNavState);
        this.sideNavState = true;
        setTimeout(() => {
            this.linkText = this.sideNavState;
        }, 200);
        this._sidenavService.sideNavState$.next(this.sideNavState);
    }
    onSidenavToggleOver() {
        console.log(this.sideNavState);
        this.sideNavState = true;
        setTimeout(() => {
            this.linkText = this.sideNavState;
        }, 200);
        this._sidenavService.sideNavState$.next(this.sideNavState);
    }
    onSidenavToggleOut() {
        console.log(this.sideNavState);
        this.sideNavState = !this.sideNavState;
        setTimeout(() => {
            this.linkText = this.sideNavState;
        }, 200);
        this._sidenavService.sideNavState$.next(this.sideNavState);
    }
}
SideMenuBarComponent.ɵfac = function SideMenuBarComponent_Factory(t) { return new (t || SideMenuBarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_sidenav_service__WEBPACK_IMPORTED_MODULE_1__.SidenavService)); };
SideMenuBarComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: SideMenuBarComponent, selectors: [["app-side-menu-bar"]], decls: 15, vars: 4, consts: [[1, "col-lg-12", "sidenav_container", 2, "transform", "scale(0.7)", 3, "click", "mouseout", "mouseover"], ["fxLayout", "column", "fxLayoutGap", "10px", 2, "height", "100%"], [1, "user_menu"], ["mat-list-item", ""], ["src", "https://www.publicdomainpictures.net/pictures/270000/velka/avatar-people-person-business-.jpg", "alt", "", 1, "jim"], [4, "ngFor", "ngForOf"], [1, "spacer"], ["fxLayout", "row", "fxLayoutAlign", "end center", 2, "padding", "0px 10px"], ["mat-icon-button", "", 3, "mouseover"], [4, "ngIf"], [2, "text-align", "center"], ["mat-list-item", "", "style", "color: white;background-color:#300c46;", 4, "ngIf"], [2, "padding-right", "5px"], ["style", "color: white;background-color:#300c46;", 4, "ngFor", "ngForOf"], [2, "color", "white", "background-color", "#300c46"], ["mat-list-item", "", 2, "color", "white", "background-color", "#300c46", 3, "routerLink"], ["mat-list-item", "", 2, "color", "white", "background-color", "#300c46"], [1, "material-icons-outlined"]], template: function SideMenuBarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SideMenuBarComponent_Template_div_click_0_listener() { return ctx.onSidenavToggleOver(); })("mouseout", function SideMenuBarComponent_Template_div_mouseout_0_listener() { return ctx.onSidenavToggleOut(); })("mouseover", function SideMenuBarComponent_Template_div_mouseover_0_listener() { return ctx.onSidenavToggleOver(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "mat-nav-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "mat-divider");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "mat-nav-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](9, SideMenuBarComponent_div_9_Template, 5, 2, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](10, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("mouseover", function SideMenuBarComponent_Template_button_mouseover_12_listener() { return ctx.onSinenavToggle(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](13, SideMenuBarComponent_mat_icon_13_Template, 2, 0, "mat-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](14, SideMenuBarComponent_mat_icon_14_Template, 2, 0, "mat-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("@onSideNavChange", ctx.sideNavState ? "open" : "close");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.pages);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.sideNavState);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.sideNavState);
    } }, directives: [_angular_material_list__WEBPACK_IMPORTED_MODULE_3__.MatNavList, _angular_material_list__WEBPACK_IMPORTED_MODULE_3__.MatListItem, _angular_material_divider__WEBPACK_IMPORTED_MODULE_4__.MatDivider, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButton, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelHeader, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__.MatIcon, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterLinkWithHref], styles: [".sidenav_container[_ngcontent-%COMP%] {\n  min-width: 60px;\n  height: calc(100vh - 200px);\n}\n\n.jim[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  object-fit: cover;\n  border-radius: 50%;\n}\n\n.example-container[_ngcontent-%COMP%] {\n  height: 500px;\n  border: 1px solid rgba(0, 0, 0, 0.5);\n}\n\n.example-sidenav-content[_ngcontent-%COMP%] {\n  display: -ms-flexbox;\n  display: flex;\n  height: 100%;\n  -ms-flex-align: center;\n      align-items: center;\n  -ms-flex-pack: center;\n      justify-content: center;\n}\n\n.example-sidenav[_ngcontent-%COMP%] {\n  -webkit-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n}\n\n.full-width[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.menu-button[_ngcontent-%COMP%] {\n  transition: 300ms ease-in-out;\n  -ms-transform: rotate(0deg);\n      transform: rotate(0deg);\n}\n\n.menu-button.rotated[_ngcontent-%COMP%] {\n  -ms-transform: rotate(180deg);\n      transform: rotate(180deg);\n}\n\n.submenu[_ngcontent-%COMP%] {\n  overflow-y: hidden;\n  transition: transform 300ms ease;\n  -ms-transform: scaleY(0);\n      transform: scaleY(0);\n  -ms-transform-origin: top;\n      transform-origin: top;\n  padding-left: 30px;\n}\n\n.submenu.expanded[_ngcontent-%COMP%] {\n  -ms-transform: scaleY(1);\n      transform: scaleY(1);\n}\n\n[_nghost-%COMP%] .mat-expansion-panel {\n  background-color: #300c46;\n  color: white;\n}\n\n[_nghost-%COMP%] .mat-expansion-panel-header:not([aria-disabled=true]) {\n  color: white;\n}\n\n[_nghost-%COMP%] .mat-expansion-indicator::after {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZGUtbWVudS1iYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVFO0VBQ0UsYUFBQTtFQUNBLG9DQUFBO0FBQ0o7O0FBQ0U7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7TUFBQSxtQkFBQTtFQUNBLHFCQUFBO01BQUEsdUJBQUE7QUFFSjs7QUFBRTtFQUNHLHlCQUFBO01BQUEscUJBQUE7VUFBQSxpQkFBQTtBQUdMOztBQURFO0VBQ0UsV0FBQTtBQUlKOztBQUZFO0VBQ0UsNkJBQUE7RUFDQSwyQkFBQTtNQUFBLHVCQUFBO0FBS0o7O0FBSEU7RUFDRSw2QkFBQTtNQUFBLHlCQUFBO0FBTUo7O0FBSkU7RUFDRSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0Esd0JBQUE7TUFBQSxvQkFBQTtFQUNBLHlCQUFBO01BQUEscUJBQUE7RUFDQSxrQkFBQTtBQU9KOztBQUxFO0VBQ0Usd0JBQUE7TUFBQSxvQkFBQTtBQVFKOztBQUxFO0VBQ0YseUJBQUE7RUFDQSxZQUFBO0FBUUE7O0FBTkU7RUFDRSxZQUFBO0FBU0o7O0FBUEU7RUFDSSxZQUFBO0FBVU4iLCJmaWxlIjoic2lkZS1tZW51LWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaWRlbmF2X2NvbnRhaW5lciB7XHJcbiAgICBtaW4td2lkdGg6IDYwcHg7IFxyXG4gICAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMjAwcHgpO1xyXG4gIH1cclxuICBcclxuICAuamltIHtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgfVxyXG5cclxuICAuZXhhbXBsZS1jb250YWluZXIge1xyXG4gICAgaGVpZ2h0OiA1MDBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICB9XHJcbiAgLmV4YW1wbGUtc2lkZW5hdi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG4gIC5leGFtcGxlLXNpZGVuYXYge1xyXG4gICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG4gIH1cclxuICAuZnVsbC13aWR0aCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcbiAgLm1lbnUtYnV0dG9uIHtcclxuICAgIHRyYW5zaXRpb246IDMwMG1zIGVhc2UtaW4tb3V0O1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgfVxyXG4gIC5tZW51LWJ1dHRvbi5yb3RhdGVkIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XHJcbiAgfVxyXG4gIC5zdWJtZW51IHtcclxuICAgIG92ZXJmbG93LXk6IGhpZGRlbjtcclxuICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAzMDBtcyBlYXNlO1xyXG4gICAgdHJhbnNmb3JtOiBzY2FsZVkoMCk7XHJcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiB0b3A7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgfVxyXG4gIC5zdWJtZW51LmV4cGFuZGVkIHtcclxuICAgIHRyYW5zZm9ybTogc2NhbGVZKDEpO1xyXG4gIH1cclxuXHJcbiAgOmhvc3Q6Om5nLWRlZXAubWF0LWV4cGFuc2lvbi1wYW5lbHtcclxuYmFja2dyb3VuZC1jb2xvcjogIzMwMGM0NjtcclxuY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICA6aG9zdDo6bmctZGVlcC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcjpub3QoW2FyaWEtZGlzYWJsZWQ9dHJ1ZV0pIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgOmhvc3Q6Om5nLWRlZXAubWF0LWV4cGFuc2lvbi1pbmRpY2F0b3I6OmFmdGVye1xyXG4gICAgICBjb2xvcjogd2hpdGU7XHJcbiAgfSJdfQ== */"], data: { animation: [_animation_animation__WEBPACK_IMPORTED_MODULE_0__.onSideNavChange, _animation_animation__WEBPACK_IMPORTED_MODULE_0__.animateText] } });


/***/ }),

/***/ 14295:
/*!***************************************************************!*\
  !*** ./src/app/package/core/side-menu-bar/sidenav.service.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SidenavService": function() { return /* binding */ SidenavService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 79765);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);


class SidenavService {
    constructor() {
        // With this subject you can save the sidenav state and consumed later into other pages.
        this.sideNavState$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    }
}
SidenavService.ɵfac = function SidenavService_Factory(t) { return new (t || SidenavService)(); };
SidenavService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: SidenavService, factory: SidenavService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 32418:
/*!****************************************************!*\
  !*** ./src/app/package/core/utils/shared-utils.ts ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStartOfDayUTCDate": function() { return /* binding */ getStartOfDayUTCDate; },
/* harmony export */   "getStartOfDayTimestamp": function() { return /* binding */ getStartOfDayTimestamp; },
/* harmony export */   "hasValue": function() { return /* binding */ hasValue; },
/* harmony export */   "removeSpaces": function() { return /* binding */ removeSpaces; },
/* harmony export */   "getUUid": function() { return /* binding */ getUUid; },
/* harmony export */   "isNotEmptyVal": function() { return /* binding */ isNotEmptyVal; },
/* harmony export */   "isEmptyVal": function() { return /* binding */ isEmptyVal; },
/* harmony export */   "isEmptyString": function() { return /* binding */ isEmptyString; },
/* harmony export */   "isNotEmptyString": function() { return /* binding */ isNotEmptyString; },
/* harmony export */   "isEmptyObj": function() { return /* binding */ isEmptyObj; },
/* harmony export */   "moveArrayElement": function() { return /* binding */ moveArrayElement; },
/* harmony export */   "getUTCTimeStampEndDay": function() { return /* binding */ getUTCTimeStampEndDay; },
/* harmony export */   "getUTCStartFromMoment": function() { return /* binding */ getUTCStartFromMoment; },
/* harmony export */   "getUTCTimeStamp": function() { return /* binding */ getUTCTimeStamp; },
/* harmony export */   "getUTCEndTimeStamp": function() { return /* binding */ getUTCEndTimeStamp; },
/* harmony export */   "replaceNullByEmptyString": function() { return /* binding */ replaceNullByEmptyString; },
/* harmony export */   "replaceNullByEmptyStringArray": function() { return /* binding */ replaceNullByEmptyStringArray; },
/* harmony export */   "getParams": function() { return /* binding */ getParams; },
/* harmony export */   "getParamsforReminder": function() { return /* binding */ getParamsforReminder; },
/* harmony export */   "getParamsWithTimeZone": function() { return /* binding */ getParamsWithTimeZone; },
/* harmony export */   "getTimezone": function() { return /* binding */ getTimezone; },
/* harmony export */   "getNotificationLocation": function() { return /* binding */ getNotificationLocation; },
/* harmony export */   "processNotification": function() { return /* binding */ processNotification; },
/* harmony export */   "mapKeys": function() { return /* binding */ mapKeys; },
/* harmony export */   "_isEmptyVal": function() { return /* binding */ _isEmptyVal; },
/* harmony export */   "_isNotEmptyVal": function() { return /* binding */ _isNotEmptyVal; },
/* harmony export */   "_isEmptyString": function() { return /* binding */ _isEmptyString; },
/* harmony export */   "_isNotEmptyString": function() { return /* binding */ _isNotEmptyString; },
/* harmony export */   "_isEmptyObj": function() { return /* binding */ _isEmptyObj; },
/* harmony export */   "firstDayOfWeek": function() { return /* binding */ firstDayOfWeek; },
/* harmony export */   "getParamsForTaskCommon": function() { return /* binding */ getParamsForTaskCommon; },
/* harmony export */   "getParamsForIntake": function() { return /* binding */ getParamsForIntake; },
/* harmony export */   "mapMatterFilterKeys": function() { return /* binding */ mapMatterFilterKeys; },
/* harmony export */   "removeunwantedHTML": function() { return /* binding */ removeunwantedHTML; },
/* harmony export */   "getUTCFormattedDate": function() { return /* binding */ getUTCFormattedDate; },
/* harmony export */   "getFormattedDateTime": function() { return /* binding */ getFormattedDateTime; },
/* harmony export */   "getFormattedDateTimeForEventsTabIfNotFullDay": function() { return /* binding */ getFormattedDateTimeForEventsTabIfNotFullDay; },
/* harmony export */   "getFormattedDateTimeForEventsTabIfFullDay": function() { return /* binding */ getFormattedDateTimeForEventsTabIfFullDay; },
/* harmony export */   "getUTCCustomFormattedDate": function() { return /* binding */ getUTCCustomFormattedDate; },
/* harmony export */   "getCustomFormattedDateTime": function() { return /* binding */ getCustomFormattedDateTime; },
/* harmony export */   "getUTCDifferentFormattedDate": function() { return /* binding */ getUTCDifferentFormattedDate; },
/* harmony export */   "setUnixFormattedDate": function() { return /* binding */ setUnixFormattedDate; },
/* harmony export */   "getUnixFormattedDate": function() { return /* binding */ getUnixFormattedDate; },
/* harmony export */   "getUnixFormattedDateWithoutTime": function() { return /* binding */ getUnixFormattedDateWithoutTime; },
/* harmony export */   "getDateandTime": function() { return /* binding */ getDateandTime; },
/* harmony export */   "getTimeandDate": function() { return /* binding */ getTimeandDate; },
/* harmony export */   "getTime": function() { return /* binding */ getTime; },
/* harmony export */   "getDateTimeFormatted": function() { return /* binding */ getDateTimeFormatted; },
/* harmony export */   "getDateWithGmtTimeZone": function() { return /* binding */ getDateWithGmtTimeZone; },
/* harmony export */   "getDateWithLocalTimeZone": function() { return /* binding */ getDateWithLocalTimeZone; },
/* harmony export */   "replaceHtmlEntites": function() { return /* binding */ replaceHtmlEntites; },
/* harmony export */   "replaceQuoteWithActual": function() { return /* binding */ replaceQuoteWithActual; },
/* harmony export */   "dataURItoBlob": function() { return /* binding */ dataURItoBlob; },
/* harmony export */   "formatCurrency": function() { return /* binding */ formatCurrency; },
/* harmony export */   "formatCurrencyWithEmptyValDecimal": function() { return /* binding */ formatCurrencyWithEmptyValDecimal; },
/* harmony export */   "formatCurrencyWithoutDollar": function() { return /* binding */ formatCurrencyWithoutDollar; },
/* harmony export */   "utcDateFilter": function() { return /* binding */ utcDateFilter; },
/* harmony export */   "sortByName": function() { return /* binding */ sortByName; }
/* harmony export */ });
/* harmony import */ var underscore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! underscore */ 35849);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ 16738);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment-timezone */ 71412);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_2__);



// tslint:disable: prefer-const
// tslint:disable: variable-name
function getStartOfDayUTCDate(d) {
    return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}
function getStartOfDayTimestamp(date) {
    let startOfDay;
    startOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    return startOfDay / 1000;
}
function hasValue(data) {
    if (data === undefined || data === "" || data === null) {
        return false;
    }
    return true;
}
function removeSpaces(content) {
    return content.replace(/\s/g, "");
}
function getUUid() {
    let dt = new Date().getTime();
    const uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        // tslint:disable-next-line: no-bitwise
        const r = (dt + Math.random() * 16) % 16 | 0;
        dt = Math.floor(dt / 16);
        // tslint:disable: triple-equals
        // tslint:disable: no-bitwise
        return (c == "x" ? r : (r & 0x3) | 0x8).toString(16);
    });
    return uuid;
}
function isNotEmptyVal(val) {
    return !isEmptyVal(val);
}
function isEmptyVal(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    if (val instanceof Array) {
        return val.length === 0;
    }
    if (isEmptyString(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNaN(val)) {
        return true;
    }
    return false;
}
function isEmptyString(str) {
    str = "" + str;
    return str.trim().length === 0;
}
function isNotEmptyString(str) {
    str = "" + str;
    return str.trim().length > 0;
}
function isEmptyObj(obj) {
    if (typeof obj === "undefined") {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(obj)) {
        return true;
    }
    return Object.keys(obj).length === 0;
}
function moveArrayElement(array, old_index, new_index) {
    if (new_index >= array.length) {
        let k = new_index - array.length;
        while (k-- + 1) {
            array.push(undefined);
        }
    }
    array.splice(new_index, 0, array.splice(old_index, 1)[0]);
}
function getUTCTimeStampEndDay(selectedDate) {
    const date = new Date(selectedDate);
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth();
    const day = date.getDate();
    const startHour = Date.UTC(year, month, day, 23, 59, 59);
    const timestamp = startHour / 1000;
    return timestamp;
}
function getUTCStartFromMoment(start) {
    let startDt = new Date(Date.UTC(parseInt(start.format("YYYY")), parseInt(start.format("MM")) - 1, parseInt(start.format("DD")), 0, 0, 0, 0));
    return moment__WEBPACK_IMPORTED_MODULE_1__(startDt.getTime()).unix();
}
function getUTCTimeStamp(selectedDate) {
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate).unix();
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__.unix(selectedDate).format("YYYY-MM-DD");
    const UTCDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate + " 0:00 +0000", "YYYY-MM-DD HH:mm Z");
    const timeStamp = moment__WEBPACK_IMPORTED_MODULE_1__(UTCDate).unix();
    return timeStamp;
}
function getUTCEndTimeStamp(selectedDate) {
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate).unix();
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__.unix(selectedDate).format("YYYY-MM-DD");
    const UTCDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate + " 23:59 +0000", "YYYY-MM-DD HH:mm Z");
    const timeStamp = moment__WEBPACK_IMPORTED_MODULE_1__(UTCDate).unix();
    return timeStamp;
}
function replaceNullByEmptyString(obj) {
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(obj, (val, key) => {
        if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val) || underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
            obj[key] = "";
        }
    });
}
function replaceNullByEmptyStringArray(array) {
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(array, (obj) => {
        replaceNullByEmptyString(obj);
    });
}
function getParams(params) {
    let querystring = "";
    params.forEach((value, key) => {
        querystring += key + "=" + value;
        querystring += "&";
    });
    return querystring.slice(0, querystring.length - 1);
}
function getParamsforReminder(params) {
    params.tz = getTimezone();
    let querystring = "";
    for (let [key, value] of Object.entries(params)) {
        querystring += key + "=" + value;
        querystring += "&";
    }
    return querystring.slice(0, querystring.length - 1);
}
function getParamsWithTimeZone(params) {
    let tz = getTimezone();
    let timeZone = moment_timezone__WEBPACK_IMPORTED_MODULE_2__.tz.guess();
    params.tz = timeZone;
    let querystring = "";
    for (let [key, value] of Object.entries(params)) {
        querystring += key + "=" + value;
        querystring += "&";
    }
    return querystring.slice(0, querystring.length - 1);
}
function getTimezone() {
    const offset = new Date().getTimezoneOffset();
    const o = Math.abs(offset);
    return ((offset < 0 ? "+" : "-") +
        ("00" + Math.floor(o / 60)).slice(-2) +
        ":" +
        ("00" + (o % 60)).slice(-2));
}
function getNotificationLocation(sectors) {
    let placeArr = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(sectors, (item) => {
        switch (item) {
            case 1: // event
                placeArr.push("Event");
                break;
            case 2: // task
                placeArr.push("Task");
                break;
            case 3: // reminders
                placeArr.push("Event_Reminder");
                placeArr.push("Task_Reminder");
                break;
            case 4: // Email
                placeArr.push("Email");
                break;
            case 5: // sms
                placeArr.push("Client_Messenger");
                break;
            case 6: // Sidebar_Comment
                placeArr.push("Sidebar_Comment");
                placeArr.push("Sidebar_Post");
                break;
            case 7:
                placeArr.push("Matter");
                break;
            case 8:
                placeArr.push("Intake");
                break;
            case 9:
                placeArr.push("UberTrip");
                break;
        }
    });
    return placeArr;
}
function processNotification(res) {
    let now = moment__WEBPACK_IMPORTED_MODULE_1__(new Date()); // todays date
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(res, (currentItem) => {
        let end = moment__WEBPACK_IMPORTED_MODULE_1__.unix(currentItem.created_on); // another date
        let duration = moment__WEBPACK_IMPORTED_MODULE_1__.duration(now.diff(end));
        currentItem.createdHoursBack = Math.floor(duration.asHours());
        currentItem.createdMinuteBack = Math.floor(duration.asMinutes());
        currentItem.notiDots = false;
        //
        if (currentItem.notification_type == "Sidebar_Comment") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.nid = notData.nid;
            currentItem.comment = notData.comment_body_value;
            currentItem.post = notData.body_value;
        }
        if (currentItem.notification_type == "Sidebar_Post") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.nid = notData.nid;
            currentItem.post = notData.body_value;
        }
        if (currentItem.notification_type == "Email") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.mail_body = notData.mail_body;
            currentItem.senders_name = notData.senders_name;
            currentItem.subject = notData.subject;
        }
        if (currentItem.notification_type == "Event") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "event";
        }
        if (currentItem.notification_type == "Task") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "task";
        }
        if (currentItem.notification_type == "Event_Reminder") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.type = "event";
        }
        if (currentItem.notification_type == "Task_Reminder") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.type = "task";
        }
        if (currentItem.notification_type == "Matter") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "matter";
        }
        if (currentItem.notification_type == "Intake") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "intake";
        }
        if (currentItem.notification_type == "Client_Messenger") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.sender_name = notData.sender_name;
            currentItem.text = notData.message;
            currentItem.is_sms = notData.is_sms;
        }
        if (currentItem.notification_type == "UberTrip") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = 'UberTrip';
        }
    });
    return res;
}
function mapKeys(data) {
    const obj = {};
    obj.contact_type = JSON.parse(data.matter_contact_type);
    obj.states = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.states, (item) => {
        obj.states.push(item.name.toString());
    });
    return obj;
}
function _isEmptyVal(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNaN(val)) {
        return true;
    }
    if (val instanceof Array) {
        return val.length === 0;
    }
    if (val instanceof Object) {
        return Object.keys(val).length === 0;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    if (_isEmptyString(val)) {
        return true;
    }
}
function _isNotEmptyVal(val) {
    return !_isEmptyVal(val);
}
function _isEmptyString(str) {
    return str.toString().trim().length === 0;
}
function _isNotEmptyString(str) {
    return str.toString().trim().length > 0;
}
function _isEmptyObj(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    return Object.keys(val).length === 0;
}
// public removeFieldSpaces(e): void {
//   e.target.value = removeSpaces(e.target.value);
// }
// public get(id: string): Observable<any> {
//   return this.http.get<any>(`${environment.urlPath}/user//${id}`);
// }
function firstDayOfWeek(year, week) {
    // Jan 1 of 'year'
    let d = new Date(year, 0, 1);
    let offset = d.getTimezoneOffset();
    // ISO: week 1 is the one with the year's first Thursday
    // so nearest Thursday: current date + 4 - current day number
    // Sunday is converted from 0 to 7
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    // 7 days * (week - overlapping first week)
    d.setTime(d.getTime() +
        7 * 24 * 60 * 60 * 1000 * (week + (year == d.getFullYear() ? -1 : 0)));
    // daylight savings fix
    d.setTime(d.getTime() + (d.getTimezoneOffset() - offset) * 60 * 1000);
    // back to Monday (from Thursday)
    d.setDate(d.getDate() - 3);
    const timestamp = moment__WEBPACK_IMPORTED_MODULE_1__(d.getTime()).unix();
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
}
function getParamsForTaskCommon(params, type) {
    params.tz = getTimezone();
    let querystring = "";
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(params, (value, key) => {
        if (type == "MM") {
            querystring += key + "=" + value;
            querystring += "&";
        }
        else if (type == "IM") {
            if (isNotEmptyVal(value)) {
                querystring += key + "=" + value;
                querystring += "&";
            }
        }
    });
    return querystring.slice(0, querystring.length - 1);
}
function getParamsForIntake(params) {
    params.tz = getTimezone();
    let querystring = "";
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(params, (value, key) => {
        if (isNotEmptyVal(value)) {
            querystring += key + "=" + value;
            querystring += "&";
        }
    });
    return querystring.slice(0, querystring.length - 1);
}
function mapMatterFilterKeys(data) {
    let obj = {};
    // Matter Category
    obj.category = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.category, (item) => {
        let cat = {};
        cat.id = item.id.toString();
        cat.name = item.name == "" ? "{Blank}" : item.name;
        obj.category.push(cat);
    });
    obj.contact_roles = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.contact_roles, (item) => {
        let cat = {};
        cat.id = item.contact_id.toString();
        cat.name = item.contact_role_name == "" ? "{Blank}" : item.contact_role_name;
        obj.contact_roles.push(cat);
    });
    //matter contact
    obj.matter_contact_roles = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.matter_contact_roles, (item) => {
        let mattercat = {};
        mattercat.id = item.contact_id.toString();
        mattercat.name = item.contact_role_name == "" ? "{Blank}" : item.contact_role_name;
        obj.matter_contact_roles.push(mattercat);
    });
    // Matter status and sub-status
    obj.statuses = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.mattes_statuses, (item) => {
        let status = {};
        status.id = item.matter_status_id.toString();
        status.name =
            item.matter_status_name == "" ? "{Blank}" : item.matter_status_name;
        status["subStatus"] = [];
        underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(item.matter_sub_status, (currentItem) => {
            let subStatus = {};
            subStatus.id = currentItem.matter_sub_status_id.toString();
            subStatus.name =
                currentItem.matter_sub_status_name == ""
                    ? "{Blank}"
                    : currentItem.matter_sub_status_name;
            status["subStatus"].push(subStatus);
        });
        obj.statuses.push(status);
    });
    // Law types
    obj["lawTypes"] = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.law_types, (item) => {
        let list = {};
        list.id = item.law_type_id.toString();
        list.name = item.law_type_name == "" ? "{Blank}" : item.law_type_name;
        obj["lawTypes"].push(list);
    });
    // mater types
    obj.type = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.matter_types, (item) => {
        let list = {};
        list.id = item.id.toString();
        list.name = item.name == "" ? "{Blank}" : item.name;
        list["subType"] = [];
        underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(item.sub_type, (currentItem) => {
            let array = {};
            array.id = currentItem.id.toString();
            array.name = currentItem.name == "" ? "{Blank}" : currentItem.name;
            list["subType"].push(array);
        });
        obj.type.push(list);
    });
    // Jurisdiction list
    obj.jurisdictions = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.jurisdiction, (item) => {
        let list = {};
        list.id = item.jurisdiction_id.toString();
        list.name = item.name == "" ? "{Blank}" : item.name;
        obj.jurisdictions.push(list);
    });
    // Venue list
    obj.venues = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.venues, (item) => {
        let venue = {};
        venue.id = item.id.toString();
        venue.jurisdictionId = item.jurisdiction_id.toString();
        venue.name = item.name == "" ? "{Blank}" : item.name;
        obj.venues.push(venue);
    });
    return obj;
}
function removeunwantedHTML(value) {
    const translate_re = /&(nbsp|amp|quot|lt|gt);/g;
    let translate = {
        nbsp: " ",
        amp: "&",
        quot: '"',
        lt: "<",
        gt: ">",
    };
    return value
        ? value
            .replace(/<\/?[^>]+>/gi, "")
            .replace(translate_re, (match, entity) => {
            return translate[entity];
        })
        : "";
}
function getUTCFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format("MM/DD/YYYY");
}
function getFormattedDateTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM/DD/YYYY hh:mm A");
}
function getFormattedDateTimeForEventsTabIfNotFullDay(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM-DD-YYYY | hh:mm A");
}
function getFormattedDateTimeForEventsTabIfFullDay(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM-DD-YYYY");
}
function getUTCCustomFormattedDate(utcTimeStamp, format) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format(format);
}
function getCustomFormattedDateTime(utcTimeStamp, format) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format(format);
}
function getUTCDifferentFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format("DD MMM YYYY");
}
function setUnixFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__(utcTimeStamp).unix();
}
function getUnixFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc();
}
function getUnixFormattedDateWithoutTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp);
}
function getDateandTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MMM DD, YYYY,  hh:mm A");
}
function getTimeandDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("hh:mm A  \xa0\xa0\xa0\xa0  MMM DD, YYYY");
}
function getTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("HH:mm");
}
function getDateTimeFormatted(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM/DD/YYYY hh:mm A");
}
function getDateWithGmtTimeZone(eventDate) {
    if (_isNotEmptyVal(eventDate) ||
        ((eventDate !== undefined || eventDate !== null) &&
            eventDate instanceof Date)) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(eventDate).format("MM/DD/YYYY");
    }
    else {
        return undefined;
    }
}
function getDateWithLocalTimeZone(eventDate) {
    return _isNotEmptyVal(eventDate) && eventDate !== "Invalid date"
        ? new Date(eventDate)
        : "";
}
function replaceHtmlEntites(s) {
    let translate_re = /&(nbsp|amp|quot|lt|gt);/g;
    let translate = {
        nbsp: " ",
        amp: "&",
        quot: '"',
        lt: "<",
        gt: ">",
    };
    if (s) {
        return s.replace(translate_re, function (match, entity) {
            return translate[entity];
        });
    }
    else {
        return "";
    }
}
function replaceQuoteWithActual(text) {
    const translate_re = /(&quot|&#34;)/g;
    const translate = {
        quot: '"',
        "&#34;": '"',
    };
    return text.replace(translate_re, (match, entity) => {
        return translate[entity];
    });
}
function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: "image/jpeg" });
}
/**
 * To format the nummber in currency format - $123.00
 * @param amount - Amount.
 */
function formatCurrency(amount) {
    const sign = amount;
    const formatter = new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 2,
    });
    return formatter.format(sign);
}
function formatCurrencyWithEmptyValDecimal(amount) {
    const sign = amount < 0 ? "-" : "";
    const decimalValue = (amount % 1) === 0 ? "00" : `${(amount % 1)}`.split(".")[1].substr(0, 2);
    const amt = (`${parseInt(amount, 10)}`).split("").reverse().join("").match(/[0-9]{1,3}/g).join(",").split("").reverse().join("");
    return (amount % 1) === 0 ? `${sign}${amt}` : `${sign}${amt}.${decimalValue}`;
}
function formatCurrencyWithoutDollar(amount) {
    return amount.split(".").length == 2 ? `${amount}` : `${amount}.00`;
}
function utcDateFilter(item, startOrEnd, format) {
    const fulldayTime = _setFulldayTime(item, startOrEnd);
    const date = moment__WEBPACK_IMPORTED_MODULE_1__.unix(fulldayTime).format(format);
    return date;
}
function _setFulldayTime(timestamp, setTimeFor) {
    let date = _getUtcMoment(timestamp);
    let isCorrectFullDayTime;
    const time = _getTimeString(date);
    isCorrectFullDayTime = _isTimeValid(time, setTimeFor);
    date = isCorrectFullDayTime ? date : moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
    return moment__WEBPACK_IMPORTED_MODULE_1__(date.valueOf()).unix();
}
function _isValidFullDayDate(timestamp, dateFor) {
    let date = _getUtcMoment(timestamp);
    let time = _getTimeString(date);
    return _isTimeValid(time, dateFor);
}
function _getUtcMoment(timestamp) {
    let format = "ddd MMM DD YYYY HH:mm:ss";
    let date = moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
    date = date.utc().format(format);
    date = moment__WEBPACK_IMPORTED_MODULE_1__(date, format);
    return date;
}
function _getTimeString(date) {
    return (prependZero(date.hour()) +
        ":" +
        prependZero(date.minute()) +
        ":" +
        prependZero(date.second()));
}
function _isTimeValid(time, timeFor) {
    switch (timeFor) {
        case "start":
            return time === "00:00:00";
        case "end":
            return time === "23:59:59";
    }
}
function prependZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}
/**
 * Sort an array of objects by name key.
 * @param arr - Array to be sorted.
 */
function sortByName(arr, name = "name") {
    if (!arr) {
        return [];
    }
    return arr.sort((a, b) => {
        if (a[name].toLowerCase() < b[name].toLowerCase()) {
            return -1;
        }
        else if (a[name].toLowerCase() > b[name].toLowerCase()) {
            return 1;
        }
        else {
            return 0;
        }
    });
}


/***/ }),

/***/ 54364:
/*!********************************************************!*\
  !*** ./src/app/package/mat-modules/material.module.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaterialModule": function() { return /* binding */ MaterialModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/input */ 83166);
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/table */ 32091);
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/paginator */ 99692);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/sort */ 11494);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/tooltip */ 11436);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/dialog */ 22238);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ 98295);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/select */ 67441);
/* harmony import */ var _material_extended_mde__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-extended/mde */ 61074);
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/radio */ 82613);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/list */ 77746);
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/datepicker */ 43220);
/* harmony import */ var _angular_material_badge__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/badge */ 70346);
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/slider */ 54436);
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/autocomplete */ 21554);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/grid-list */ 4929);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/tabs */ 65939);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/snack-bar */ 77001);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/expansion */ 1562);
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/progress-bar */ 12178);
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/slide-toggle */ 45396);
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/material/stepper */ 94553);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/material/menu */ 33935);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/toolbar */ 12522);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/material/sidenav */ 94935);
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/button-toggle */ 42542);
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/material/divider */ 1769);
/* harmony import */ var angular_google_charts__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! angular-google-charts */ 30159);
/* harmony import */ var igniteui_angular__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! igniteui-angular */ 84951);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/core */ 5015);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @ng-select/ng-select */ 86640);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
















//import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MatMomentDateModule } from "@angular/material-moment-adapter";




//import { MatNativeDateModule, MatIconModule, MatOptionModule, MatChipsModule, MatSidenavModule, MatTreeModule } from "@angular/material";










//import { MatPasswordStrengthModule } from "@angular-material-extensions/password-strength";









class MaterialModule {
}
MaterialModule.ɵfac = function MaterialModule_Factory(t) { return new (t || MaterialModule)(); };
MaterialModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: MaterialModule });
MaterialModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ providers: [
    // { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
    ], imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_3__.MatInputModule,
            _angular_material_table__WEBPACK_IMPORTED_MODULE_4__.MatTableModule,
            _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__.MatPaginatorModule,
            _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__.MatSortModule,
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__.MatDialogModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule,
            _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_11__.MatSelectModule,
            _material_extended_mde__WEBPACK_IMPORTED_MODULE_12__.MdePopoverModule,
            _angular_material_radio__WEBPACK_IMPORTED_MODULE_13__.MatRadioModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
            _angular_material_list__WEBPACK_IMPORTED_MODULE_15__.MatListModule,
            //MatNavList,
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_16__.MatDatepickerModule,
            // MatMomentDateModule,
            _angular_material_badge__WEBPACK_IMPORTED_MODULE_17__.MatBadgeModule,
            _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_18__.MatToolbarModule,
            _angular_material_slider__WEBPACK_IMPORTED_MODULE_19__.MatSliderModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__.MatAutocompleteModule,
            _angular_material_core__WEBPACK_IMPORTED_MODULE_21__.MatNativeDateModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_22__.MatIconModule,
            // MatOptionModule,
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_23__.MatGridListModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_24__.MatTabsModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_25__.MatSnackBarModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_26__.MatExpansionModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__.MatProgressBarModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_28__.MatSlideToggleModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_29__.MatStepperModule,
            _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__.MatMenuModule,
            // MatChipsModule,
            //MatTreeModule,
            //MatPasswordStrengthModule, 
            _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_31__.MatButtonToggleModule,
            _angular_material_divider__WEBPACK_IMPORTED_MODULE_32__.MatDividerModule,
            angular_google_charts__WEBPACK_IMPORTED_MODULE_33__.GoogleChartsModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxGridModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxButtonModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxIconModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxInputGroupModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxRippleModule,
            igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxChipsModule,
            //AngularFontAwesomeModule
            //NativeDateAdapter
            _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_35__.NgSelectModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule
        ], _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_3__.MatInputModule,
        _angular_material_table__WEBPACK_IMPORTED_MODULE_4__.MatTableModule,
        _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__.MatPaginatorModule,
        _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__.MatSortModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
        _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__.MatDialogModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule,
        _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_11__.MatSelectModule,
        _material_extended_mde__WEBPACK_IMPORTED_MODULE_12__.MdePopoverModule,
        _angular_material_radio__WEBPACK_IMPORTED_MODULE_13__.MatRadioModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
        _angular_material_list__WEBPACK_IMPORTED_MODULE_15__.MatListModule,
        //MatNavList,
        _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_16__.MatDatepickerModule,
        //MatMomentDateModule,
        _angular_material_badge__WEBPACK_IMPORTED_MODULE_17__.MatBadgeModule,
        _angular_material_slider__WEBPACK_IMPORTED_MODULE_19__.MatSliderModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__.MatAutocompleteModule,
        _angular_material_core__WEBPACK_IMPORTED_MODULE_21__.MatNativeDateModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_22__.MatIconModule,
        //MatOptionModule,
        _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_23__.MatGridListModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_24__.MatTabsModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_25__.MatSnackBarModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_26__.MatExpansionModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__.MatProgressBarModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_28__.MatSlideToggleModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_29__.MatStepperModule,
        _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__.MatMenuModule,
        //MatChipsModule,
        _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_18__.MatToolbarModule,
        _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_37__.MatSidenavModule,
        //MatTreeModule,
        //MatPasswordStrengthModule, 
        _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_31__.MatButtonToggleModule,
        _angular_material_divider__WEBPACK_IMPORTED_MODULE_32__.MatDividerModule,
        angular_google_charts__WEBPACK_IMPORTED_MODULE_33__.GoogleChartsModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxGridModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxButtonModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxIconModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxInputGroupModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxRippleModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxChipsModule,
        //FontAwesomeModule
        //NativeDateAdapter
        _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_35__.NgSelectModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](MaterialModule, { imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule,
        _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_3__.MatInputModule,
        _angular_material_table__WEBPACK_IMPORTED_MODULE_4__.MatTableModule,
        _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__.MatPaginatorModule,
        _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__.MatSortModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
        _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__.MatDialogModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule,
        _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_11__.MatSelectModule,
        _material_extended_mde__WEBPACK_IMPORTED_MODULE_12__.MdePopoverModule,
        _angular_material_radio__WEBPACK_IMPORTED_MODULE_13__.MatRadioModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
        _angular_material_list__WEBPACK_IMPORTED_MODULE_15__.MatListModule,
        //MatNavList,
        _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_16__.MatDatepickerModule,
        // MatMomentDateModule,
        _angular_material_badge__WEBPACK_IMPORTED_MODULE_17__.MatBadgeModule,
        _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_18__.MatToolbarModule,
        _angular_material_slider__WEBPACK_IMPORTED_MODULE_19__.MatSliderModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__.MatAutocompleteModule,
        _angular_material_core__WEBPACK_IMPORTED_MODULE_21__.MatNativeDateModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_22__.MatIconModule,
        // MatOptionModule,
        _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_23__.MatGridListModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_24__.MatTabsModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_25__.MatSnackBarModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_26__.MatExpansionModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__.MatProgressBarModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_28__.MatSlideToggleModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_29__.MatStepperModule,
        _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__.MatMenuModule,
        // MatChipsModule,
        //MatTreeModule,
        //MatPasswordStrengthModule, 
        _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_31__.MatButtonToggleModule,
        _angular_material_divider__WEBPACK_IMPORTED_MODULE_32__.MatDividerModule,
        angular_google_charts__WEBPACK_IMPORTED_MODULE_33__.GoogleChartsModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxGridModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxButtonModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxIconModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxInputGroupModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxRippleModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxChipsModule,
        //AngularFontAwesomeModule
        //NativeDateAdapter
        _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_35__.NgSelectModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule], exports: [_angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_3__.MatInputModule,
        _angular_material_table__WEBPACK_IMPORTED_MODULE_4__.MatTableModule,
        _angular_material_paginator__WEBPACK_IMPORTED_MODULE_5__.MatPaginatorModule,
        _angular_material_sort__WEBPACK_IMPORTED_MODULE_6__.MatSortModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
        _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__.MatDialogModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule,
        _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_11__.MatSelectModule,
        _material_extended_mde__WEBPACK_IMPORTED_MODULE_12__.MdePopoverModule,
        _angular_material_radio__WEBPACK_IMPORTED_MODULE_13__.MatRadioModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
        _angular_material_list__WEBPACK_IMPORTED_MODULE_15__.MatListModule,
        //MatNavList,
        _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_16__.MatDatepickerModule,
        //MatMomentDateModule,
        _angular_material_badge__WEBPACK_IMPORTED_MODULE_17__.MatBadgeModule,
        _angular_material_slider__WEBPACK_IMPORTED_MODULE_19__.MatSliderModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__.MatAutocompleteModule,
        _angular_material_core__WEBPACK_IMPORTED_MODULE_21__.MatNativeDateModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_22__.MatIconModule,
        //MatOptionModule,
        _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_23__.MatGridListModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_24__.MatTabsModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_25__.MatSnackBarModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_26__.MatExpansionModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__.MatProgressBarModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_28__.MatSlideToggleModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_29__.MatStepperModule,
        _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__.MatMenuModule,
        //MatChipsModule,
        _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_18__.MatToolbarModule,
        _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_37__.MatSidenavModule,
        //MatTreeModule,
        //MatPasswordStrengthModule, 
        _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_31__.MatButtonToggleModule,
        _angular_material_divider__WEBPACK_IMPORTED_MODULE_32__.MatDividerModule,
        angular_google_charts__WEBPACK_IMPORTED_MODULE_33__.GoogleChartsModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxGridModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxButtonModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxIconModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxInputGroupModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxRippleModule,
        igniteui_angular__WEBPACK_IMPORTED_MODULE_34__.IgxChipsModule,
        //FontAwesomeModule
        //NativeDateAdapter
        _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_35__.NgSelectModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule] }); })();


/***/ }),

/***/ 87366:
/*!******************************************************************************!*\
  !*** ./src/app/package/modules/rdap-shared-components/utils/shared-utils.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStartOfDayUTCDate": function() { return /* binding */ getStartOfDayUTCDate; },
/* harmony export */   "getStartOfDayTimestamp": function() { return /* binding */ getStartOfDayTimestamp; },
/* harmony export */   "hasValue": function() { return /* binding */ hasValue; },
/* harmony export */   "removeSpaces": function() { return /* binding */ removeSpaces; },
/* harmony export */   "getUUid": function() { return /* binding */ getUUid; },
/* harmony export */   "isNotEmptyVal": function() { return /* binding */ isNotEmptyVal; },
/* harmony export */   "isEmptyVal": function() { return /* binding */ isEmptyVal; },
/* harmony export */   "isEmptyString": function() { return /* binding */ isEmptyString; },
/* harmony export */   "isNotEmptyString": function() { return /* binding */ isNotEmptyString; },
/* harmony export */   "isEmptyObj": function() { return /* binding */ isEmptyObj; },
/* harmony export */   "moveArrayElement": function() { return /* binding */ moveArrayElement; },
/* harmony export */   "getUTCTimeStampEndDay": function() { return /* binding */ getUTCTimeStampEndDay; },
/* harmony export */   "getUTCStartFromMoment": function() { return /* binding */ getUTCStartFromMoment; },
/* harmony export */   "getUTCTimeStamp": function() { return /* binding */ getUTCTimeStamp; },
/* harmony export */   "getUTCEndTimeStamp": function() { return /* binding */ getUTCEndTimeStamp; },
/* harmony export */   "replaceNullByEmptyString": function() { return /* binding */ replaceNullByEmptyString; },
/* harmony export */   "replaceNullByEmptyStringArray": function() { return /* binding */ replaceNullByEmptyStringArray; },
/* harmony export */   "getParams": function() { return /* binding */ getParams; },
/* harmony export */   "getParamsforReminder": function() { return /* binding */ getParamsforReminder; },
/* harmony export */   "getParamsWithTimeZone": function() { return /* binding */ getParamsWithTimeZone; },
/* harmony export */   "getTimezone": function() { return /* binding */ getTimezone; },
/* harmony export */   "getNotificationLocation": function() { return /* binding */ getNotificationLocation; },
/* harmony export */   "processNotification": function() { return /* binding */ processNotification; },
/* harmony export */   "mapKeys": function() { return /* binding */ mapKeys; },
/* harmony export */   "_isEmptyVal": function() { return /* binding */ _isEmptyVal; },
/* harmony export */   "_isNotEmptyVal": function() { return /* binding */ _isNotEmptyVal; },
/* harmony export */   "_isEmptyString": function() { return /* binding */ _isEmptyString; },
/* harmony export */   "_isNotEmptyString": function() { return /* binding */ _isNotEmptyString; },
/* harmony export */   "_isEmptyObj": function() { return /* binding */ _isEmptyObj; },
/* harmony export */   "firstDayOfWeek": function() { return /* binding */ firstDayOfWeek; },
/* harmony export */   "getParamsForTaskCommon": function() { return /* binding */ getParamsForTaskCommon; },
/* harmony export */   "getParamsForIntake": function() { return /* binding */ getParamsForIntake; },
/* harmony export */   "mapMatterFilterKeys": function() { return /* binding */ mapMatterFilterKeys; },
/* harmony export */   "removeunwantedHTML": function() { return /* binding */ removeunwantedHTML; },
/* harmony export */   "getUTCFormattedDate": function() { return /* binding */ getUTCFormattedDate; },
/* harmony export */   "getFormattedDateTime": function() { return /* binding */ getFormattedDateTime; },
/* harmony export */   "getFormattedDateTimeForEventsTabIfNotFullDay": function() { return /* binding */ getFormattedDateTimeForEventsTabIfNotFullDay; },
/* harmony export */   "getFormattedDateTimeForEventsTabIfFullDay": function() { return /* binding */ getFormattedDateTimeForEventsTabIfFullDay; },
/* harmony export */   "getUTCCustomFormattedDate": function() { return /* binding */ getUTCCustomFormattedDate; },
/* harmony export */   "getCustomFormattedDateTime": function() { return /* binding */ getCustomFormattedDateTime; },
/* harmony export */   "getUTCDifferentFormattedDate": function() { return /* binding */ getUTCDifferentFormattedDate; },
/* harmony export */   "setUnixFormattedDate": function() { return /* binding */ setUnixFormattedDate; },
/* harmony export */   "getUnixFormattedDate": function() { return /* binding */ getUnixFormattedDate; },
/* harmony export */   "getUnixFormattedDateWithoutTime": function() { return /* binding */ getUnixFormattedDateWithoutTime; },
/* harmony export */   "getDateandTime": function() { return /* binding */ getDateandTime; },
/* harmony export */   "getTimeandDate": function() { return /* binding */ getTimeandDate; },
/* harmony export */   "getTime": function() { return /* binding */ getTime; },
/* harmony export */   "getDateTimeFormatted": function() { return /* binding */ getDateTimeFormatted; },
/* harmony export */   "getDateWithGmtTimeZone": function() { return /* binding */ getDateWithGmtTimeZone; },
/* harmony export */   "getDateWithLocalTimeZone": function() { return /* binding */ getDateWithLocalTimeZone; },
/* harmony export */   "replaceHtmlEntites": function() { return /* binding */ replaceHtmlEntites; },
/* harmony export */   "replaceQuoteWithActual": function() { return /* binding */ replaceQuoteWithActual; },
/* harmony export */   "dataURItoBlob": function() { return /* binding */ dataURItoBlob; },
/* harmony export */   "formatCurrency": function() { return /* binding */ formatCurrency; },
/* harmony export */   "formatCurrencyWithEmptyValDecimal": function() { return /* binding */ formatCurrencyWithEmptyValDecimal; },
/* harmony export */   "formatCurrencyWithoutDollar": function() { return /* binding */ formatCurrencyWithoutDollar; },
/* harmony export */   "utcDateFilter": function() { return /* binding */ utcDateFilter; },
/* harmony export */   "sortByName": function() { return /* binding */ sortByName; }
/* harmony export */ });
/* harmony import */ var underscore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! underscore */ 35849);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ 16738);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment-timezone */ 71412);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_2__);



// tslint:disable: prefer-const
// tslint:disable: variable-name
function getStartOfDayUTCDate(d) {
    return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}
function getStartOfDayTimestamp(date) {
    let startOfDay;
    startOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    return startOfDay / 1000;
}
function hasValue(data) {
    if (data === undefined || data === "" || data === null) {
        return false;
    }
    return true;
}
function removeSpaces(content) {
    return content.replace(/\s/g, "");
}
function getUUid() {
    let dt = new Date().getTime();
    const uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        // tslint:disable-next-line: no-bitwise
        const r = (dt + Math.random() * 16) % 16 | 0;
        dt = Math.floor(dt / 16);
        // tslint:disable: triple-equals
        // tslint:disable: no-bitwise
        return (c == "x" ? r : (r & 0x3) | 0x8).toString(16);
    });
    return uuid;
}
function isNotEmptyVal(val) {
    return !isEmptyVal(val);
}
function isEmptyVal(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    if (val instanceof Array) {
        return val.length === 0;
    }
    if (isEmptyString(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNaN(val)) {
        return true;
    }
    return false;
}
function isEmptyString(str) {
    str = "" + str;
    return str.trim().length === 0;
}
function isNotEmptyString(str) {
    str = "" + str;
    return str.trim().length > 0;
}
function isEmptyObj(obj) {
    if (typeof obj === "undefined") {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(obj)) {
        return true;
    }
    return Object.keys(obj).length === 0;
}
function moveArrayElement(array, old_index, new_index) {
    if (new_index >= array.length) {
        let k = new_index - array.length;
        while (k-- + 1) {
            array.push(undefined);
        }
    }
    array.splice(new_index, 0, array.splice(old_index, 1)[0]);
}
function getUTCTimeStampEndDay(selectedDate) {
    const date = new Date(selectedDate);
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth();
    const day = date.getDate();
    const startHour = Date.UTC(year, month, day, 23, 59, 59);
    const timestamp = startHour / 1000;
    return timestamp;
}
function getUTCStartFromMoment(start) {
    let startDt = new Date(Date.UTC(parseInt(start.format("YYYY")), parseInt(start.format("MM")) - 1, parseInt(start.format("DD")), 0, 0, 0, 0));
    return moment__WEBPACK_IMPORTED_MODULE_1__(startDt.getTime()).unix();
}
function getUTCTimeStamp(selectedDate) {
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate).unix();
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__.unix(selectedDate).format("YYYY-MM-DD");
    const UTCDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate + " 0:00 +0000", "YYYY-MM-DD HH:mm Z");
    const timeStamp = moment__WEBPACK_IMPORTED_MODULE_1__(UTCDate).unix();
    return timeStamp;
}
function getUTCEndTimeStamp(selectedDate) {
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate).unix();
    selectedDate = moment__WEBPACK_IMPORTED_MODULE_1__.unix(selectedDate).format("YYYY-MM-DD");
    const UTCDate = moment__WEBPACK_IMPORTED_MODULE_1__(selectedDate + " 23:59 +0000", "YYYY-MM-DD HH:mm Z");
    const timeStamp = moment__WEBPACK_IMPORTED_MODULE_1__(UTCDate).unix();
    return timeStamp;
}
function replaceNullByEmptyString(obj) {
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(obj, (val, key) => {
        if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val) || underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
            obj[key] = "";
        }
    });
}
function replaceNullByEmptyStringArray(array) {
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(array, (obj) => {
        replaceNullByEmptyString(obj);
    });
}
function getParams(params) {
    let querystring = "";
    params.forEach((value, key) => {
        querystring += key + "=" + value;
        querystring += "&";
    });
    return querystring.slice(0, querystring.length - 1);
}
function getParamsforReminder(params) {
    params.tz = getTimezone();
    let querystring = "";
    for (let [key, value] of Object.entries(params)) {
        querystring += key + "=" + value;
        querystring += "&";
    }
    return querystring.slice(0, querystring.length - 1);
}
function getParamsWithTimeZone(params) {
    let tz = getTimezone();
    let timeZone = moment_timezone__WEBPACK_IMPORTED_MODULE_2__.tz.guess();
    params.tz = timeZone;
    let querystring = "";
    for (let [key, value] of Object.entries(params)) {
        querystring += key + "=" + value;
        querystring += "&";
    }
    return querystring.slice(0, querystring.length - 1);
}
function getTimezone() {
    const offset = new Date().getTimezoneOffset();
    const o = Math.abs(offset);
    return ((offset < 0 ? "+" : "-") +
        ("00" + Math.floor(o / 60)).slice(-2) +
        ":" +
        ("00" + (o % 60)).slice(-2));
}
function getNotificationLocation(sectors) {
    let placeArr = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(sectors, (item) => {
        switch (item) {
            case 1: // event
                placeArr.push("Event");
                break;
            case 2: // task
                placeArr.push("Task");
                break;
            case 3: // reminders
                placeArr.push("Event_Reminder");
                placeArr.push("Task_Reminder");
                break;
            case 4: // Email
                placeArr.push("Email");
                break;
            case 5: // sms
                placeArr.push("Client_Messenger");
                break;
            case 6: // Sidebar_Comment
                placeArr.push("Sidebar_Comment");
                placeArr.push("Sidebar_Post");
                break;
            case 7:
                placeArr.push("Matter");
                break;
            case 8:
                placeArr.push("Intake");
                break;
            case 9:
                placeArr.push("UberTrip");
                break;
        }
    });
    return placeArr;
}
function processNotification(res) {
    let now = moment__WEBPACK_IMPORTED_MODULE_1__(new Date()); // todays date
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(res, (currentItem) => {
        let end = moment__WEBPACK_IMPORTED_MODULE_1__.unix(currentItem.created_on); // another date
        let duration = moment__WEBPACK_IMPORTED_MODULE_1__.duration(now.diff(end));
        currentItem.createdHoursBack = Math.floor(duration.asHours());
        currentItem.createdMinuteBack = Math.floor(duration.asMinutes());
        currentItem.notiDots = false;
        //
        if (currentItem.notification_type == "Sidebar_Comment") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.nid = notData.nid;
            currentItem.comment = notData.comment_body_value;
            currentItem.post = notData.body_value;
        }
        if (currentItem.notification_type == "Sidebar_Post") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.nid = notData.nid;
            currentItem.post = notData.body_value;
        }
        if (currentItem.notification_type == "Email") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.mail_body = notData.mail_body;
            currentItem.senders_name = notData.senders_name;
            currentItem.subject = notData.subject;
        }
        if (currentItem.notification_type == "Event") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "event";
        }
        if (currentItem.notification_type == "Task") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "task";
        }
        if (currentItem.notification_type == "Event_Reminder") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.type = "event";
        }
        if (currentItem.notification_type == "Task_Reminder") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.text = notData.notification_text;
            currentItem.type = "task";
        }
        if (currentItem.notification_type == "Matter") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "matter";
        }
        if (currentItem.notification_type == "Intake") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = "intake";
        }
        if (currentItem.notification_type == "Client_Messenger") {
            let notData = JSON.parse(currentItem.notification_text);
            currentItem.sender_name = notData.sender_name;
            currentItem.text = notData.message;
            currentItem.is_sms = notData.is_sms;
        }
        if (currentItem.notification_type == "UberTrip") {
            currentItem.text = currentItem.notification_text;
            currentItem.type = 'UberTrip';
        }
    });
    return res;
}
function mapKeys(data) {
    const obj = {};
    obj.contact_type = JSON.parse(data.matter_contact_type);
    obj.states = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.states, (item) => {
        obj.states.push(item.name.toString());
    });
    return obj;
}
function _isEmptyVal(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNaN(val)) {
        return true;
    }
    if (val instanceof Array) {
        return val.length === 0;
    }
    if (val instanceof Object) {
        return Object.keys(val).length === 0;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    if (_isEmptyString(val)) {
        return true;
    }
}
function _isNotEmptyVal(val) {
    return !_isEmptyVal(val);
}
function _isEmptyString(str) {
    return str.toString().trim().length === 0;
}
function _isNotEmptyString(str) {
    return str.toString().trim().length > 0;
}
function _isEmptyObj(val) {
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isUndefined(val)) {
        return true;
    }
    if (underscore__WEBPACK_IMPORTED_MODULE_0__.isNull(val)) {
        return true;
    }
    return Object.keys(val).length === 0;
}
// public removeFieldSpaces(e): void {
//   e.target.value = removeSpaces(e.target.value);
// }
// public get(id: string): Observable<any> {
//   return this.http.get<any>(`${environment.urlPath}/user//${id}`);
// }
function firstDayOfWeek(year, week) {
    // Jan 1 of 'year'
    let d = new Date(year, 0, 1);
    let offset = d.getTimezoneOffset();
    // ISO: week 1 is the one with the year's first Thursday
    // so nearest Thursday: current date + 4 - current day number
    // Sunday is converted from 0 to 7
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    // 7 days * (week - overlapping first week)
    d.setTime(d.getTime() +
        7 * 24 * 60 * 60 * 1000 * (week + (year == d.getFullYear() ? -1 : 0)));
    // daylight savings fix
    d.setTime(d.getTime() + (d.getTimezoneOffset() - offset) * 60 * 1000);
    // back to Monday (from Thursday)
    d.setDate(d.getDate() - 3);
    const timestamp = moment__WEBPACK_IMPORTED_MODULE_1__(d.getTime()).unix();
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
}
function getParamsForTaskCommon(params, type) {
    params.tz = getTimezone();
    let querystring = "";
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(params, (value, key) => {
        if (type == "MM") {
            querystring += key + "=" + value;
            querystring += "&";
        }
        else if (type == "IM") {
            if (isNotEmptyVal(value)) {
                querystring += key + "=" + value;
                querystring += "&";
            }
        }
    });
    return querystring.slice(0, querystring.length - 1);
}
function getParamsForIntake(params) {
    params.tz = getTimezone();
    let querystring = "";
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(params, (value, key) => {
        if (isNotEmptyVal(value)) {
            querystring += key + "=" + value;
            querystring += "&";
        }
    });
    return querystring.slice(0, querystring.length - 1);
}
function mapMatterFilterKeys(data) {
    let obj = {};
    // Matter Category
    obj.category = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.category, (item) => {
        let cat = {};
        cat.id = item.id.toString();
        cat.name = item.name == "" ? "{Blank}" : item.name;
        obj.category.push(cat);
    });
    obj.contact_roles = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.contact_roles, (item) => {
        let cat = {};
        cat.id = item.contact_id.toString();
        cat.name = item.contact_role_name == "" ? "{Blank}" : item.contact_role_name;
        obj.contact_roles.push(cat);
    });
    //matter contact
    obj.matter_contact_roles = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.matter_contact_roles, (item) => {
        let mattercat = {};
        mattercat.id = item.contact_id.toString();
        mattercat.name = item.contact_role_name == "" ? "{Blank}" : item.contact_role_name;
        obj.matter_contact_roles.push(mattercat);
    });
    // Matter status and sub-status
    obj.statuses = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.mattes_statuses, (item) => {
        let status = {};
        status.id = item.matter_status_id.toString();
        status.name =
            item.matter_status_name == "" ? "{Blank}" : item.matter_status_name;
        status["subStatus"] = [];
        underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(item.matter_sub_status, (currentItem) => {
            let subStatus = {};
            subStatus.id = currentItem.matter_sub_status_id.toString();
            subStatus.name =
                currentItem.matter_sub_status_name == ""
                    ? "{Blank}"
                    : currentItem.matter_sub_status_name;
            status["subStatus"].push(subStatus);
        });
        obj.statuses.push(status);
    });
    // Law types
    obj["lawTypes"] = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.law_types, (item) => {
        let list = {};
        list.id = item.law_type_id.toString();
        list.name = item.law_type_name == "" ? "{Blank}" : item.law_type_name;
        obj["lawTypes"].push(list);
    });
    // mater types
    obj.type = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.matter_types, (item) => {
        let list = {};
        list.id = item.id.toString();
        list.name = item.name == "" ? "{Blank}" : item.name;
        list["subType"] = [];
        underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(item.sub_type, (currentItem) => {
            let array = {};
            array.id = currentItem.id.toString();
            array.name = currentItem.name == "" ? "{Blank}" : currentItem.name;
            list["subType"].push(array);
        });
        obj.type.push(list);
    });
    // Jurisdiction list
    obj.jurisdictions = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.jurisdiction, (item) => {
        let list = {};
        list.id = item.jurisdiction_id.toString();
        list.name = item.name == "" ? "{Blank}" : item.name;
        obj.jurisdictions.push(list);
    });
    // Venue list
    obj.venues = [];
    underscore__WEBPACK_IMPORTED_MODULE_0__.forEach(data.venues, (item) => {
        let venue = {};
        venue.id = item.id.toString();
        venue.jurisdictionId = item.jurisdiction_id.toString();
        venue.name = item.name == "" ? "{Blank}" : item.name;
        obj.venues.push(venue);
    });
    return obj;
}
function removeunwantedHTML(value) {
    const translate_re = /&(nbsp|amp|quot|lt|gt);/g;
    let translate = {
        nbsp: " ",
        amp: "&",
        quot: '"',
        lt: "<",
        gt: ">",
    };
    return value
        ? value
            .replace(/<\/?[^>]+>/gi, "")
            .replace(translate_re, (match, entity) => {
            return translate[entity];
        })
        : "";
}
function getUTCFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format("MM/DD/YYYY");
}
function getFormattedDateTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM/DD/YYYY hh:mm A");
}
function getFormattedDateTimeForEventsTabIfNotFullDay(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM-DD-YYYY | hh:mm A");
}
function getFormattedDateTimeForEventsTabIfFullDay(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM-DD-YYYY");
}
function getUTCCustomFormattedDate(utcTimeStamp, format) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format(format);
}
function getCustomFormattedDateTime(utcTimeStamp, format) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format(format);
}
function getUTCDifferentFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc().format("DD MMM YYYY");
}
function setUnixFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__(utcTimeStamp).unix();
}
function getUnixFormattedDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).utc();
}
function getUnixFormattedDateWithoutTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp);
}
function getDateandTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MMM DD, YYYY,  hh:mm A");
}
function getTimeandDate(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("hh:mm A  \xa0\xa0\xa0\xa0  MMM DD, YYYY");
}
function getTime(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("HH:mm");
}
function getDateTimeFormatted(utcTimeStamp) {
    return moment__WEBPACK_IMPORTED_MODULE_1__.unix(utcTimeStamp).format("MM/DD/YYYY hh:mm A");
}
function getDateWithGmtTimeZone(eventDate) {
    if (_isNotEmptyVal(eventDate) ||
        ((eventDate !== undefined || eventDate !== null) &&
            eventDate instanceof Date)) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(eventDate).format("MM/DD/YYYY");
    }
    else {
        return undefined;
    }
}
function getDateWithLocalTimeZone(eventDate) {
    return _isNotEmptyVal(eventDate) && eventDate !== "Invalid date"
        ? new Date(eventDate)
        : "";
}
function replaceHtmlEntites(s) {
    let translate_re = /&(nbsp|amp|quot|lt|gt);/g;
    let translate = {
        nbsp: " ",
        amp: "&",
        quot: '"',
        lt: "<",
        gt: ">",
    };
    if (s) {
        return s.replace(translate_re, function (match, entity) {
            return translate[entity];
        });
    }
    else {
        return "";
    }
}
function replaceQuoteWithActual(text) {
    const translate_re = /(&quot|&#34;)/g;
    const translate = {
        quot: '"',
        "&#34;": '"',
    };
    return text.replace(translate_re, (match, entity) => {
        return translate[entity];
    });
}
function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: "image/jpeg" });
}
/**
 * To format the nummber in currency format - $123.00
 * @param amount - Amount.
 */
function formatCurrency(amount) {
    const sign = amount;
    const formatter = new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 2,
    });
    return formatter.format(sign);
}
function formatCurrencyWithEmptyValDecimal(amount) {
    const sign = amount < 0 ? "-" : "";
    const decimalValue = (amount % 1) === 0 ? "00" : `${(amount % 1)}`.split(".")[1].substr(0, 2);
    const amt = (`${parseInt(amount, 10)}`).split("").reverse().join("").match(/[0-9]{1,3}/g).join(",").split("").reverse().join("");
    return (amount % 1) === 0 ? `${sign}${amt}` : `${sign}${amt}.${decimalValue}`;
}
function formatCurrencyWithoutDollar(amount) {
    return amount.split(".").length == 2 ? `${amount}` : `${amount}.00`;
}
function utcDateFilter(item, startOrEnd, format) {
    const fulldayTime = _setFulldayTime(item, startOrEnd);
    const date = moment__WEBPACK_IMPORTED_MODULE_1__.unix(fulldayTime).format(format);
    return date;
}
function _setFulldayTime(timestamp, setTimeFor) {
    let date = _getUtcMoment(timestamp);
    let isCorrectFullDayTime;
    const time = _getTimeString(date);
    isCorrectFullDayTime = _isTimeValid(time, setTimeFor);
    date = isCorrectFullDayTime ? date : moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
    return moment__WEBPACK_IMPORTED_MODULE_1__(date.valueOf()).unix();
}
function _isValidFullDayDate(timestamp, dateFor) {
    let date = _getUtcMoment(timestamp);
    let time = _getTimeString(date);
    return _isTimeValid(time, dateFor);
}
function _getUtcMoment(timestamp) {
    let format = "ddd MMM DD YYYY HH:mm:ss";
    let date = moment__WEBPACK_IMPORTED_MODULE_1__.unix(timestamp);
    date = date.utc().format(format);
    date = moment__WEBPACK_IMPORTED_MODULE_1__(date, format);
    return date;
}
function _getTimeString(date) {
    return (prependZero(date.hour()) +
        ":" +
        prependZero(date.minute()) +
        ":" +
        prependZero(date.second()));
}
function _isTimeValid(time, timeFor) {
    switch (timeFor) {
        case "start":
            return time === "00:00:00";
        case "end":
            return time === "23:59:59";
    }
}
function prependZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}
/**
 * Sort an array of objects by name key.
 * @param arr - Array to be sorted.
 */
function sortByName(arr, name = "name") {
    if (!arr) {
        return [];
    }
    return arr.sort((a, b) => {
        if (a[name].toLowerCase() < b[name].toLowerCase()) {
            return -1;
        }
        else if (a[name].toLowerCase() > b[name].toLowerCase()) {
            return 1;
        }
        else {
            return 0;
        }
    });
}


/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": function() { return /* binding */ environment; }
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 39075);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.error(err));


/***/ }),

/***/ 46700:
/*!***************************************************!*\
  !*** ./node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./af": 26431,
	"./af.js": 26431,
	"./ar": 81286,
	"./ar-dz": 1616,
	"./ar-dz.js": 1616,
	"./ar-kw": 9759,
	"./ar-kw.js": 9759,
	"./ar-ly": 43160,
	"./ar-ly.js": 43160,
	"./ar-ma": 62551,
	"./ar-ma.js": 62551,
	"./ar-sa": 79989,
	"./ar-sa.js": 79989,
	"./ar-tn": 6962,
	"./ar-tn.js": 6962,
	"./ar.js": 81286,
	"./az": 15887,
	"./az.js": 15887,
	"./be": 14572,
	"./be.js": 14572,
	"./bg": 3276,
	"./bg.js": 3276,
	"./bm": 93344,
	"./bm.js": 93344,
	"./bn": 58985,
	"./bn-bd": 83990,
	"./bn-bd.js": 83990,
	"./bn.js": 58985,
	"./bo": 94391,
	"./bo.js": 94391,
	"./br": 46728,
	"./br.js": 46728,
	"./bs": 5536,
	"./bs.js": 5536,
	"./ca": 41043,
	"./ca.js": 41043,
	"./cs": 70420,
	"./cs.js": 70420,
	"./cv": 33513,
	"./cv.js": 33513,
	"./cy": 6771,
	"./cy.js": 6771,
	"./da": 47978,
	"./da.js": 47978,
	"./de": 46061,
	"./de-at": 25204,
	"./de-at.js": 25204,
	"./de-ch": 2653,
	"./de-ch.js": 2653,
	"./de.js": 46061,
	"./dv": 85,
	"./dv.js": 85,
	"./el": 8579,
	"./el.js": 8579,
	"./en-au": 25724,
	"./en-au.js": 25724,
	"./en-ca": 10525,
	"./en-ca.js": 10525,
	"./en-gb": 52847,
	"./en-gb.js": 52847,
	"./en-ie": 67216,
	"./en-ie.js": 67216,
	"./en-il": 39305,
	"./en-il.js": 39305,
	"./en-in": 73364,
	"./en-in.js": 73364,
	"./en-nz": 79130,
	"./en-nz.js": 79130,
	"./en-sg": 11161,
	"./en-sg.js": 11161,
	"./eo": 50802,
	"./eo.js": 50802,
	"./es": 40328,
	"./es-do": 45551,
	"./es-do.js": 45551,
	"./es-mx": 75615,
	"./es-mx.js": 75615,
	"./es-us": 64790,
	"./es-us.js": 64790,
	"./es.js": 40328,
	"./et": 96389,
	"./et.js": 96389,
	"./eu": 52961,
	"./eu.js": 52961,
	"./fa": 26151,
	"./fa.js": 26151,
	"./fi": 7997,
	"./fi.js": 7997,
	"./fil": 58898,
	"./fil.js": 58898,
	"./fo": 37779,
	"./fo.js": 37779,
	"./fr": 28174,
	"./fr-ca": 3287,
	"./fr-ca.js": 3287,
	"./fr-ch": 38867,
	"./fr-ch.js": 38867,
	"./fr.js": 28174,
	"./fy": 50452,
	"./fy.js": 50452,
	"./ga": 45014,
	"./ga.js": 45014,
	"./gd": 74127,
	"./gd.js": 74127,
	"./gl": 72124,
	"./gl.js": 72124,
	"./gom-deva": 6444,
	"./gom-deva.js": 6444,
	"./gom-latn": 37953,
	"./gom-latn.js": 37953,
	"./gu": 76604,
	"./gu.js": 76604,
	"./he": 1222,
	"./he.js": 1222,
	"./hi": 74235,
	"./hi.js": 74235,
	"./hr": 622,
	"./hr.js": 622,
	"./hu": 37735,
	"./hu.js": 37735,
	"./hy-am": 90402,
	"./hy-am.js": 90402,
	"./id": 59187,
	"./id.js": 59187,
	"./is": 30536,
	"./is.js": 30536,
	"./it": 35007,
	"./it-ch": 94667,
	"./it-ch.js": 94667,
	"./it.js": 35007,
	"./ja": 62093,
	"./ja.js": 62093,
	"./jv": 80059,
	"./jv.js": 80059,
	"./ka": 66870,
	"./ka.js": 66870,
	"./kk": 80880,
	"./kk.js": 80880,
	"./km": 1083,
	"./km.js": 1083,
	"./kn": 68785,
	"./kn.js": 68785,
	"./ko": 21721,
	"./ko.js": 21721,
	"./ku": 37851,
	"./ku.js": 37851,
	"./ky": 1727,
	"./ky.js": 1727,
	"./lb": 40346,
	"./lb.js": 40346,
	"./lo": 93002,
	"./lo.js": 93002,
	"./lt": 64035,
	"./lt.js": 64035,
	"./lv": 56927,
	"./lv.js": 56927,
	"./me": 5634,
	"./me.js": 5634,
	"./mi": 94173,
	"./mi.js": 94173,
	"./mk": 86320,
	"./mk.js": 86320,
	"./ml": 11705,
	"./ml.js": 11705,
	"./mn": 31062,
	"./mn.js": 31062,
	"./mr": 92805,
	"./mr.js": 92805,
	"./ms": 11341,
	"./ms-my": 59900,
	"./ms-my.js": 59900,
	"./ms.js": 11341,
	"./mt": 37734,
	"./mt.js": 37734,
	"./my": 19034,
	"./my.js": 19034,
	"./nb": 9324,
	"./nb.js": 9324,
	"./ne": 46495,
	"./ne.js": 46495,
	"./nl": 70673,
	"./nl-be": 76272,
	"./nl-be.js": 76272,
	"./nl.js": 70673,
	"./nn": 72486,
	"./nn.js": 72486,
	"./oc-lnc": 46219,
	"./oc-lnc.js": 46219,
	"./pa-in": 2829,
	"./pa-in.js": 2829,
	"./pl": 78444,
	"./pl.js": 78444,
	"./pt": 53170,
	"./pt-br": 66117,
	"./pt-br.js": 66117,
	"./pt.js": 53170,
	"./ro": 96587,
	"./ro.js": 96587,
	"./ru": 39264,
	"./ru.js": 39264,
	"./sd": 42135,
	"./sd.js": 42135,
	"./se": 95366,
	"./se.js": 95366,
	"./si": 93379,
	"./si.js": 93379,
	"./sk": 46143,
	"./sk.js": 46143,
	"./sl": 196,
	"./sl.js": 196,
	"./sq": 21082,
	"./sq.js": 21082,
	"./sr": 91621,
	"./sr-cyrl": 98963,
	"./sr-cyrl.js": 98963,
	"./sr.js": 91621,
	"./ss": 41404,
	"./ss.js": 41404,
	"./sv": 55685,
	"./sv.js": 55685,
	"./sw": 3872,
	"./sw.js": 3872,
	"./ta": 54106,
	"./ta.js": 54106,
	"./te": 39204,
	"./te.js": 39204,
	"./tet": 83692,
	"./tet.js": 83692,
	"./tg": 86361,
	"./tg.js": 86361,
	"./th": 31735,
	"./th.js": 31735,
	"./tk": 1568,
	"./tk.js": 1568,
	"./tl-ph": 96129,
	"./tl-ph.js": 96129,
	"./tlh": 13759,
	"./tlh.js": 13759,
	"./tr": 81644,
	"./tr.js": 81644,
	"./tzl": 90875,
	"./tzl.js": 90875,
	"./tzm": 16878,
	"./tzm-latn": 11041,
	"./tzm-latn.js": 11041,
	"./tzm.js": 16878,
	"./ug-cn": 74357,
	"./ug-cn.js": 74357,
	"./uk": 74810,
	"./uk.js": 74810,
	"./ur": 86794,
	"./ur.js": 86794,
	"./uz": 28966,
	"./uz-latn": 77959,
	"./uz-latn.js": 77959,
	"./uz.js": 28966,
	"./vi": 35386,
	"./vi.js": 35386,
	"./x-pseudo": 23156,
	"./x-pseudo.js": 23156,
	"./yo": 68028,
	"./yo.js": 68028,
	"./zh-cn": 9330,
	"./zh-cn.js": 9330,
	"./zh-hk": 89380,
	"./zh-hk.js": 89380,
	"./zh-mo": 60874,
	"./zh-mo.js": 60874,
	"./zh-tw": 96508,
	"./zh-tw.js": 96508
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 46700;

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["vendor"], function() { return __webpack_exec__(14431); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main-es2015.js.map